#include "ai_demo_obj.hpp"


AIDemoObject::AIDemoObject(const sf::Vector2f& size, const sf::Vector2f& position, std::vector<crumb>* crumbs)
{
    crumbIndex = 0;
    dropTimer = 0;
    this->setPosition(position);
    setSize(size);
    this->collidable = true;
    this->colType = CollisionType::STANDARD;
    this->shouldRender = true;
    this->objectID = ++nextID;
    this->breadcrumbs = crumbs;
    
}

void AIDemoObject::Update(int64_t deltaT){

    // Drop breadcrumb
    //basic timer for leaving breadcrumbs
    if (dropTimer > 0)
    {
        dropTimer -= deltaT;
    }
    else
    {
        dropTimer = 100.f;
        breadcrumbs->at(crumbIndex).drop(this->getPosition());

        if (crumbIndex < 9)
            crumbIndex++;
        else
            crumbIndex = 0;
    }

    // Define steering behaviors
    Arrive arrive = Arrive(500, 850, 125, 50, 0.05);
    Align align = Align(10, 2 * M_PI / 3, 0.05, 0.01);

    // Update Kinematic Data
    this->kineData.position = this->getPosition();
    this->kineData.orientation = this->getRotation() * M_PI / 180;

    //std::cout << "Current position: [" << kineData.position.x << ", " << kineData.position.y << "]" << std::endl;
    //std::cout << "Target position: [" << targetData.position.x << ", " << targetData.position.y << "]" << std::endl;
    //std::cout << "Sent Target velocity: [" << targetData.velocity.x << ", " << targetData.velocity.y << "]" << std::endl;\

    // Calculate linear acceleration
    SteeringData sDataLin = arrive.calculateAcceleration(this->kineData, targetData);

    // Calculate target orientation
    sf::Vector2f direction = targetData.position - this->kineData.position;

    sf::Vector2f directionNormalized = direction;
    float directionMag = sqrt(pow(direction.x, 2) + pow(direction.y, 2));
    if(directionMag <= 45){
        targetData.orientation = this->kineData.orientation;
    } else {
        
       
        if(directionMag != 0){
            directionNormalized = direction / directionMag;
        } else {
            directionNormalized = direction;
        }
        targetData.orientation = atan2(directionNormalized.y, directionNormalized.x);
    }


    //std::cout << "Target direction: [" << directionNormalized.x << ", " << directionNormalized.y << "]" << std::endl;
    //std::cout << "Target orientation: " << (targetData.orientation * 180 / M_PI) << std::endl;

    // Calculate angular acceleration
    SteeringData sDataAng = align.calculateAcceleration(this->kineData, targetData);

    //std::cout << "Received Acceleration: [" << sData.linearAcceleration.x << ", " << sData.linearAcceleration.y << "]" << std::endl;

    // Update Velocity and Rotation with Acceleration
    this->kineData.velocity += (float)deltaT * 0.001f * sDataLin.linearAcceleration;
    this->kineData.rotation += (float)deltaT * 0.001f * sDataAng.angularAcceleration;

    // Calculate proposed new position
    sf::Vector2f newPos = kineData.position + ((float)deltaT  * 0.001f * this->kineData.velocity);

    // Apply position constraints
    if(newPos.x < 0){
        newPos.x = 0;
    }
    if(newPos.x > C_WINWIDTH){
        newPos.x = C_WINWIDTH;
    }
    if(newPos.y < 0){
        newPos.y = 0;
    }
    if(newPos.y > C_WINHEIGHT){
        newPos.y = C_WINHEIGHT;
    }
    //std::cout << "current orientation: " << kineData.orientation << std::endl;
    //std::cout << "target orientation: " << targetData.orientation << std::endl;
    //std::cout << "angular acceleration: " << sDataAng.angularAcceleration << std::endl;

    // Apply velocity and rotation
    this->setPosition(newPos);
    this->rotate(((float)deltaT * 0.001f * this->kineData.rotation) * 180 / M_PI);

}

void AIDemoObject::setTargetData(KinematicData data){
    this->targetData = data;
}