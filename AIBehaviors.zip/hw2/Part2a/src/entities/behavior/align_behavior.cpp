#include "../behavior/align_behavior.hpp"

Align::Align(float maxRotation, float rDec, float rSat, float timeToTargetRotation){
    this->maxRotation = maxRotation;
    this->rDec = rDec;
    this->rSat = rSat;
    this->timeToTargetRotation = timeToTargetRotation;
}

SteeringData Align::calculateAcceleration(KinematicData character, KinematicData target){
    float rotation = target.orientation - character.orientation;
    rotation = GeneralTools::mapToRange(rotation);
    float rotationSize = abs(rotation);
    //std::cout << "Rotation size " << rotationSize << std::endl;
    float goalRot;
    if(rotationSize < rSat){
        goalRot = 0;
    } else if(rotationSize > rDec){
        goalRot = maxRotation;
    } else {
        goalRot = maxRotation * rotationSize / rDec;
    }

    if(rotationSize != 0){
        goalRot *= rotation / rotationSize;
    } else {
        goalRot = 0;
    }
    
    SteeringData output = SteeringData();
    output.angularAcceleration = goalRot - character.rotation;
    output.angularAcceleration /= timeToTargetRotation;
    return output;
}