#include <SFML/Graphics/CircleShape.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>

#ifndef CRUMB_H
#define CRUMB_H

//Breadcrumb class
class crumb : public sf::CircleShape
{
    public:
        crumb(int id);

        //tell breadcrumb to render self, using current render window
        void draw(sf::RenderWindow* window);

        //set position of breadcrumb
        void drop(float x, float y);

        //set position of breadcrumb
        void drop(sf::Vector2f position);

    private:
        int crumbId;
};

#endif