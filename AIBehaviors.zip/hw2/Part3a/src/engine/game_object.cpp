#include <SFML/Graphics/RectangleShape.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <string>
#include <cstring>
#include <iostream>
#include "../engine/game_object.hpp"

int GameObject::nextID = 0;
std::vector<GameObject*> GameObject::game_objects;

GameObject::GameObject(const sf::Vector2f& size, const sf::Vector2f& position, bool collidable)
{
    this->objectID = ++nextID;
    this->kineData = KinematicData();
    this->setPosition(position);
    kineData.position = position;
    setSize(size);
    this->collidable = collidable;
    this->colType = CollisionType::STANDARD;
    game_objects.push_back(this);
}

/**
 * Can read a formatted string into a GameObject.
*/
GameObject::GameObject(std::string rep)
{

    //Read ID
    std::string idRaw = rep.substr(rep.find("ID:") + 3, rep.find(";", rep.find("ID:")) - (rep.find("ID:") + 3));
    int readId = std::stoi(idRaw);
    this->objectID = readId;

    //Read Position
    std::string posXRaw = rep.substr(rep.find("Position:") + 9, rep.find(",", rep.find("Position:")) - (rep.find("Position:") + 9));
    float positionX = std::stof(posXRaw);
    std::string posYRaw = rep.substr(rep.find(",", rep.find("Position:")) + 1, rep.find(";", rep.find("Position:")) - (rep.find(",", rep.find("Position:")) + 1));
    float positionY = std::stof(posYRaw);
    //std::cout << "New Object Position: " << positionX << ", " << positionY << std::endl;
    this->setPosition(sf::Vector2f(positionX, positionY));

    //Read Size
    float sizeX = std::stof(rep.substr(rep.find("Size:") + 5, rep.find(",", rep.find("Size:")) - (rep.find("Size:") + 5)));
    float sizeY = std::stof(rep.substr(rep.find(",", rep.find("Size:")) + 1, rep.find(";", rep.find("Size:")) - (rep.find(",", rep.find("Size:")) + 1)));
    setSize(sf::Vector2f(sizeX, sizeY));

    //Read Velocity
    std::string velXRaw = rep.substr(rep.find("Velocity:") + 9, rep.find(",", rep.find("Velocity:")) - (rep.find("Velocity:") + 9)); 
    std::string velYRaw = rep.substr(rep.find(",", rep.find("Velocity:")) + 1, rep.find(";", rep.find("Velocity:")) - (rep.find(",", rep.find("Velocity:")) + 1));
    //std::cout << "New Object Velocity: " << velXRaw << ", " << velYRaw << std::endl;
    float velX = std::stof(velXRaw);
    float velY = std::stof(velYRaw);
    
    this->kineData.velocity = sf::Vector2f(velX, velY);

    // Read Collidable
    std::string collidableRaw = rep.substr(rep.find("Collidable:")+11, rep.find(";", rep.find("Collidable:")) - (rep.find("Collidable:")+11));
    //std::cout << "Collidable: " << collidableRaw << std::endl;
    this->collidable = std::stoi(collidableRaw);

    // Read Collision Type
    std::string colTypeRaw = rep.substr(rep.find("Collision Type:")+15, rep.find(";", rep.find("Collision Type:")) - (rep.find("Collision Type:")+15));
    //std::cout << "Collidable: " << collidableRaw << std::endl;
    this->colType = (CollisionType)std::stoi(colTypeRaw);

    // Read Should Render
    std::string renderRaw = rep.substr(rep.find("ShouldRender:")+13, rep.find(";", rep.find("ShouldRender:")) - (rep.find("ShouldRender:")+13));
    //std::cout << "Speed: " << speedRaw << std::endl;
    this->shouldRender = std::stoi(renderRaw);

    // Read Active
    std::string activeRaw = rep.substr(rep.find("Active:")+7, rep.find(";", rep.find("Active:")) - (rep.find("Active:")+7));
    //std::cout << "Speed: " << speedRaw << std::endl;
    this->active = std::stoi(activeRaw);

    // Read Speed
    std::string speedRaw = rep.substr(rep.find("Speed:")+6, rep.find(";", rep.find("Speed:")) - (rep.find("Speed:")+6));
    //std::cout << "Speed: " << speedRaw << std::endl;
    this->speed = std::stof(speedRaw);

    // Read Colors
    std::string rRaw = rep.substr(rep.find("Color:")+6,
                                 rep.find(",", rep.find("Color:")) - (rep.find("Color:")+6));
    std::string gRaw = rep.substr(rep.find(",", rep.find("Color:")) + 1,
                                  rep.find(",", rep.find(",", rep.find("Color:")) + 1) - (rep.find(",", rep.find("Color:") + 1) + 1));
    std::string bRaw = rep.substr(rep.find(",", rep.find(",", rep.find("Color:")) + 1) + 1,
                                  rep.find(";", rep.find("Color:")) - (rep.find(",", rep.find(",", rep.find("Color:")) + 1) + 1));
    //std::cout << "Color: r: " << rRaw << ", g: " << gRaw << ", b: " << bRaw << std::endl;
    int r = std::stoi(rRaw);
    int g = std::stoi(gRaw);
    int b = std::stoi(bRaw);
    this->setFillColor(sf::Color(r, g, b));

    if(rep.find("Texture:") != std::string::npos){
        this->textureLoc = rep.substr(rep.find("Texture:")+8, rep.find(";", rep.find("Texture:")) - (rep.find("Texture:")+8));
        if(objectTexture.loadFromFile(textureLoc)){
            this->setTexture(&objectTexture);
        }
    }

}

std::size_t GameObject::getPointCount() const
{
    return 4;
}

void GameObject::setTextureAddress(std::string &address){
    this->textureLoc.assign(address);
}

sf::Vector2f GameObject::getPoint(std::size_t index) const
{
    sf::Vector2f direction = sf::Vector2f(0.f, 0.f);

    switch(index) {
        case 0:
            direction.x = -m_size.x / 2;
            direction.y = m_size.y / 2;
            break;
        case 1:
            direction.x = -m_size.x / 2;
            direction.y = -m_size.y / 2;
            break;
        case 2:
            direction.x = m_size.x / 2;
            direction.y = -m_size.y / 2;
            break;
        case 3:
            direction.x = m_size.x / 2;
            direction.y = m_size.y / 2;
            break;
        default:
            break;
    }
    return direction;
}

/**
 * Creates a formatted String based on the GameObject's properties
*/
std::string GameObject::toString(){
    std::string rep = "{ID:" + std::to_string(this->getID()) +
                      ";Size:" + std::to_string(this->getSize().x) + "," + std::to_string(this->getSize().y) +
                      ";Position:"+ std::to_string(this->getPosition().x) + "," + std::to_string(this->getPosition().y)+
                      ";Velocity:"+ std::to_string(this->getVelocity().x) + "," + std::to_string(this->getVelocity().y)+
                      ";Collidable:" + std::to_string((int)this->collidable) +
                      ";Collision Type:" + std::to_string((int)this->colType) +
                      ";ShouldRender:" + std::to_string(this->shouldRender) +
                      ";Active:" + std::to_string(this->active) +
                      ";Speed:" + std::to_string(this->speed) +
                      ";Color:" + std::to_string(this->getFillColor().r) + "," + std::to_string(this->getFillColor().g) + "," + std::to_string(this->getFillColor().b);
    if(strcmp(this->textureLoc.c_str(), "null") != 0){
        rep += ";Texture:"+textureLoc;
    }
    rep += ";}";
    return rep;
}