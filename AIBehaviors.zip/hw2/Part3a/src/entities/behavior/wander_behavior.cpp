#include "../behavior/wander_behavior.hpp"
#include "../behavior/align_behavior.hpp"
#include "../behavior/arrive_behavior.hpp"
#include "../../handlers/general_tools.hpp"

Wander::Wander(float maxAcceleration, float maxVelocity, float maxRotation, float rDecLin, float rSatLin, float rDecAng, float rSatAng, float timeToTargetVelocity, float timeToTargetRotation, float wanderRate, float wanderOffset, float wanderRadius){
    this->maxVelocity = maxVelocity;
    this->maxRotation = maxRotation;
    this->rDecLin = rDecLin;
    this->rSatLin = rSatLin;
    this->rDecAng = rDecAng;
    this->rSatAng = rSatAng;
    this->timeToTargetVelocity = timeToTargetVelocity;
    this->timeToTargetRotation = timeToTargetRotation;
    this->wanderRate = wanderRate;
    this->wanderOffset = wanderOffset;
    this->wanderRadius = wanderRadius;
}

SteeringData Wander::calculateAcceleration(KinematicData character, KinematicData target){
    Align align = Align(maxRotation, rDecAng, rSatAng, timeToTargetRotation);
    Arrive arrive = Arrive(maxAcceleration, maxVelocity, rDecLin, rSatLin, timeToTargetVelocity);

    float wanderOrientation = GeneralTools::RandomBinomial() * wanderRate;
    
    target.orientation = wanderOrientation + character.orientation;
    
    target.position = character.position + wanderOffset * sf::Vector2f(cosf(character.orientation), sinf(character.orientation));
    target.position += wanderRadius * sf::Vector2f(cosf(target.orientation), sinf(target.orientation));

    // Calculate angular acceleration
    SteeringData sDataAng = align.calculateAcceleration(character, target);

    // Calculate linear acceleration
    SteeringData sDataLin = arrive.calculateAcceleration(character, target);

    SteeringData output = SteeringData();
    output.linearAcceleration = sDataLin.linearAcceleration;
    output.angularAcceleration = sDataAng.angularAcceleration;

    return output;
}