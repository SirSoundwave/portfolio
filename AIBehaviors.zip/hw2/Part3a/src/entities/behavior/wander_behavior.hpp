#include "../behavior/steering_behavior.hpp"

#ifndef WANDER_H
#define WANDER_H
class Wander : public SteeringBehavior {
    public:
        float maxAcceleration;
        float maxVelocity;
        float maxRotation;
        float rDecLin;
        float rSatLin;
        float rDecAng;
        float rSatAng;
        float timeToTargetVelocity;
        float timeToTargetRotation;
        float wanderRate;
        float wanderOffset;
        float wanderRadius;
        Wander(float maxAcceleration, float maxVelocity, float maxRotation, float rDecLin, float rSatLin, float rDecAng, float rSatAng, float timeToTargetVelocity, float timeToTargetRotation, float wanderRate, float wanderOffset, float wanderRadius);
        virtual SteeringData calculateAcceleration(KinematicData character, KinematicData target);
    protected:
        float mapToRange(float theta);
};
#endif