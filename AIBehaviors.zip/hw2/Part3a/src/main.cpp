#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <iostream>
#include <thread>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include "../src/engine/game_object.hpp"
#include "../src/environment/spawn_point.hpp"
#include "../src/entities/ai_demo_obj.hpp"
#include "../src/entities/behavior/velocity_match_behavior.hpp"
#include "../src/handlers/timeline.hpp"
#include "../src/handlers/general_tools.hpp"
#include "../src/handlers/event_manager.hpp"
#include "../src/handlers/remove_handler.hpp"


using namespace std;

/**
 * All references and tutorials are linked below:
 * 
 * SFML Documentation and Tutorials: https://www.sfml-dev.org/index.php
 * AABB Collision Logic Tutorial: https://trederia.blogspot.com/2016/02/2d-physics-101-pong.html
 * C++ enum Tutorial: https://www.programiz.com/cpp-programming/enumeration
 * C++ instanceof equivalent tutorial: https://stackoverflow.com/questions/500493/c-equivalent-of-javas-instanceof
 * C++ Singleton Tutorial: https://www.geeksforgeeks.org/implementation-of-singleton-class-in-cpp/
 * SFML Delta Time Tutorial 1: https://en.sfml-dev.org/forums/index.php?topic=7068.0
 * SFML Delta Time Tutorial 2: https://www.reddit.com/r/gamedev/comments/4c2ekd/what_is_the_best_way_to_work_out_delta_time/
 * 
 * This code is based on my submission for HW5 for CSC 481 (Game Engine Foundations).
*/


int main()
{

    // Constants for Demo Object size
    const float demoObjectWidth = 100;
    const float demoObjectHeight = 70;

    sf::RenderWindow window(sf::VideoMode(C_WINWIDTH, C_WINHEIGHT), "Homework 2", sf::Style::Resize); // Create the render window

    #pragma region handlers

    // Creates a new base Timeline with a tic rate of 2
    Timeline mainTimeline = Timeline(nullptr, 2);
    int64_t frame_delta = 0;

    EventManager* eventManager = new EventManager(&mainTimeline);


    #pragma endregion

    #pragma region gameObjects

    // Initialize Breadcrumbs
    std::vector<crumb> breadcrumbs = std::vector<crumb>();
    for(int i = 0; i < 10; i++)
    {
        crumb c = crumb(i);
        breadcrumbs.push_back(c);
    }

    // Initialize AI Demo Object
    AIDemoObject* demoObject = new AIDemoObject(sf::Vector2f(demoObjectWidth, demoObjectHeight), sf::Vector2f(C_WINWIDTH / 2, C_WINHEIGHT / 2), &breadcrumbs);
    sf::Texture demoObjectTexture;
    if(!demoObjectTexture.loadFromFile("resources/textures/entities/boid.png")){
        demoObject->setFillColor(sf::Color::Yellow);
    } else {
        demoObject->setTexture(&demoObjectTexture);
        std::string address = "resources/textures/entities/boid.png";
        demoObject->setTextureAddress(address);
    }

    #pragma endregion

    bool windowCloseFlag = false;


    int64_t last_time = mainTimeline.getTime();
    int64_t unscaled_last_time = mainTimeline.getTime();
    int64_t unaltered_frame_delta;

    bool focused = true;
    
    // run the program as long as the window is open
    while (window.isOpen())
    {
        

        // check all the window's events that were triggered since the last iteration of the loop (do this before restricting framerate to allow closing the window at any time)
        sf::Event* event = (sf::Event *) malloc(sizeof(sf::Event));
        while (window.pollEvent(*event))
        {

            // "close requested" event: we close the window
            if (event->type == sf::Event::Closed){
                cout << "Close requested" << std::endl;
                window.close();
                return 0;
            } else if(event->type == sf::Event::GainedFocus){
                focused = true;
            } else if(event->type == sf::Event::LostFocus){
                focused = false;
            }
        }

        // Wipe the window to white
        window.clear(sf::Color::White);

        // Get the Frame Delta
        int64_t current_time = mainTimeline.getTime();
        int64_t current_pauseless_time = mainTimeline.getPauselessTime();

        frame_delta = current_time - last_time; // Delta t in milliseconds
        unaltered_frame_delta = current_pauseless_time - unscaled_last_time;

        unscaled_last_time = current_pauseless_time;

        last_time = current_time;


        // Queue events raised in the last iteration and handle them.
        eventManager->PopulateQueue();
        eventManager->HandleEvents();
            

        //std::cout << "Mouse position: [" << mouseData.position.x << ", " << mouseData.position.y << "]" << std::endl;
        //std::cout << "Mouse velocity: [" << mouseData.velocity.x << ", " << mouseData.velocity.y << "]" << std::endl;

        

        // Update and draw all active GameObjects.
        for(std::vector<GameObject*>::iterator it = GameObject::game_objects.begin(); it!=GameObject::game_objects.end(); it++){
            GameObject toDraw = (**it);
            
            if(toDraw.getActive()){
                (*it)->Update(frame_delta);
                if(toDraw.getShouldRender()){
                    window.draw(toDraw);
                }              
            }
            
        }

        for(int i = 0; i < breadcrumbs.size(); i++)
        {
            breadcrumbs[i].draw(&window);
        }

        // Draw the current frame
        window.display();
        //cout << "frame ended" << std::endl;
    }
    return 0;
}