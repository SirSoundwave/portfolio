#include "../behavior/rotation_match_behavior.hpp"

RotationMatch::RotationMatch(float timeToTargetRotation){
    this->timeToTargetRotation = timeToTargetRotation;
}

SteeringData RotationMatch::calculateAcceleration(KinematicData character, KinematicData target){
    SteeringData output = SteeringData();
    output.angularAcceleration = target.rotation - character.rotation;
    output.angularAcceleration = mapToRange(output.angularAcceleration);
    output.angularAcceleration /= timeToTargetRotation;
    return output;
}

float RotationMatch::mapToRange(int theta){
    int out = fmod(theta, 2 * M_PI);
    if(abs(out) <= M_PI){
        return out;
    } else if(out > M_PI){
        return out - (2 * M_PI);
    } else {
        return out + (2 * M_PI);
    }
    
}