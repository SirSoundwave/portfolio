#include "../behavior/steering_behavior.hpp"
#include "../behavior/align_behavior.hpp"
#include "../../entities/ai_demo_obj.hpp"

#ifndef FLOCK_H
#define FLOCK_H
class Flock : public SteeringBehavior {
    public:
        float maxAcceleration;
        float minVelocity;
        float timeToTargetVelocity;
        float timeToTargetRotation;
        float rAvoid;
        float rFollow;

        float avoidFactor;
        float matchingFactor;
        float centeringFactor;

        float leftMargin;
        float topMargin;
        float rightMargin;
        float bottomMargin;
        float turningFactor;

        std::vector<AIDemoObject *>* boids;

        Flock(float maxAcceleration, float maxVelocity, float minVelocity, float timeToTargetVelocity, float timeToTargetRotation, float rAvoid, float rFollow, float avoidFactor, float matchingFactor, float centeringFactor, std::vector<AIDemoObject *>* boids, float leftMargin, float topMargin, float rightMargin, float bottomMargin, float turningFactor);
        virtual SteeringData calculateAcceleration(KinematicData character, KinematicData target);
};  
#endif