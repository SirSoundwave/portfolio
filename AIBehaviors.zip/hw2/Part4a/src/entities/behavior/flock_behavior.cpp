#include "../behavior/flock_behavior.hpp"

Flock::Flock(float maxAcceleration, float maxVelocity, float minVelocity, float timeToTargetVelocity, float timeToTargetRotation, float rAvoid, float rFollow, float avoidFactor, float matchingFactor, float centeringFactor, std::vector<AIDemoObject *>* boids, float leftMargin, float topMargin, float rightMargin, float bottomMargin, float turningFactor){
    this->maxAcceleration = maxAcceleration;
    this->maxVelocity = maxVelocity;
    this->minVelocity = minVelocity;
    this->timeToTargetVelocity = timeToTargetVelocity;
    this->timeToTargetRotation = timeToTargetRotation;
    this->rAvoid = rAvoid;
    this->rFollow = rFollow;
    this->avoidFactor = avoidFactor;
    this->matchingFactor = matchingFactor;
    this->centeringFactor = centeringFactor;
    this->boids = boids;
    this->leftMargin = leftMargin;
    this->topMargin = topMargin;
    this->rightMargin = rightMargin;
    this->bottomMargin = bottomMargin;
    this->turningFactor = turningFactor;
}

SteeringData Flock::calculateAcceleration(KinematicData character, KinematicData target){
    //cout << "Initial Position: <" << character.position.x << ", " << character.position.y << ">" << std::endl;
    sf::Vector2f closeVector = sf::Vector2f(0, 0);
    sf::Vector2f avgVelocity = sf::Vector2f(0, 0);
    sf::Vector2f avgPos = sf::Vector2f(0, 0);
    int numNeighboringBoids = 0;

    // Loop over all boids
    //cout << "number of boids: " << boids->size() << std::endl;
    //cout << "This ID: " << character.objID << std::endl;
    for(int i = 0; i < boids->size(); i++){
        
        GameObject other = *(boids->at(i));
        if(other.kineData.objID != character.objID){
            //cout << "other ID: " << other.kineData.objID << std::endl;
            // Calculate the vector to the center of the boids in avoidance range
            float distance = GeneralTools::EuclidianDistance(character.position, other.kineData.position);
            if(distance <= rAvoid){
                closeVector += character.position - other.kineData.position;
                //cout << "Updating Close vector: <" << closeVector.x << ", " << closeVector.y << ">" << std::endl;
            // Calculate the average velocity and position of neighboring boids
            } else if (distance <= rFollow){
                avgVelocity += other.kineData.velocity;
                avgPos += other.kineData.position;
                numNeighboringBoids++;
            }
        }
    }

    SteeringData output = SteeringData();

    sf::Vector2f goalVelocity = character.velocity;
    //cout << "This position: <" << character.position.x << ", " << character.position.y << ">" << std::endl;
    //cout << "This velocity: <" << character.velocity.x << ", " << character.velocity.y << ">" << std::endl;
    //cout << "Final Close vector: <" << closeVector.x << ", " << closeVector.y << ">" << std::endl;
    //cout << "Average velocity: <" << avgVelocity.x << ", " << avgVelocity.y << ">" << std::endl;
    //cout << "Average position: <" << avgPos.x << ", " << avgPos.y << ">" << std::endl;
    //cout << "Number of neighbors: " << numNeighboringBoids << std::endl;

    //float magnitudeAccumulator = 0;
    
    if(numNeighboringBoids > 0){
        avgVelocity /= (float)numNeighboringBoids;
        avgPos /= (float)numNeighboringBoids;
        float avgVelMag = GeneralTools::Magnitude(avgVelocity) * matchingFactor;
        float avgPosMag = GeneralTools::Magnitude(avgVelocity) * centeringFactor;
        goalVelocity += (avgVelocity - character.velocity) * matchingFactor;
        //magnitudeAccumulator += avgVelMag;
        //if(magnitudeAccumulator < maxAcceleration){
            goalVelocity += (avgPos - character.position) * centeringFactor;
            //magnitudeAccumulator += avgVelMag;
        //}
    }
    //if(magnitudeAccumulator < maxAcceleration){
        goalVelocity += closeVector * avoidFactor;
    //}
    
    //cout << "Goal velocity: <" << goalVelocity.x << ", " << goalVelocity.y << ">" << std::endl;

    if(character.position.x < leftMargin){
        goalVelocity.x  += turningFactor;
    } if(character.position.x > rightMargin){
        goalVelocity.x  -= turningFactor;
    } if(character.position.y < topMargin){
        goalVelocity.y  += turningFactor;
    } if(character.position.y > bottomMargin){
        goalVelocity.y  -= turningFactor;
    }

    float goalSpeed = sqrtf(pow(goalVelocity.x, 2) + pow(goalVelocity.y, 2));
    //cout << "Original Goal Speed: " << goalSpeed << std::endl;

    if(goalSpeed > maxVelocity){
        goalSpeed = maxVelocity;
    } else if(goalSpeed < minVelocity){
        goalSpeed = minVelocity;
    }

    //cout << "Limited Goal Speed: " << goalSpeed << std::endl;
    sf::Vector2f normalizedGoalVelocity = GeneralTools::Normalize(goalVelocity);

    //cout << "Normalized Goal Velocity: <" << normalizedGoalVelocity.x << ", " << normalizedGoalVelocity.y << ">" << std::endl;
    //cout << "Limited Goal Velocity: <" << (normalizedGoalVelocity * goalSpeed).x << ", " << (normalizedGoalVelocity * goalSpeed).y << ">" << std::endl;

    output.linearAcceleration = (normalizedGoalVelocity * goalSpeed - character.velocity) / timeToTargetVelocity;
    //cout << "Output linearAcceleration: <" << goalVelocity.x << ", " << goalVelocity.y << ">" << std::endl;
    Align align = Align(10, 2 * M_PI / 3, 0.05, timeToTargetRotation);
    KinematicData targetOrientation = KinematicData();
    targetOrientation.orientation = atan2(goalVelocity.y, goalVelocity.x);
    output.angularAcceleration = align.calculateAcceleration(character, targetOrientation).angularAcceleration;

    return output;
}