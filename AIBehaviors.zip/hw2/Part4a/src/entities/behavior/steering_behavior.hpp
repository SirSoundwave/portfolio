#include <SFML/Graphics.hpp>
#include <math.h>
#include <iostream>
#include "../../handlers/general_tools.hpp"

#ifndef STEERINGBEHAVIOR_H
#define STEERINGBEHAVIOR_H

struct KinematicData{
    sf::Vector2f position = sf::Vector2f(0, 0);
    float orientation = 0;
    sf::Vector2f velocity = sf::Vector2f(0, 0);
    float rotation = 0;
    int objID = 0;

    bool operator!=(const KinematicData& a){
        if(a.position == position && a.orientation == orientation && a.velocity == velocity && a.rotation == rotation){
            return false;
        }
        return true;
    }
};

struct SteeringData{
    sf::Vector2f linearAcceleration = sf::Vector2f(0, 0);
    float angularAcceleration = 0;
};

class SteeringBehavior {
    public:
        float maxVelocity;
        float maxRotation;
        virtual SteeringData calculateAcceleration(KinematicData character, KinematicData target) = 0;
};

#endif