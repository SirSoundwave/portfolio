#include <SFML/Graphics/RectangleShape.hpp>
#include <cmath>
#include <iostream>
#include "../entities/crumb.hpp"
#include "../entities/behavior/steering_behavior.hpp"
#include "../engine/game_object.hpp"
#include "../handlers/remove_event.hpp"
#include "../handlers/spawn_event.hpp"
#include "../handlers/event_manager.hpp"
#include "../handlers/general_tools.hpp"

using namespace std;
#ifndef AIDEMO_H
#define AIDEMO_H

class AIDemoObject : public GameObject
{
public:
    AIDemoObject(const sf::Vector2f& size, const sf::Vector2f& position, std::vector<crumb>* crumbs, SteeringBehavior &behavior);

    virtual void Update(int64_t deltaT);

    void setTargetData(KinematicData data);

    std::vector<crumb>* breadcrumbs;

private:
    KinematicData targetData;
    //point of breadcrumbs


    //indice variables
    int crumbIndex;

    int dropTimer;

    SteeringBehavior &behavior;
};

#endif