#include <SFML/Graphics/RectangleShape.hpp>
#include <cmath>
#include <iostream>
#include "../entities/behavior/velocity_match_behavior.hpp"
#include "../engine/game_object.hpp"
#include "../handlers/remove_event.hpp"
#include "../handlers/spawn_event.hpp"
#include "../handlers/event_manager.hpp"
#include "../handlers/general_tools.hpp"

using namespace std;
#ifndef AIDEMO_H
#define AIDEMO_H

class AIDemoObject : public GameObject
{
public:
    AIDemoObject(const sf::Vector2f& size = sf::Vector2f(0.f, 0.f), const sf::Vector2f& position = sf::Vector2f(0.f, 0.f));

    virtual void Update(int64_t deltaT);

    void setTargetData(KinematicData data);

private:
    KinematicData targetData;

};

#endif