#include "ai_demo_obj.hpp"


AIDemoObject::AIDemoObject(const sf::Vector2f& size, const sf::Vector2f& position)
{
    this->setPosition(position);
    setSize(size);
    this->collidable = true;
    this->colType = CollisionType::STANDARD;
    this->shouldRender = true;
    this->objectID = ++nextID;
}

void AIDemoObject::Update(int64_t deltaT){
    VelocityMatch behavior = VelocityMatch(0.1f);
    this->kineData.position = this->getPosition();
    this->kineData.rotation = this->getRotation();

    //std::cout << "Sent Target position: [" << targetData.position.x << ", " << targetData.position.y << "]" << std::endl;
    //std::cout << "Sent Target velocity: [" << targetData.velocity.x << ", " << targetData.velocity.y << "]" << std::endl;
    SteeringData sData = behavior.calculateAcceleration(this->kineData, targetData);

    //std::cout << "Received Acceleration: [" << sData.linearAcceleration.x << ", " << sData.linearAcceleration.y << "]" << std::endl;
    this->kineData.velocity += (float)deltaT  * 0.001f * sData.linearAcceleration;

    sf::Vector2f newPos = kineData.position + ((float)deltaT  * 0.001f * this->kineData.velocity);

    if(newPos.x < 0){
        newPos.x = 0;
    }
    if(newPos.x > C_WINWIDTH){
        newPos.x = C_WINWIDTH;
    }
    if(newPos.y < 0){
        newPos.y = 0;
    }
    if(newPos.y > C_WINHEIGHT){
        newPos.y = C_WINHEIGHT;
    }
    //std::cout << "New position: [" << newPos.x << ", " << newPos.y << "]" << std::endl;
    this->setPosition(newPos);

}

void AIDemoObject::setTargetData(KinematicData data){
    this->targetData = data;
}