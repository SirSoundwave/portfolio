#include "../behavior/steering_behavior.hpp"

#ifndef RMATCH_H
#define RMATCH_H
class RotationMatch : public SteeringBehavior {
    public:
        float timeToTargetRotation;
        RotationMatch(float timeToTargetRotation);
        virtual SteeringData calculateAcceleration(KinematicData character, KinematicData target);
};
#endif