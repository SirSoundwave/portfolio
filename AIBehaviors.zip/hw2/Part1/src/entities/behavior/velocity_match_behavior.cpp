#include "../behavior/velocity_match_behavior.hpp"

VelocityMatch::VelocityMatch(float timeToTargetVelocity){
    this->timeToTargetVelocity = timeToTargetVelocity;
}

SteeringData VelocityMatch::calculateAcceleration(KinematicData character, KinematicData target){
    SteeringData output = SteeringData();
    output.linearAcceleration = target.velocity - character.velocity;
    output.linearAcceleration /= timeToTargetVelocity;
    return output;
}