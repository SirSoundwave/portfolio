#include "../behavior/steering_behavior.hpp"

#ifndef ALIGN_H
#define ALIGN_H
class Align : public SteeringBehavior {
    public:
        float maxRotation;
        float rDec;
        float rSat;
        float timeToTargetRotation;
        Align(float maxRotation, float rDec, float rSat, float timeToTargetRotation);
        virtual SteeringData calculateAcceleration(KinematicData character, KinematicData target);
};
#endif