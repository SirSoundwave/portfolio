#include "../behavior/arrive_behavior.hpp"

Arrive::Arrive(float maxAcceleration, float maxVelocity, float rDec, float rSat, float timeToTargetVelocity){
    this->maxAcceleration = maxAcceleration;
    this->maxVelocity = maxVelocity;
    this->rDec = rDec;
    this->rSat = rSat;
    this->timeToTargetVelocity = timeToTargetVelocity;
}

SteeringData Arrive::calculateAcceleration(KinematicData character, KinematicData target){
    sf::Vector2f direction = target.position - character.position;
    float distance = sqrt(pow(direction.x, 2) + pow(direction.y, 2));
    float goalSpeed;
    if(distance <= rSat){
        goalSpeed = 0;
    } else if(distance > rDec){
        goalSpeed = maxVelocity;
    } else {
        goalSpeed = maxVelocity * distance/rDec;
    }
    sf::Vector2f goalVelocity = (direction / distance) * goalSpeed;
    SteeringData output = SteeringData();
    output.linearAcceleration = goalVelocity - character.velocity;
    output.linearAcceleration /= timeToTargetVelocity;
    return output;
}