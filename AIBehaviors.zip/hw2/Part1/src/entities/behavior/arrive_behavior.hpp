#include "../behavior/steering_behavior.hpp"

#ifndef ARRIVE_H
#define ARRIVE_H
class Arrive : public SteeringBehavior {
    public:
        float maxAcceleration;
        float rDec;
        float rSat;
        float timeToTargetVelocity;
        Arrive(float maxAcceleration, float maxVelocity, float rDec, float rSat, float timeToTargetVelocity);
        virtual SteeringData calculateAcceleration(KinematicData character, KinematicData target);
};
#endif