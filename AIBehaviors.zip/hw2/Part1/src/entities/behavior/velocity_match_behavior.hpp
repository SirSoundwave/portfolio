#include "../behavior/steering_behavior.hpp"


#ifndef VMATCH_H
#define VMATCH_H
class VelocityMatch : public SteeringBehavior {
    public:
        float timeToTargetVelocity;
        VelocityMatch(float timeToTargetVelocity);
        virtual SteeringData calculateAcceleration(KinematicData character, KinematicData target);
};
#endif