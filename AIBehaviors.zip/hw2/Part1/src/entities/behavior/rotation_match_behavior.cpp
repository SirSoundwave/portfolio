#include "../behavior/rotation_match_behavior.hpp"

RotationMatch::RotationMatch(float timeToTargetRotation){
    this->timeToTargetRotation = timeToTargetRotation;
}

SteeringData RotationMatch::calculateAcceleration(KinematicData character, KinematicData target){
    SteeringData output = SteeringData();
    output.angularAcceleration = target.rotation - character.rotation;
    output.angularAcceleration = GeneralTools::mapToRange(output.angularAcceleration);
    output.angularAcceleration /= timeToTargetRotation;
    return output;
}