#include "../handlers/remove_handler.hpp"

void RemoveHandler::OnEvent(Event event){
            if(event.GetType() == EventType::Remove){
                RemoveEvent rem = *(RemoveEvent*)&event;
                // Gets the id passed in the RemoveEvent.
                int idTmp = rem.getSource();
                // Removes and erases the object with the id passed in the RemoveEvent from the game_objects vector.
                GameObject::game_objects.erase(std::remove_if(GameObject::game_objects.begin(), GameObject::game_objects.end(), [&, idTmp](const GameObject* g){return g->getID() == idTmp;}), GameObject::game_objects.end());
            }
            
        }