#include "../handlers/spawn_event.hpp"

SpawnEvent::SpawnEvent(u_int64_t calledTime, int source){
    this->type = EventType::Spawn;
    this->calledTime = calledTime;
    this->sourceID = source;
}

std::string SpawnEvent::ToString() {
    return "{Type:" + std::to_string((int)this->type) +
            ";Called Time:" + std::to_string(this->calledTime); +
            ";Source ID:" + std::to_string(sourceID);
            "};";
}