#include "../handlers/general_tools.hpp"

float GeneralTools::RandomBinomial(){
    return random() - random();
}

float GeneralTools::mapToRange(float theta){
    float out = fmod(theta, 2 * M_PI);
    if(abs(out) <= M_PI){
        return out;
    } else if(out > M_PI){
        return out - (2 * M_PI);
    } else {
        return out + (2 * M_PI);
    }
}

float GeneralTools::EuclidianDistance(sf::Vector2f a, sf::Vector2f b){
    sf::Vector2f c = b - a;
    return Magnitude(c);
}

sf::Vector2f GeneralTools::Normalize(sf::Vector2f in){
    float magnitude = Magnitude(in);
    sf::Vector2f out;
    if(magnitude == 0){
        out = in;
    } else {
        out = in / magnitude;
    }
    
    return out;
}

float GeneralTools::Magnitude(sf::Vector2f in){
    return sqrtf(pow(in.x, 2) + pow(in.y, 2));
}