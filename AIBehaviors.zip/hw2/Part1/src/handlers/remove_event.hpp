#include "event.hpp"

#ifndef REMOVEEVENT_H
#define REMOVEEVENT_H

class RemoveEvent : public Event{
        public:
        RemoveEvent(u_int64_t calledTime, int source);

        virtual std::string ToString() override;
};

#endif