#include <SFML/System/Vector2.hpp>
#include <cmath>

#ifndef GENERALTOOLS_H
#define GENERALTOOLS_H

#define C_WINWIDTH 1280
#define C_WINHEIGHT 960

class GeneralTools{
    public:
        static float RandomBinomial();

        static float mapToRange(float theta);

        static float EuclidianDistance(sf::Vector2f a, sf::Vector2f b);

        static sf::Vector2f Normalize(sf::Vector2f in);

        static float Magnitude(sf::Vector2f in);
};

enum class CollisionType{
        NONE = 0,
        STANDARD = 1,
        DEATH = 2,
        SCROLL = 3,
        COUNT = 4
};

enum class Direction{
    UP = 0,
    RIGHT = 1,
    DOWN = 2,
    LEFT = 3,
    NONE = 4
};

struct CollisionData{
    Direction dir;
    CollisionType type;
};

#endif