#include "../handlers/remove_event.hpp"

RemoveEvent::RemoveEvent(u_int64_t calledTime, int source){
    this->type = EventType::Remove;
    this->calledTime = calledTime;
    this->sourceID = source;
}

std::string RemoveEvent::ToString(){
    return "{Type:" + std::to_string((int)this->type) +
            ";Called Time:" + std::to_string(this->calledTime); +
            ";Source ID:" + std::to_string(sourceID);
            "};";
}