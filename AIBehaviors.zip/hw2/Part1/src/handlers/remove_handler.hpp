#include "../engine/game_object.hpp"
#include "../handlers/remove_event.hpp"
#include "../handlers/event_manager.hpp"

#ifndef REMOVEHAND_H
#define REMOVEHAND_H

class RemoveHandler : public EventHandler{

    public:
        void OnEvent(Event event);

};




#endif