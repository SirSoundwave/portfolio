#include "event.hpp"
#include "../engine/game_object.hpp"

#ifndef SPAWNEVENT_H
#define SPAWNEVENT_H

    class SpawnEvent : public Event{
        public:
            SpawnEvent(u_int64_t calledTime, int source);

            virtual std::string ToString();
    };

#endif