#include <SFML/Graphics/RectangleShape.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <string>
#include "../handlers/event.hpp"
#include "../handlers/general_tools.hpp"
#include "../handlers/timeline.hpp"
#include "../entities/behavior/steering_behavior.hpp"
#include <iostream>

#ifndef GAME_OBJECT_H
#define GAME_OBJECT_H

class GameObject : public sf::RectangleShape
{
public :

    /**
     * Shared list of all instances of game objects...auto populated by the
     * constructor.
     */
    static std::vector<GameObject*> game_objects;

    explicit GameObject(const sf::Vector2f& size = sf::Vector2f(0.f, 0.f), const sf::Vector2f& position = sf::Vector2f(0.f, 0.f), bool collidable = false);

    GameObject(std::string rep);

    void setSize(const sf::Vector2f& size)
    {
        m_size = size;
        update();
    }

    const sf::Vector2f& getSize() const
    {
        return m_size;
    }

    virtual std::size_t getPointCount() const;

    virtual sf::Vector2f getPoint(std::size_t index) const;

    void setColor(sf::Color color)
    {
        this->color = color;
    }

    void setColor(int r, int g, int b, int a=255)
    {
        this->color = sf::Color(r, g, b, a);
    }

    sf::Color getColor()
    {
        return color;
    }

    sf::FloatRect getBoundingBox(){
        return getGlobalBounds();
    }

    void setVelocity(sf::Vector2f velocity){
        kineData.velocity = velocity;
    }

    sf::Vector2f getVelocity(){
        return kineData.velocity;
    }

    float getSpeed(){
        return this->speed;
    }

    bool getCollidable(){
        return collidable && active;
    }

    CollisionType getCollisionType() const{
        return colType;
    }

    void PreUpdate();

    virtual void Update(int64_t deltaT){
        //std::cout << "Shouldn't see this." << std::endl;
    }

    std::string toString();

    void setTextureAddress(std::string &address);

    static int getNextID(){
        nextID++;
        return nextID;
    }

    void setID(int id) {
        this->objectID = id;
    }


    int getID() const{
        return this->objectID;
    }

    bool getShouldRender(){
        return this->shouldRender;
    }

    void setTimeline(Timeline* timeline){
        this->timeline = timeline;
    }

    void setActive(bool active){
        this->active = active;
    }

    bool getActive(){
        return this->active;
    }

private :
    sf::Vector2f m_size;

    
    
protected :
    sf::Color color = sf::Color::Black;
    bool collidable;
    float speed = 0;
    std::string textureLoc = "null";
    sf::Texture objectTexture;
    CollisionType colType;
    static int nextID;
    int objectID;
    bool shouldRender;
    Timeline* timeline;
    bool active = true;
    KinematicData kineData;
};

#endif