#include <SFML/Graphics/RectangleShape.hpp>
#include <vector>
#include <functional>
#include "../entities/behavior/steering_behavior.hpp"
#include "../environment/graph/graph.hpp"
#include "../decision_making/decision_tree_node.hpp"

#ifndef DECISION_TREE_LEAF_H
#define DECISION_TREE_LEAF_H

template <typename T> class DecisionTreeLeaf : public DecisionTreeNode<T>{
    private:
        T output;
    public:
        DecisionTreeLeaf(T output) : output(output){
        }
        
        T Evaluate(T data) override{
            return this->output;
        }
};

#endif