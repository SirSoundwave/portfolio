#include <SFML/Graphics/RectangleShape.hpp>
#include <vector>
#include <functional>
#include "../entities/behavior/steering_behavior.hpp"
#include "../environment/graph/graph.hpp"

#ifndef DECISION_TREE_NODE_H
#define DECISION_TREE_NODE_H

template <typename T> class DecisionTreeNode{
    private:
        std::vector<DecisionTreeNode<T>*> children;
        std::function<T(T, std::vector<DecisionTreeNode<T>*>)> evaluate;
    public:
        DecisionTreeNode(){
            
        }

        DecisionTreeNode(std::vector<DecisionTreeNode<T>*> children, std::function<T(T,  std::vector<DecisionTreeNode<T>*>)> evaluate) : children(children), evaluate(evaluate){
            this->children = children;
            this->evaluate = evaluate;
        }

        virtual T Evaluate(T data){
            return evaluate(data, children);
        }
};

#endif