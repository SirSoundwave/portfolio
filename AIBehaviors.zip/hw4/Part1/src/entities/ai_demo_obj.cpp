#include "ai_demo_obj.hpp"


AIDemoObject::AIDemoObject(const sf::Vector2f& size, const sf::Vector2f& position, std::vector<crumb>* crumbs, SteeringBehavior &behavior, DecisionTreeNode<KinematicData> *targetSelectorTree)
: behavior(behavior), targetSelector(targetSelectorTree)
{
    crumbIndex = 0;
    dropTimer = 0;
    this->setPosition(position);
    KinematicData tempTarget = KinematicData();
    tempTarget.position = position;
    this->setTargetData(tempTarget);
    setSize(size);
    this->collidable = true;
    this->colType = CollisionType::STANDARD;
    this->shouldRender = true;
    this->objectID = ++nextID;
    this->breadcrumbs = crumbs;
}

void AIDemoObject::Update(int64_t deltaT){

    
    // Drop breadcrumb
    //basic timer for leaving breadcrumbs
    if (dropTimer > 0)
    {
        dropTimer -= deltaT;
    }
    else
    {
        dropTimer = 100.f;
        breadcrumbs->at(crumbIndex).drop(this->getPosition());

        if (crumbIndex < 9)
            crumbIndex++;
        else
            crumbIndex = 0;
    }

    // Update Kinematic Data
    this->kineData.position = this->getPosition();
    this->kineData.orientation = this->getRotation() * M_PI / 180;

    // Bounce at edges
    sf::Vector2f orientationVector = sf::Vector2f(cosf(this->kineData.orientation), sinf(this->kineData.orientation));
    if(kineData.position.x <= 0 || kineData.position.x >= C_WINWIDTH){
        kineData.orientation = atan2(orientationVector.y, -1 * orientationVector.x);
        kineData.velocity.x *= -1;
    }
    if(kineData.position.y <= 0 || kineData.position.y >= C_WINHEIGHT){
        kineData.orientation = atan2(-1 * orientationVector.y, orientationVector.x);
        kineData.velocity.y *= -1;
    }
    
    if(std::fabs(kineData.velocity.x) <= 1 && std::fabs(kineData.velocity.y) <= 1){
        std::cout << "Choosing new target" << std::endl;
        targetData = targetSelector->Evaluate(this->kineData);
        std::cout << "New target chosen! Position: <" << targetData.position.x << ", " << targetData.position.y << ">" << std::endl;
    } else {
        std::cout << "Current velocity <" << kineData.velocity.x << ", " << kineData.velocity.y << ">" << std::endl;
    }
    
    SteeringData sData = behavior.calculateAcceleration(this->kineData, targetData);



    //std::cout << "Received Acceleration: [" << sData.linearAcceleration.x << ", " << sData.linearAcceleration.y << "]" << std::endl;

    // Update Velocity and Rotation with Acceleration
    this->kineData.velocity += (float)deltaT * 0.001f * sData.linearAcceleration;
    this->kineData.rotation += (float)deltaT * 0.001f * sData.angularAcceleration;

    // Calculate proposed new position
    sf::Vector2f newPos = kineData.position + ((float)deltaT  * 0.001f * this->kineData.velocity);

    // Apply position constraints
    if(newPos.x < 0){
        newPos.x = 0;
    }
    if(newPos.x > C_WINWIDTH){
        newPos.x = C_WINWIDTH;
    }
    if(newPos.y < 0){
        newPos.y = 0;
    }
    if(newPos.y > C_WINHEIGHT){
        newPos.y = C_WINHEIGHT;
    }


    // Apply velocity and rotation
    this->setPosition(newPos);
    this->setRotation((kineData.orientation + (float)deltaT * 0.001f * this->kineData.rotation) * 180 / M_PI);

}

void AIDemoObject::setTargetData(KinematicData data){
    this->targetData = data;
}