#include <SFML/Graphics.hpp>

#ifndef VERTEX_H
#define VERTEX_H

class Edge;

class Vertex
{
    public:
        Vertex();
        Vertex(int id);
        Vertex(int id, sf::Vector2f position);

        std::map<Vertex, Edge> *getOutgoing();
        std::map<Vertex, Edge> *getIncoming();

        int getID() const;

        sf::Vector2f getPosition();

        bool operator < (const Vertex& other) const;
        bool operator == (const Vertex& other) const;

    private:
        // A map of outgoing edges keyed with the opposite vertex;
        std::map<Vertex, Edge> *outgoing;
        // A map of incoming edges keyed with the opposite vertex;
        std::map<Vertex, Edge> *incoming;

        sf::Vector2f position;
        int id;
};

#endif