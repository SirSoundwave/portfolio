#include "../graph/edge.hpp"
#include "../graph/vertex.hpp"

Edge::Edge(){
    this->weight = 0;
    this->endpoints = std::array<Vertex *, 2>();
}

Edge::Edge(float weight, Vertex *v1, Vertex *v2){
    this->weight = weight;
    this->endpoints = {v1, v2};
}

float Edge::getWeight() const{
    return this->weight;
}

bool Edge::operator< (const Edge& other) const{
    return this->getWeight() < other.getWeight();
}

bool Edge::operator== (const Edge& other) const{
    return (this->getWeight() < other.getWeight() && this->endpoints[0] == other.endpoints[0] && this->endpoints[1] == other.endpoints[1]);
}
