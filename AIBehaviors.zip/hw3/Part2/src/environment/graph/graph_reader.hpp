#include <iostream>
#include <fstream>
#include <sstream>
#include "../graph/graph.hpp"

#ifndef GRAPHREADER_H
#define GRAPHREADER_H

class GraphReader{
    public:
        static Graph ReadGraphFromFile(std::string filename, bool hasCoords);

        static Graph ReadGraphFromFile(std::string filename);
};

#endif