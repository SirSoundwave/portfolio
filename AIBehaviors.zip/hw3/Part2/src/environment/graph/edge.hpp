#include <array>
#include <SFML/Graphics.hpp>

#ifndef EDGE_H
#define EDGE_H

class Vertex;

class Edge
{
    public:
        Edge();
        Edge(float weight, Vertex *v1, Vertex *v2);

        float getWeight() const;

        bool operator < (const Edge& other) const;
        bool operator == (const Edge& other) const;
    private:
        float weight;
        std::array<Vertex *, 2> endpoints;

};

#endif