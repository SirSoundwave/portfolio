#include <list>
#include <array>
#include <SFML/Graphics.hpp>

#include "../graph/edge.hpp"
#include "../graph/vertex.hpp"

#ifndef GRAPH_H
#define GRAPH_H

class Graph
{
    public:
        Graph();

        int numVertices();

        std::map<int, Vertex *> vertices();

        int numEdges();

        std::list<Edge> edges();

        Edge getEdge(Vertex v1, Vertex v2);

        int outDegree(Vertex v);

        int inDegree(Vertex v);

        std::list<Edge> outgoingEdges(Vertex v);

        std::list<Edge> incomingEdges(Vertex v);

        Vertex *insertVertex(int id, sf::Vector2f position);

        Vertex *insertVertex(int id);

        Vertex *insertVertex(sf::Vector2f position);

        Edge insertEdge(Vertex *v1, Vertex *v2, float weight);

        void removeVertex(Vertex v);

        void removeEdge(Edge e);

    private:
        bool isDirected = true;
        std::map<int, Vertex*> vertexList;
        std::list<Edge> edgeList;
        int nextVertexID;
};

#endif