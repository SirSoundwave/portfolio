#include "../search/heuristic.hpp"
#include <math.h>
#include <iostream>

#ifndef EUCLIDHEURISTIC_H
#define EUCLIDHEURISTIC_H

class EuclideanHeuristic : public Heuristic{
    public:
        EuclideanHeuristic(Graph *graph);
        virtual float HFunction(Vertex current, Vertex goal);
};

#endif