#include "../search/manhattan_heuristic.hpp"

ManhattanHeuristic::ManhattanHeuristic(Graph *graph){
    this->graph = graph;
}

float ManhattanHeuristic::HFunction(Vertex start, Vertex goal){
    //std::cout << "Vertex "  <<  start.getID() << " (Start Position): <" << start.getPosition().x << ", " << start.getPosition().y << ">" << std::endl;
    //std::cout << "Vertex " << goal.getID() << " (End Position): <" << goal.getPosition().x << ", " << goal.getPosition().y << ">" << std::endl;
    sf::Vector2f travel = goal.getPosition() - start.getPosition();
    float distance = abs(travel.x) + abs(travel.y);
    //std::cout << "Distance: " << distance << std::endl;
    return distance;
}