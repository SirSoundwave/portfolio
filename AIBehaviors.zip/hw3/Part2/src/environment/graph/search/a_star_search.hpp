#include <iostream>
#include <set>
#include <cstring>
#include "../search/search.hpp"
#include "../search/heuristic.hpp"

#ifndef ASTARSEARCH_H
#define ASTARSEARCH_H

struct AStarNode{
    float cost;
    Vertex v;
    AStarNode *prev;
};

inline bool operator<(const AStarNode& x, const AStarNode& y){
    return x.cost < y.cost;
}

class AStarSearch : public Search{
    public:
        AStarSearch(Graph *graph, Heuristic *h);

        virtual std::list<Vertex> FindPath(Vertex start, Vertex goal);
    private:
        Heuristic *h;
};

#endif