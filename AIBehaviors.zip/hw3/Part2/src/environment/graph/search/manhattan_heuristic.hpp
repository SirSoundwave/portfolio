#include "../search/heuristic.hpp"
#include <math.h>
#include <iostream>

#ifndef MANHATTANHEURISTIC_H
#define MANHATTANHEURISTIC_H

class ManhattanHeuristic : public Heuristic{
    public:
        ManhattanHeuristic(Graph *graph);
        virtual float HFunction(Vertex current, Vertex goal);
};

#endif