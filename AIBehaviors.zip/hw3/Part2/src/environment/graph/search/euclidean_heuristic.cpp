#include "../search/euclidean_heuristic.hpp"

EuclideanHeuristic::EuclideanHeuristic(Graph *graph){
    this->graph = graph;
}

float EuclideanHeuristic::HFunction(Vertex start, Vertex goal){
    //std::cout << "Vertex "  <<  start.getID() << " (Start Position): <" << start.getPosition().x << ", " << start.getPosition().y << ">" << std::endl;
    //std::cout << "Vertex " << goal.getID() << " (End Position): <" << goal.getPosition().x << ", " << goal.getPosition().y << ">" << std::endl;
    sf::Vector2f travel = goal.getPosition() - start.getPosition();
    float distance = sqrtf(pow(travel.x, 2) + pow(travel.y, 2));
    //std::cout << "Distance: " << distance << std::endl;
    return distance;
}