#include <iostream>
#include <set>
#include <cstring>
#include <limits>
#include <set>
#include "../search/search.hpp"

#ifndef DJIKSTRASEARCH_H
#define DJIKSTRASEARCH_H

struct DjikstraNode{
    float cost;
    Vertex v;
    DjikstraNode *prev;
};

inline bool operator<(const DjikstraNode& x, const DjikstraNode& y){
    return x.cost < y.cost;
}

class DjikstraSearch : public Search{
    public:
        DjikstraSearch(Graph *graph);

        virtual std::list<Vertex> FindPath(Vertex start, Vertex goal);
};

#endif