#include "../graph.hpp"
#include "../vertex.hpp"
#include "../edge.hpp"

#ifndef HEURISTIC_H
#define HEURISTIC_H

class Heuristic{
    public:
        virtual float HFunction(Vertex current, Vertex goal) = 0;
    protected:
        Graph *graph;
};

#endif