#include <chrono>
#include <iostream>
#include "../graph.hpp"
#include "../vertex.hpp"
#include "../edge.hpp"

#ifndef SEARCH_H
#define SEARCH_H

class Search{
    public:
        virtual std::list<Vertex> FindPath(Vertex start, Vertex goal) = 0;
    protected:
        Graph *graph;
};

#endif