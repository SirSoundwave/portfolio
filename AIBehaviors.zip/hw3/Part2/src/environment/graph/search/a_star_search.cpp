#include "../search/a_star_search.hpp"

AStarSearch::AStarSearch(Graph *graph, Heuristic *h){
    this->graph = graph;
    this->h = h;
}

std::list<Vertex> AStarSearch::FindPath(Vertex start, Vertex goal){
    auto begin = std::chrono::high_resolution_clock::now();
    std::list<AStarNode> *closedList = new std::list<AStarNode>();
    std::multiset<AStarNode> openList = {(AStarNode){0, start, nullptr}};
    std::map<Vertex, float> g = std::map<Vertex, float>();
    std::map<Vertex, float> f = std::map<Vertex, float>();
    g[start] = 0;
    f[start] = g[start] + h->HFunction(start, start);

    int fringeCounter = 0;

    while(!openList.empty()){
        AStarNode m = *openList.begin();
        /*
        std::cout << "Current open list" << std::endl;
        for(std::multiset<AStarNode>::iterator it = openList.begin(); it != openList.end(); it++){
            std::cout << "Vertex: " << it->v.getID() << "; Cost: " << it->cost << std::endl;
        }*/
        //std::cout << "Traversing vertex: " << m.v.getID() << " with cost " << m.cost << std::endl;
        openList.erase(openList.lower_bound(m));
        closedList->emplace_back(m);
        if(m.v == goal){
            std::list<Vertex> *output = new std::list<Vertex>();
            AStarNode o = m;
            while(o.prev != nullptr){
                //std::cout << "Adding Vertex " << o.v.getID() << " to final path." << std::endl;
                output->emplace_front(o.v);
                o = *o.prev;
            }
            output->emplace_front(o.v);
            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - begin);
            fringeCounter += openList.size();
            std::cout << "A* search runtime = " << duration.count() << " microseconds." << std::endl;
            std::cout << "A* search fill = " << closedList->size() << " vertices." << std::endl;
            std::cout << "A* search fringe = " << fringeCounter << " vertices." << std::endl;
            return *output;
        }

        //std::cout << "Vertex " << m.v.getID() << " traversed." << std::endl;
        //std::cout << "Vertex " << m.v.getID() << " has " << m.v.getOutgoing()->size() << " children." << std::endl;
        for(std::map<Vertex, Edge>::iterator it = m.v.getOutgoing()->begin(); it != m.v.getOutgoing()->end(); it++){
            Vertex n = it->first;
            //std::cout << "Checking child vertex: " << n.getID() << std::endl;
            float cost = g[m.v] + it->second.getWeight();
            //std::cout << "Cost to reach current node: " << g[m.v] << std::endl;
            //std::cout << "Edge weight: " << it->second.getWeight() << std::endl;
            //std::cout << "Cost to reach child: " << cost << std::endl;
            //std::cout << "Documented cost to reach child: " << g[n] << std::endl;


            if((std::find_if(openList.begin(), openList.end(), [n](const AStarNode& element){return element.v == n;}) != openList.end()) && cost < g[n]){
                //std::cout << "Child found in open list" << n.getID() << std::endl;
                openList.erase(std::find_if(openList.begin(), openList.end(), [n](const AStarNode& element){return element.v == n;}));
            }
            if((std::find_if(closedList->begin(), closedList->end(), [n](const AStarNode& element){return element.v == n;}) != closedList->end()) && cost < g[n]){
                //std::cout << "Child found in closed list" << n.getID() << std::endl;
                closedList->erase(std::find_if(closedList->begin(), closedList->end(), [n](const AStarNode& element){return element.v == n;}));
            }
            if(!(std::find_if(closedList->begin(), closedList->end(), [n](const AStarNode& element){return element.v == n;}) != closedList->end()) && !(std::find_if(openList.begin(), openList.end(), [n](const AStarNode& element){return element.v == n;}) != openList.end())){                
                //std::cout << "Adding Vertex " << n.getID() << " to open list " << std::endl;
                g[n] = cost;
                f[n] = g[n] + h->HFunction(n, goal);
                AStarNode *temp = new AStarNode(m);
                openList.emplace((AStarNode){f[n], n, temp});
            }

        }
    }
    return {};
}