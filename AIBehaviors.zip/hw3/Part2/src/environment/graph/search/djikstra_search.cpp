#include "../search/djikstra_search.hpp"

DjikstraSearch::DjikstraSearch(Graph *graph){
    this->graph = graph;
}

std::list<Vertex> DjikstraSearch::FindPath(Vertex start, Vertex goal){
    auto begin = std::chrono::high_resolution_clock::now();
    std::multiset<DjikstraNode> *unknownNodeList = new std::multiset<DjikstraNode>();
    std::multiset<DjikstraNode> *knownNodeList = new std::multiset<DjikstraNode>();
    //std::cout << "populating lists" << std::endl;
    //std::cout << "Found " << graph->vertices().size() << " vertices" << std::endl;
    std::map<int, Vertex *> localMap = std::map<int, Vertex *>(graph->vertices());
    for(std::map<int, Vertex *>::iterator it = localMap.begin(); it != localMap.end(); it++){
        //std::cout << "Received vertex " << it->second->getID() << " to populate" << std::endl;
        if(it->second->getID() == start.getID()){
            //std::cout << "populating source node " << start.getID() << std::endl;
            unknownNodeList->insert(DjikstraNode{0, *(it->second), nullptr});
        } else {
            //std::cout << "populated node" << std::endl;
            unknownNodeList->insert(DjikstraNode{std::numeric_limits<float>::infinity(), *(it->second), nullptr});
            //std::cout << "inserted" << std::endl;
        }
    }
    std::multiset<DjikstraNode> *fullNodeList = new std::multiset<DjikstraNode>(*unknownNodeList);

    std::list<Vertex> *output = new std::list<Vertex>();
    DjikstraNode *n = new DjikstraNode(*unknownNodeList->begin());
    while(!unknownNodeList->empty()){
        /*
        std::cout << "Current unknown list" << std::endl;
        for(std::multiset<DjikstraNode>::iterator it = unknownNodeList->begin(); it != unknownNodeList->end(); it++){
            std::cout << "Vertex: " << (it)->v.getID() << "; Cost: " << (it)->cost << std::endl;
        }*/
        //std::cout << "fetching lowest cost unknown node" << std::endl;
        *n = *(unknownNodeList->begin());
        //std::cout << "erasing unknown node list entry" << std::endl;
        unknownNodeList->erase(unknownNodeList->begin());
        //std::cout << "marking node known" << std::endl;
        knownNodeList->insert(*n);
        //std::cout << "found " << n->v.getOutgoing()->size() <<  " node neighbors for node " << n->v.getID() << std::endl;
        for(std::map<Vertex, Edge>::iterator it = n->v.getOutgoing()->begin(); it != n->v.getOutgoing()->end(); it++){
            Vertex a = it->first;
            float alt = n->cost + it->second.getWeight();
            DjikstraNode *aNode = new DjikstraNode(*std::find_if(fullNodeList->begin(), fullNodeList->end(), [a](const DjikstraNode& element){return element.v == a;}));
            if(alt < aNode->cost){
                fullNodeList->erase(std::find_if(fullNodeList->begin(), fullNodeList->end(), [aNode](const DjikstraNode& element){return element.v.getID() == aNode->v.getID();}));
                unknownNodeList->erase(std::find_if(unknownNodeList->begin(), unknownNodeList->end(), [aNode](const DjikstraNode& element){return element.v.getID() == aNode->v.getID();}));
                //std::cout << "setting cost of " << aNode->v.getID() <<  " to " << alt << " and prev to " << n->v.getID() << std::endl;
                aNode->cost = alt;
                aNode->prev = new DjikstraNode(*n);
                //std::cout << "emplacing before Vertex " <<  (std::find_if(fullNodeList->begin(), fullNodeList->end(), [aNode](const DjikstraNode& element){return element.cost >= aNode->cost;}))->v.getID() << std::endl;
                unknownNodeList->insert(DjikstraNode(*aNode));
                fullNodeList->insert(DjikstraNode(*aNode));
            }
        }
    }
    *n = *std::find_if(fullNodeList->begin(), fullNodeList->end(), [goal](const DjikstraNode& element){return element.v == goal;});
    while(n->prev != nullptr){
        //std::cout << "Adding Vertex " << n->v.getID() << " to final path." << std::endl;
        output->emplace_front(n->v);
        n = n->prev;
    }
    output->emplace_front(n->v);
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - begin);
    std::cout << "Djikstra's search runtime = " << duration.count() << " microseconds." << std::endl;
    return *output;
}