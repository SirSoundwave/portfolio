#include "../graph/graph.hpp"

Graph::Graph(){
    vertexList = std::map<int, Vertex *>();
    edgeList = std::list<Edge>();
}

int Graph::numVertices(){
    return vertexList.size();
}

std::map<int, Vertex *> Graph::vertices(){
    return vertexList;
}

int Graph::numEdges(){
    return edgeList.size();
}

std::list<Edge> Graph::edges(){
    return edgeList;
}

Edge Graph::getEdge(Vertex v1, Vertex v2){
    return (*v1.getOutgoing())[v2];
}

int Graph::outDegree(Vertex v){
    return v.getOutgoing()->size();
}

int Graph::inDegree(Vertex v){
    return v.getIncoming()->size();
}

std::list<Edge> Graph::outgoingEdges(Vertex v){
    std::list<Edge> *edges = new std::list<Edge>();
    for(std::map<Vertex, Edge>::iterator it = v.getOutgoing()->begin(); it != v.getOutgoing()->end(); ++it){
        edges->push_back(it->second);
    }
    return *edges;
}

std::list<Edge> Graph::incomingEdges(Vertex v){
    std::list<Edge> *edges = new std::list<Edge>();
    for(std::map<Vertex, Edge>::iterator it = v.getIncoming()->begin(); it != v.getIncoming()->end(); ++it){
        edges->push_back(it->second);
    }
    return *edges;
}


Vertex *Graph::insertVertex(int id, sf::Vector2f position){
    vertexList.emplace(id, new Vertex(id, position));
    return vertexList[id];
}

Vertex *Graph::insertVertex(int id){
    return this->insertVertex(id, sf::Vector2f(0, 0));
}

Vertex *Graph::insertVertex(sf::Vector2f position){
    return this->insertVertex(nextVertexID++, position);
}

Edge Graph::insertEdge(Vertex *v1, Vertex *v2, float weight){
    float validatedWeight = weight;
    if(validatedWeight <= 0){
        validatedWeight = std::abs(validatedWeight) + 1;
    }

    Edge *e = new Edge(validatedWeight, v1, v2);
    edgeList.emplace_back(*e);
    if(vertexList.find(v1->getID()) != vertexList.end()){
        vertexList[v1->getID()]->getOutgoing()->emplace(*v2, *e);
    }
    if(vertexList.find(v2->getID()) != vertexList.end()){
        vertexList[v2->getID()]->getIncoming()->emplace(*v1, *e);
    }
    v1->getOutgoing()->emplace(*v2, *e);
    v2->getIncoming()->emplace(*v1, *e);
    return *e;
}

void Graph::removeVertex(Vertex v){
    for(std::map<Vertex, Edge>::iterator it = v.getOutgoing()->begin(); it != v.getOutgoing()->end(); ++it){
        removeEdge(it->second);
    }

    for(std::map<Vertex, Edge>::iterator it = v.getIncoming()->begin(); it != v.getIncoming()->end(); ++it){
        removeEdge(it->second);
    }

    vertexList.erase(v.getID());
}

void Graph::removeEdge(Edge e){
    edgeList.remove(e);
}