#include "../graph/graph_reader.hpp"

Graph GraphReader::ReadGraphFromFile(std::string filename, bool hasCoords){
    std::cout << "Reading graph" << std::endl;
    std::ifstream file(filename);

    Graph *graph = new Graph();
    
    if(file.is_open()){
        std::string line, v1ID, v2ID, edgeWeight, v1x, v1y, v2x, v2y;
        while(getline(file, line)){
            std::istringstream sline(line);

            //std::cout << "got line " << line << std::endl;

            getline(sline, v1ID, ',');
            v1ID.erase(std::remove_if(v1ID.begin(), v1ID.end(), isspace), v1ID.end());
            //std::cout << "Vertex 1: ID: " << v1ID << std::endl;
            getline(sline, v2ID, ',');
            v2ID.erase(std::remove_if(v1ID.begin(), v1ID.end(), isspace), v1ID.end());
            //std::cout << "Vertex 2: ID: " << v2ID << std::endl;
            
            if(hasCoords){
                getline(sline, edgeWeight, ',');
                //std::cout << "Edge Weight: " << edgeWeight << std::endl;
                getline(sline, v1x, ',');
                //std::cout << "Vertex 1 X position: " << v1x << std::endl;
                getline(sline, v1y, ',');
                //std::cout << "Vertex 1 Y position: " << v1y << std::endl;
                getline(sline, v2x, ',');
                //std::cout << "Vertex 2 X position: " << v2x << std::endl;
                getline(sline, v2y);
                //std::cout << "Vertex 2 Y position: " << v2y << std::endl;                

                //std::cout << "inserting Vertex 1" << std::endl;
                Vertex *v1 = graph->insertVertex(std::stoi(v1ID), sf::Vector2f(std::stof(v1x),std::stof(v1y)));
                //std::cout << "inserting Vertex 2" << std::endl;
                Vertex *v2 = graph->insertVertex(std::stoi(v2ID), sf::Vector2f(std::stof(v2x),std::stof(v2y)));
                //std::cout << "inserting Edge" << std::endl;
                graph->insertEdge(v1, v2, std::stof(edgeWeight));

            } else {
                getline(sline, edgeWeight);
                Vertex *v1 = graph->insertVertex(std::stoi(v1ID), sf::Vector2f(std::stoi(v1ID) % 1000, std::stoi(v1ID) / 1000));
                Vertex *v2 = graph->insertVertex(std::stoi(v2ID), sf::Vector2f(std::stoi(v2ID) % 1000, std::stoi(v2ID) / 1000));

                graph->insertEdge(v1, v2, std::stof(edgeWeight));
            }
        }
    } else {
        std::cout << "File " << filename << " failed to open" << std::endl;
    }

    return *graph;
}

Graph GraphReader::ReadGraphFromFile(std::string filename){
    return GraphReader::ReadGraphFromFile(filename, false);
}