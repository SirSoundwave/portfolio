#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <iostream>
#include <thread>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include "../src/engine/game_object.hpp"
#include "../src/environment/spawn_point.hpp"
#include "../src/entities/ai_demo_obj.hpp"
#include "../src/entities/behavior/flock_behavior.hpp"
#include "../src/handlers/timeline.hpp"
#include "../src/handlers/general_tools.hpp"
#include "../src/handlers/event_manager.hpp"
#include "../src/handlers/remove_handler.hpp"
#include "../src/environment/graph/graph.hpp"
#include "../src/environment/graph/graph_reader.hpp"
#include "../src/environment/graph/search/a_star_search.hpp"
#include "../src/environment/graph/search/euclidean_heuristic.hpp"
#include "../src/environment/graph/search/manhattan_heuristic.hpp"
#include "../src/environment/graph/search/djikstra_search.hpp"


using namespace std;

/**
 * All references and tutorials are linked below:
 * 
 * SFML Documentation and Tutorials: https://www.sfml-dev.org/index.php
 * AABB Collision Logic Tutorial: https://trederia.blogspot.com/2016/02/2d-physics-101-pong.html
 * C++ enum Tutorial: https://www.programiz.com/cpp-programming/enumeration
 * C++ instanceof equivalent tutorial: https://stackoverflow.com/questions/500493/c-equivalent-of-javas-instanceof
 * C++ Singleton Tutorial: https://www.geeksforgeeks.org/implementation-of-singleton-class-in-cpp/
 * SFML Delta Time Tutorial 1: https://en.sfml-dev.org/forums/index.php?topic=7068.0
 * SFML Delta Time Tutorial 2: https://www.reddit.com/r/gamedev/comments/4c2ekd/what_is_the_best_way_to_work_out_delta_time/
 * 
 * This code is based on my submission for HW5 for CSC 481 (Game Engine Foundations).
*/


int main()
{
    std::string smallGraphPath = "resources/SmallGraph.csv";
    std::string environmentGraphPath = "resources/EnvironmentGraph.csv";

    // Reads the small graph from the file into the Graph data structure
    cout << "Reading small graph." << std::endl;
    Graph smallGraph = GraphReader::ReadGraphFromFile(smallGraphPath, true);
    EuclideanHeuristic eHSmall = EuclideanHeuristic(&smallGraph);
    ManhattanHeuristic mHSmall = ManhattanHeuristic(&smallGraph);
    AStarSearch *euclidAStarSmall = new AStarSearch(&smallGraph, &eHSmall);
    AStarSearch *manhattanAStarSmall = new AStarSearch(&smallGraph, &mHSmall);


    std::list<Vertex> path1To13A = euclidAStarSmall->FindPath(*smallGraph.vertices()[1], *smallGraph.vertices()[13]);
    cout << "Calculated path from v1 to v13 using Euclidean Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = path1To13A.begin(); it != path1To13A.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> path1To13M = manhattanAStarSmall->FindPath(*smallGraph.vertices()[1], *smallGraph.vertices()[13]);
    cout << "Calculated path from v1 to v13 using Manhattan Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = path1To13M.begin(); it != path1To13M.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> path17To9A = euclidAStarSmall->FindPath(*smallGraph.vertices()[17], *smallGraph.vertices()[9]);
    cout << "Calculated path from v17 to v9 using Euclidean Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = path17To9A.begin(); it != path17To9A.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> path17To9M = manhattanAStarSmall->FindPath(*smallGraph.vertices()[17], *smallGraph.vertices()[9]);
    cout << "Calculated path from v17 to v9 using Manhattan Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = path17To9M.begin(); it != path17To9M.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> path23To1A = euclidAStarSmall->FindPath(*smallGraph.vertices()[23], *smallGraph.vertices()[1]);
    cout << "Calculated path from v23 to v1 using Euclidean Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = path23To1A.begin(); it != path23To1A.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> path23To1M = manhattanAStarSmall->FindPath(*smallGraph.vertices()[23], *smallGraph.vertices()[1]);
    cout << "Calculated path from v23 to v1 using Manhattan Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = path23To1M.begin(); it != path23To1M.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    cout << "Reading environment graph." << std::endl;
    Graph envGraph = GraphReader::ReadGraphFromFile(environmentGraphPath, true);
    EuclideanHeuristic eHEnv = EuclideanHeuristic(&envGraph);
    ManhattanHeuristic mHEnv = ManhattanHeuristic(&envGraph);
    AStarSearch *euclidAStarEnv = new AStarSearch(&envGraph, &eHEnv);
    AStarSearch *manhattanAStarEnv = new AStarSearch(&envGraph, &mHEnv);

    std::list<Vertex> pathEnv1To13A = euclidAStarEnv->FindPath(*envGraph.vertices()[1], *envGraph.vertices()[13]);
    cout << "Calculated path from v1 to v13 using Euclidean Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = pathEnv1To13A.begin(); it != pathEnv1To13A.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> pathEnv17To62A = euclidAStarEnv->FindPath(*envGraph.vertices()[17], *envGraph.vertices()[62]);
    cout << "Calculated path from v17 to v62 using Euclidean Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = pathEnv17To62A.begin(); it != pathEnv17To62A.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> pathEnv31To35A = euclidAStarEnv->FindPath(*envGraph.vertices()[31], *envGraph.vertices()[35]);
    cout << "Calculated path from v31 to v35 using Euclidean Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = pathEnv31To35A.begin(); it != pathEnv31To35A.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> pathEnv1To13M = manhattanAStarEnv->FindPath(*envGraph.vertices()[1], *envGraph.vertices()[13]);
    cout << "Calculated path from v1 to v13 using Manhattan Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = pathEnv1To13M.begin(); it != pathEnv1To13M.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> pathEnv17To62M = manhattanAStarEnv->FindPath(*envGraph.vertices()[17], *envGraph.vertices()[62]);
    cout << "Calculated path from v17 to v62 using Manhattan Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = pathEnv17To62M.begin(); it != pathEnv17To62M.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    std::list<Vertex> pathEnv31To35M = manhattanAStarEnv->FindPath(*envGraph.vertices()[31], *envGraph.vertices()[35]);
    cout << "Calculated path from v31 to v35 using Manhattan Heuristic: " << std::endl;
    for(std::list<Vertex>::iterator it = pathEnv31To35M.begin(); it != pathEnv31To35M.end(); it++){
        cout << (*it).getID() << std::endl;
    }

    // Saving SFML window for later parts so I don't have to copy it back in
    /*
    // Constants for Demo Object size
    const float demoObjectWidth = 100;
    const float demoObjectHeight = 70;

    sf::RenderWindow window(sf::VideoMode(C_WINWIDTH, C_WINHEIGHT), "Homework 3", sf::Style::Resize); // Create the render window

    #pragma region handlers

    // Creates a new base Timeline with a tic rate of 2
    Timeline mainTimeline = Timeline(nullptr, 2);
    int64_t frame_delta = 0;

    EventManager* eventManager = new EventManager(&mainTimeline);


    #pragma endregion

    #pragma region gameObjects

    std::vector<AIDemoObject *> boids = std::vector<AIDemoObject *>();
    //Flock flockBehavior = Flock(350, 850, 500, 0.15, 0.1, 150, 200, 3, 0.2, 1.2, &boids, 0, 0, C_WINWIDTH - 100, C_WINHEIGHT - 100, 10);
    Flock flockBehavior = Flock(200, 850, 550, 0.2, 0.1, 200, 250, 0.25, 0.5, 0.5, &boids, 200, 200, C_WINWIDTH - 200, C_WINHEIGHT - 200, 200);

    bool loadedFromFile = false;
    sf::Texture demoObjectTexture;

    if(!demoObjectTexture.loadFromFile("resources/textures/entities/boid.png")){
        loadedFromFile = false;
    } else {
        loadedFromFile = true;
    }
    // Initialize AI Demo Objects
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
                // Initialize Breadcrumbs
                std::vector<crumb>* breadcrumbs =  new std::vector<crumb>();
                for(int i = 0; i < 10; i++)
                {
                    crumb c = crumb(i);
                    breadcrumbs->push_back(c);
                }
                boids.push_back(new AIDemoObject(sf::Vector2f(demoObjectWidth, demoObjectHeight), sf::Vector2f((C_WINWIDTH / 2) + demoObjectWidth * (2 * (j - 1)) + random() / RAND_MAX * 50, (C_WINHEIGHT / 2)  + demoObjectHeight * (2 * (i - 1)) + random() / RAND_MAX * 50), breadcrumbs, flockBehavior));
                
                if(!loadedFromFile){
                    boids.back()->setFillColor(sf::Color::Yellow);
                } else {
                    boids.back()->setTexture(&demoObjectTexture);
                    std::string address = "resources/textures/entities/boid.png";
                    boids.back()->setTextureAddress(address);
                }
                boids.back()->kineData.velocity = sf::Vector2f(random() / RAND_MAX * 500, random() / RAND_MAX * 500);
                cout << "Created object id " << boids.back()->getID() << " at <" << boids.back()->getPosition().x << ", " << boids.back()->getPosition().y << ">" << std::endl;
        }
    }
    //boids.push_back(new AIDemoObject(sf::Vector2f(demoObjectWidth, demoObjectHeight), sf::Vector2f((C_WINWIDTH / 2) + demoObjectWidth * (2), (C_WINHEIGHT / 2) +  + demoObjectHeight * (-2)), &breadcrumbs, flockBehavior));

    #pragma endregion

    bool windowCloseFlag = false;


    int64_t last_time = mainTimeline.getTime();
    int64_t unscaled_last_time = mainTimeline.getTime();
    int64_t unaltered_frame_delta;

    bool focused = true;
    
    // run the program as long as the window is open
    while (window.isOpen())
    {
        

        // check all the window's events that were triggered since the last iteration of the loop (do this before restricting framerate to allow closing the window at any time)
        sf::Event* event = (sf::Event *) malloc(sizeof(sf::Event));
        while (window.pollEvent(*event))
        {

            // "close requested" event: we close the window
            if (event->type == sf::Event::Closed){
                cout << "Close requested" << std::endl;
                window.close();
                return 0;
            } else if(event->type == sf::Event::GainedFocus){
                focused = true;
            } else if(event->type == sf::Event::LostFocus){
                focused = false;
            }
        }

        // Wipe the window to white
        window.clear(sf::Color::White);

        // Get the Frame Delta
        int64_t current_time = mainTimeline.getTime();
        int64_t current_pauseless_time = mainTimeline.getPauselessTime();

        frame_delta = current_time - last_time; // Delta t in milliseconds
        unaltered_frame_delta = current_pauseless_time - unscaled_last_time;

        unscaled_last_time = current_pauseless_time;

        last_time = current_time;


        // Queue events raised in the last iteration and handle them.
        eventManager->PopulateQueue();
        eventManager->HandleEvents();
            

        //std::cout << "Mouse position: [" << mouseData.position.x << ", " << mouseData.position.y << "]" << std::endl;
        //std::cout << "Mouse velocity: [" << mouseData.velocity.x << ", " << mouseData.velocity.y << "]" << std::endl;

        

        // Update and draw all active GameObjects.
        for(std::vector<GameObject*>::iterator it = GameObject::game_objects.begin(); it!=GameObject::game_objects.end(); it++){
            GameObject toDraw = (**it);
            
            if(toDraw.getActive()){
                (*it)->Update(frame_delta);
                if(toDraw.getShouldRender()){
                    window.draw(toDraw);
                }              
            }
            
        }

        
        for(int i = 0; i < boids.size(); i++)
        {
            std::vector<crumb> crumbs = *boids.at(i)->breadcrumbs;
            for(int j = 0; j < crumbs.size(); j++){
                crumbs[j].draw(&window);
            }
             
        }

        // Draw the current frame
        window.display();
        //cout << "frame ended" << std::endl;
    }
    */
    return 0;
}