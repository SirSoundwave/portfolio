#include <SFML/Graphics.hpp>
#include <math.h>
#include <iostream>
#include "../graph/graph.hpp"

#ifndef GRAPHDIV_H
#define GRAPHDIV_H

class GraphDivider{
    public:
        GraphDivider(sf::Vector2f minPos, sf::Vector2f maxPos, float tileSize, Graph *graph);
        Vertex *Quantize(sf::Vector2f environmentCoords);
        sf::Vector2f *Localize(sf::Vector2f graphCoords);

    private:
        sf::Vector2f environmentSize, graphSize, minPos, maxPos;
        float tileSize;
        Graph *graph;
};

#endif