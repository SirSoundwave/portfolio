#include "edge.hpp"
#include "vertex.hpp"

Vertex::Vertex(){
    this->id = 0;
    this->position = sf::Vector2f(0, 0);
    this->outgoing = new std::map<Vertex, Edge>();
    this->incoming = new std::map<Vertex, Edge>();
}

Vertex::Vertex(int id, sf::Vector2f position){
    this->id = id;
    this->position = position;
    this->outgoing = new std::map<Vertex, Edge>();
    this->incoming = new std::map<Vertex, Edge>();
}

int Vertex::getID() const{
    return this->id;
}

std::map<Vertex, Edge> *Vertex::getOutgoing() const{
    return this->outgoing;
}

std::map<Vertex, Edge> *Vertex::getIncoming() const{
    return this->incoming;
}

sf::Vector2f Vertex::getPosition() const{
    return this->position;
}

bool Vertex::operator< (const Vertex& other) const{
    return this->getID() < other.getID();
}

bool Vertex::operator== (const Vertex& other) const{
    return this->getID() == other.getID();
}