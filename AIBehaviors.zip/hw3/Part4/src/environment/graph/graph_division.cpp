#include "../graph/graph_division.hpp"

GraphDivider::GraphDivider(sf::Vector2f minPos, sf::Vector2f maxPos, float tileSize, Graph *graph){
    this->minPos = minPos;
    this->maxPos = maxPos;
    this->tileSize = tileSize;
    this->graph = graph;
}

Vertex *GraphDivider::Quantize(sf::Vector2f environmentCoords){
    
    float graphX = roundf(std::min(maxPos.x, std::max(minPos.x, (roundf(environmentCoords.x)))) / tileSize);
    float graphY = roundf(std::min(maxPos.y, std::max(minPos.y, (roundf(environmentCoords.y)))) / tileSize);
    //std::cout << "Graph coordinates are <" << graphX << ", " << graphY << ">" << std::endl;
    std::map<int, Vertex *> vertices = graph->vertices();
    std::map<int, Vertex *>::iterator vertex = std::find_if(vertices.begin(), vertices.end(), [graphX, graphY](const std::pair<int, Vertex *> element){return (element.second->getPosition().x == graphX && element.second->getPosition().y == graphY);});
    if(vertex == vertices.end()){
        return nullptr;
    } else {
        return (vertex->second);
    }
}

sf::Vector2f *GraphDivider::Localize(sf::Vector2f graphCoords){
    float x = graphCoords.x * tileSize;
    float y = graphCoords.y * tileSize;
    return new sf::Vector2f(x, y);
}