#include "../behavior/steering_behavior.hpp"
#include "../behavior/arrive_behavior.hpp"
#include "../behavior/align_behavior.hpp"
#include <iostream>
#include <set>
#include <cstring>
#include "../../environment/graph/graph.hpp"
#include "../../environment/graph/search/search.hpp"
#include "../../environment/graph/graph_division.hpp"


#ifndef PATHFOLLOW_H
#define PATHFOLLOW_H

class PathFollow : public SteeringBehavior{
    public:
        PathFollow(float maxAcceleration, float maxVelocity, float rDec, float rSat, float timeToTargetVelocity, float timeToTargetRotation, Graph *graph, Search *searcher, GraphDivider *divider);
        virtual SteeringData calculateAcceleration(KinematicData character, KinematicData target);
    private:
        float maxAcceleration;
        float rDec;
        float rSat;
        float timeToTargetVelocity;
        float timeToTargetRotation;
        Graph *graph;
        Search *searcher;
        GraphDivider *divider;
        std::list<Vertex> currentPath;
        std::list<Vertex>::iterator currentPathPosition;
        Arrive *arrive;

};

#endif