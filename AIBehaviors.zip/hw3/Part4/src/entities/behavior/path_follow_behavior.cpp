#include "../behavior/path_follow_behavior.hpp"

PathFollow::PathFollow(float maxAcceleration, float maxVelocity, float rDec, float rSat, float timeToTargetVelocity, float timeToTargetRotation, Graph *graph, Search *searcher, GraphDivider *divider){
    this->maxAcceleration = maxAcceleration;
    this->maxVelocity = maxVelocity;
    this->rDec = rDec;
    this->rSat = rSat;
    this->timeToTargetVelocity = timeToTargetVelocity;
    this->timeToTargetRotation = timeToTargetRotation;
    this->graph = graph;
    this->searcher = searcher;
    this->divider = divider;
    this->currentPath = {};
    this->currentPathPosition = currentPath.end();
    this->arrive = new Arrive(maxAcceleration, maxVelocity, rDec, rSat, timeToTargetVelocity);
}

SteeringData PathFollow::calculateAcceleration(KinematicData character, KinematicData target){
    if(divider->Quantize(target.position) == nullptr){
        SteeringData output = SteeringData();
        output.linearAcceleration = (sf::Vector2f(0, 0) - character.velocity) / timeToTargetVelocity;
        Align align = Align(10, 2 * M_PI / 3, 0.05, timeToTargetRotation);
        KinematicData targetOrientation = KinematicData();
        targetOrientation.orientation = atan2(output.linearAcceleration.y, output.linearAcceleration.x);
        output.angularAcceleration = align.calculateAcceleration(character, targetOrientation).angularAcceleration;
        return output;
    }
    sf::Vector2f direction = *divider->Localize(divider->Quantize(target.position)->getPosition()) - character.position;
    float distance = sqrt(pow(direction.x, 2) + pow(direction.y, 2));
    std::cout << "Distance to target is " << distance << std::endl;
    if(distance <= rSat){
        //std::cout << "Distance is within rSat." << std::endl;
        SteeringData output = SteeringData();
        output.linearAcceleration = (sf::Vector2f(0, 0) - character.velocity) / timeToTargetVelocity;
        Align align = Align(10, 2 * M_PI / 3, 0.05, timeToTargetRotation);
        KinematicData targetOrientation = KinematicData();
        targetOrientation.orientation = atan2(output.linearAcceleration.y, output.linearAcceleration.x);
        output.angularAcceleration = align.calculateAcceleration(character, targetOrientation).angularAcceleration;
        return output;
    } else {
        //std::cout << "Distance is not within rSat." << std::endl;
        if(currentPathPosition == currentPath.end()){
            std::cout << "Calculating path from <" << character.position.x << ", " << character.position.y << "> to <" << target.position.x << ", " << target.position.y << ">" << std::endl;
            std::cout << "Start Vertex " << divider->Quantize(character.position)->getID() << std::endl;
            std::cout << "Goal Vertex " << divider->Quantize(target.position)->getID() << std::endl;
            this->currentPath = searcher->FindPath(*divider->Quantize(character.position), *divider->Quantize(target.position));
            std::cout << "Calculated path from character to target using A*: " << std::endl;
            for(std::list<Vertex>::iterator it = currentPath.begin(); it != currentPath.end(); it++){
                std::cout << (*it).getID() << std::endl;
            }
            currentPathPosition = currentPath.begin()++;
        }
        std::cout << "currently targeted vertex: " << currentPathPosition->getID() << std::endl;
        KinematicData currTarget = KinematicData();
        currTarget.position = *divider->Localize(currentPathPosition->getPosition());
        sf::Vector2f nextVertexDirection = currTarget.position - character.position;
        float nextVertexDistance = sqrt(pow(nextVertexDirection.x, 2) + pow(nextVertexDirection.y, 2));

        std::cout << "Distance to currently targeted vertex is " << nextVertexDistance << std::endl;
        if(nextVertexDistance <= rSat){
            
            currentPathPosition++;
            
        }
        SteeringData output = this->arrive->calculateAcceleration(character, currTarget);
        Align align = Align(10, 2 * M_PI / 3, 0.05, timeToTargetRotation);
        KinematicData targetOrientation = KinematicData();
        targetOrientation.orientation = atan2(nextVertexDirection.y, nextVertexDirection.x);
        output.angularAcceleration = align.calculateAcceleration(character, targetOrientation).angularAcceleration;
        return output;
        return this->arrive->calculateAcceleration(character, currTarget);
    }
}