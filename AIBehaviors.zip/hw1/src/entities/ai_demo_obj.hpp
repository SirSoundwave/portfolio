#include <SFML/Graphics/RectangleShape.hpp>
#include <cmath>
#include <iostream>
#include "../engine/game_object.hpp"
#include "../handlers/remove_event.hpp"
#include "../handlers/spawn_event.hpp"
#include "../handlers/event_manager.hpp"

using namespace std;
#ifndef AIDEMO_H
#define AIDEMO_H

class AIDemoObject : public GameObject
{
public:
    AIDemoObject(const sf::Vector2f& size = sf::Vector2f(0.f, 0.f), const sf::Vector2f& position = sf::Vector2f(0.f, 0.f), const sf::Vector2f targets[] = {}, int numTargets = 0, float speed = 1, EventManager* manager = nullptr, Timeline* timeline = nullptr, int spawnPointID = 0);

    sf::Vector2f getNextTarget(){
        return targets[targetIndex];
    }

    sf::Vector2f getPreviousTarget(){
        if(targetIndex == 0){
            return targets[numTargets - 1];
        }
        return targets[targetIndex];
    }

    virtual void Update(int64_t deltaT) override{
        sf::Vector2f next = getNextTarget();
        sf::Vector2f current = getPosition();

        double distance = sqrt(pow(next.x - current.x, 2) + pow(next.y - current.y, 2));

        if(distance <= (speed * deltaT)){
            sf::Vector2f movement = getNextTarget()-getPosition();
            if(targetIndex >= numTargets - 1){
                //std::cout << "queuing remove event" << std::endl;
                manager->QueueEvent(new RemoveEvent(timeline->getTime(), this->getID()));
                
                
                //targetIndex = 0;
            } else {
                if(targetIndex == 0 && !spawnedChild){
                    //std::cout << "queuing spawn event" << std::endl;
                    spawnedChild = true;
                    manager->QueueEvent(new SpawnEvent(timeline->getTime(), spawnPointID));                
                }
                this->rotate(90);
                
                targetIndex ++;
                //std::cout << "New Target Index: " << std::to_string(targetIndex) << "; x: " << std::to_string(targets[targetIndex].x) << ", y: " << std::to_string(targets[targetIndex].y) << std::endl;
            }
            velocity = movement;
        } else {
            sf::Transform t;
            sf::Vector2f movementDir = (next - current);
            double movementLen = sqrt(pow(movementDir.x, 2) + pow(movementDir.y, 2));

            sf::Vector2f movementNormalized = sf::Vector2f(movementDir.x / movementLen, movementDir.y / movementLen);

            double movementAmt = (speed * deltaT);

            velocity = sf::Vector2f(movementNormalized.x * movementAmt, movementNormalized.y * movementAmt);
        }

        //std::cout << "Current Position: x: " << std::to_string(current.x) << ", y: " << std::to_string(current.y) << std::endl;

        this->move(velocity);

    }

    void setSpeed(float speed){
        this->speed = speed;
    }

    void setTargets(const sf::Vector2f targetsIn[], int numTargets){
        targets = (sf::Vector2f *)malloc(sizeof(sf::Vector2f) * numTargets);
        for(int i = 0; i < numTargets; i++){
            targets[i] = targetsIn[i];
        }
    }

private:
    int targetIndex;
    int numTargets;
    sf::Vector2f *targets;
    EventManager* manager;
    int spawnPointID;
    bool spawnedChild = false;
};

#endif