#include <SFML/Graphics/RectangleShape.hpp>
#include "../engine/game_object.hpp"
#include "ai_demo_obj.hpp"


AIDemoObject::AIDemoObject(const sf::Vector2f& size, const sf::Vector2f& position, const sf::Vector2f targets[], int numTargets, float speed, EventManager* manager, Timeline* timeline, int spawnPointID)
{
    this->setPosition(position);
    setSize(size);
    setSpeed(speed);
    targetIndex = 0;
    this->numTargets = numTargets;
    setTargets(targets, numTargets);
    this->collidable = true;
    this->colType = CollisionType::STANDARD;
    this->shouldRender = true;
    this->manager = manager;
    this->spawnPointID = spawnPointID;
    this->timeline = timeline;
    this->objectID = ++nextID;
}