#include "timeline.hpp"
#include <chrono>

Timeline::Timeline(Timeline *anchor, int64_t tic)
{
    this->tic = tic;
    if(anchor == nullptr){ // If this timeline isn't anchored to anything, use system time.
        start_time = chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now().time_since_epoch()).count();
        baseTimeline = true;
    } else { // Link this timeline to its anchor.
        this->anchor = anchor;
        start_time = this->anchor->getTime();
        baseTimeline = false;
    }
    elapsed_paused_time = 0;
    last_paused_time = start_time;
}