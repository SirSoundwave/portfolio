#include "event.hpp"

Event::~Event()
{
}