#include <string.h>
#include <iostream>
#include <queue>
#include "event.hpp"
#include "../engine/game_object.hpp"
#include "timeline.hpp"
#include "event_handler.hpp"
#include <mutex>

#ifndef EVENTMANAGER_H
#define EVENTMANAGER_H

    using namespace std;

    struct EventCompare {
        bool operator()(const Event l, const Event r) const {return l.GetCalledTime() > r.GetCalledTime();};
    };

    class EventManager{
        private:
            std::map<EventType, std::vector<EventHandler*>> listeners;
            std::priority_queue<Event, std::vector<Event>, EventCompare> eventQueue;
            std::list<Event> preQueue;
            Timeline* timeline;
            std::mutex eventPreQueueLock;
            std::mutex eventQueueLock;

        public:
            EventManager(Timeline* timeline);

            void addListener(EventType type, EventHandler* obj){
                listeners[type].push_back(obj);
            }

            void QueueEvent(Event* const &event){
                //cout << "locking to queue" << std::endl;
                {
                    std::unique_lock<std::mutex> mutexLock1(this->eventPreQueueLock);
                    //cout << "locked to queue" << std::endl;
                    //cout << "preparing to queue event" << std::endl;
                    preQueue.push_front(*event);
                    //cout << "event queued" << std::endl;
                }
                //cout << "unlocked from queue" << std::endl;
            }

            void PopulateQueue(){
                {
                    //cout << "populating queue" << std::endl;
                    std::unique_lock<std::mutex> mutexLock1(this->eventPreQueueLock);
                    std::unique_lock<std::mutex> mutexLock2(this->eventQueueLock);
                    while(!preQueue.empty()){
                        eventQueue.push(preQueue.front());
                        preQueue.pop_front();
                    }
                    //cout << "finished populating queue" << std::endl;
                }
            }

            void SendEvent(Event event){
                //cout << "preparing to send event" << std::endl;
                if(listeners.find(event.GetType()) == listeners.end()){
                    //cout << "no listeners" << std::endl;
                    return;
                }
                for(auto&& listener : listeners.at(event.GetType())){
                    //cout << "sending to listeners " << ((GameObject *)event->getSource())->toString() << std::endl;
                    if(!event.Handled()){
                        listener->HearEvent(event);
                    }
                }
                event.Handle();
                //free(event);
                //cout << "event handled" << std::endl;
            }

            void HandleEvents(){
                //cout << "locking to handle" << std::endl;
                {
                    std::unique_lock<std::mutex> mutexLock2(this->eventQueueLock);
                    //cout << "locked to handle" << std::endl;
                    while(!eventQueue.empty() && eventQueue.top().GetCalledTime() <= timeline->getTime()){
                        //cout << "getting event to send" << std::endl;
                        //cout << "preparing event to raise" << std::endl;
                        Event toSend = eventQueue.top();
                        eventQueue.pop();
                        SendEvent(toSend);
                        toSend.Cleanup();
                        //cout << "event sent" << std::endl;
                    }
                }
                //cout << "unlocked from handle" << std::endl;
            }
    };

#endif