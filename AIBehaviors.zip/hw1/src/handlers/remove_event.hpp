#include "event.hpp"

#ifndef REMOVEEVENT_H
#define REMOVEEVENT_H

class RemoveEvent : public Event{
        public:
        RemoveEvent(u_int64_t calledTime, int source){
            this->type = EventType::Remove;
            this->calledTime = calledTime;
            this->sourceID = source;
        }

        virtual std::string ToString() override{
            return "{Type:" + std::to_string((int)this->type) +
                    ";Called Time:" + std::to_string(this->calledTime); +
                    ";Source ID:" + std::to_string(sourceID);
                    "};";
        }
};

#endif