#include <SFML/Graphics.hpp>
#include <string.h>
#include <iostream>
#include "enum_tools.hpp"

#ifndef EVENT_H
#define EVENT_H

    enum class EventType{
        Key,
        Collision,
        Death,
        Spawn,
        Remove
    };

    class Event{
        protected:
            EventType type;
            bool handled = false;
            u_int64_t calledTime;

            int sourceID;
            void* data;
        public:
            virtual~ Event();

            EventType GetType() const{
                return type;
            }

            bool Handled(){
                return handled;
            }

            void Handle(){
                handled = true;
            }

            u_int64_t GetCalledTime() const{
                return calledTime;
            }

            int getSource(){
                return sourceID;
            }
            void * getData(){
                return data;
            }


            virtual std::string ToString(){
                std::string output;
                switch (type)
                {
                case EventType::Collision :
                    output = "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime) +
                        ";Source ID:" + std::to_string(sourceID) +
                        ";Direction:" + std::to_string((int)(*(CollisionData*)this->data).dir) +
                        ";CollisionType:" + std::to_string((int)(*(CollisionData*)this->data).type) +
                        ";}";
                    break;
            
                case EventType::Death :
                    output = "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime) +
                        ";Source ID:" + std::to_string(sourceID);
                        ";}";
                    break;
                case EventType::Key :
                    output = "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime) +
                        ";Source ID:" + std::to_string(sourceID);
                        ";Key:" + std::to_string(*((sf::Keyboard::Key *)this->data)) +
                        ";}";
                    break;
                case EventType::Spawn :
                    output = "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime) +
                        ";Source ID:" + std::to_string((sourceID));
                        ";}";
                    break;
                default:
                    output = "should be overridden";
                    break;
                }
                return output;

            }
            void Cleanup(){
                //std::cout << "Client cleanup Event Type: " << (int)this->type << std::  endl;
                if(this->data != nullptr && (this->type != EventType::Death) && (this->type != EventType::Spawn) && this->type != EventType::Remove){
                    free(this->data);
                }
                //std::cout << "Client cleaned" << std::endl;
            }

    };



#endif