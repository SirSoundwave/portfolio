#include "../entities/ai_demo_obj.hpp"
#include "../handlers/spawn_event.hpp"
#include "../handlers/event_manager.hpp"

#ifndef SPAWNPOINT_H
#define SPAWNPOINT_H

class SpawnPoint : public GameObject, public EventHandler
{
public:
    SpawnPoint(const sf::Vector2f& position = sf::Vector2f(0.f, 0.f), AIDemoObject* blueprint = nullptr, EventManager* manager = nullptr);
    
    virtual void OnEvent(Event event) override{
        if(this->active){
            if(event.GetType() == EventType::Spawn){
                SpawnEvent spawn = *(SpawnEvent*)&event;
                // Spawns a new blueprint entity if the passed id matches the spawnpoint's.
                if(spawn.getSource() == this->getID()){
                    SpawnEntity();
                }
            }
            
            else if(event.GetType() == EventType::Remove){
                livingChildren--;
                if(livingChildren <= 0){
                    remainingSpawns = baseRemainingSpawns;
                    SpawnEntity();

                }
            }
        }
    }


private:
    /**
     * Spawns a new AIDemoObject matching the blueprint while assigning the next available GameObject ID.
    */
    void SpawnEntity(){
        if(remainingSpawns > 0){
            blueprint->setID(GameObject::getNextID());
            game_objects.push_back(new AIDemoObject(*blueprint));
            
            remainingSpawns--;
            livingChildren++;
        }
    }

    EventManager* manager;
    AIDemoObject* blueprint;
    int baseRemainingSpawns = 4;
    int remainingSpawns = 3;
    int livingChildren = 1;
};



#endif