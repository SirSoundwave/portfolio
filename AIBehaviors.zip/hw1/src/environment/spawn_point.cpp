    #include <SFML/Graphics/RectangleShape.hpp>
    #include "spawn_point.hpp"


    SpawnPoint::SpawnPoint(const sf::Vector2f& position, AIDemoObject* blueprint, EventManager* manager)
    {
        this->setPosition(position);
        setSize(sf::Vector2f(0, 0));
        this->collidable = false;
        this->colType = CollisionType::NONE;
        this->shouldRender = false;
        this->manager = manager;
        this->blueprint = (AIDemoObject *)malloc(sizeof(AIDemoObject));
        memcpy(this->blueprint, blueprint, sizeof(AIDemoObject));   
    }
