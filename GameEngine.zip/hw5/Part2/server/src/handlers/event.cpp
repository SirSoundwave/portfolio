#include "event.hpp"

int Event::counter = 0;


Event::~Event()
{
    this->handle = "event" + std::to_string(counter++);
}

void Event::setEventType(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<Event*>(ptr)->type = static_cast<EventType>(value->Int32Value());
}

void Event::getEventType(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	int type_val = static_cast<int>(static_cast<Event*>(ptr)->type);
	info.GetReturnValue().Set(type_val);
}

void Event::setEventHandled(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<Event*>(ptr)->handled = value->BooleanValue();
}

void Event::getEventHandled(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	int handled_val = static_cast<Event*>(ptr)->handled;
	info.GetReturnValue().Set(handled_val);
}

void Event::setEventCalledTime(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<Event*>(ptr)->calledTime = value->Uint32Value();
}

void Event::getEventCalledTime(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	int time_val = static_cast<Event*>(ptr)->calledTime;
	info.GetReturnValue().Set(time_val);
}

void Event::setEventSource(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	v8::String::Utf8Value utf8_str(info.GetIsolate(), value->ToString());
	static_cast<Event*>(ptr)->sourceGUID = *utf8_str;
}

void Event::getEventSource(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	std::string guid = static_cast<Event*>(ptr)->sourceGUID;
	v8::Local<v8::String> v8_guid = v8::String::NewFromUtf8(info.GetIsolate(), guid.c_str(), v8::String::kNormalString);
	info.GetReturnValue().Set(v8_guid);
}

void Event::setEventData(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
    std::string dt;
    switch (static_cast<Event*>(ptr)->type)
    {
    case EventType::Key :
        static_cast<Event*>(ptr)->data = (sf::Keyboard::Key *)malloc(sizeof(sf::Keyboard::Key));
        *(sf::Keyboard::Key *)(static_cast<Event*>(ptr)->data) = static_cast<sf::Keyboard::Key>(value->Uint32Value());
        break;
    case EventType::Collision :
        static_cast<Event*>(ptr)->data = (CollisionData *)malloc(sizeof(CollisionData));
        dt = static_cast<Event*>(ptr)->ToString();
        *(CollisionData *)static_cast<Event*>(ptr)->data = (CollisionData){(Direction)std::stoi(dt.substr(dt.find("Direction:") + 10, dt.find(";", dt.find("Direction:")) - (dt.find("Direction:") + 10))), (CollisionType)std::stoi(dt.substr(dt.find("Type:") + 5, dt.find(";", dt.find("Type:")) - (dt.find("Type:") + 5)))};
        break;
    default:
        
        break;
    }
	
}

void Event::getEventData(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	std::string guid = static_cast<Event*>(ptr)->sourceGUID;
	v8::Local<v8::String> v8_guid = v8::String::NewFromUtf8(info.GetIsolate(), guid.c_str(), v8::String::kNormalString);
	info.GetReturnValue().Set(v8_guid);
}

void Event::setEventHandle(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
    v8::String::Utf8Value utf8_str(info.GetIsolate(), value->ToString());
	static_cast<Event*>(ptr)->handle = *utf8_str;
}

void Event::getEventHandle(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	std::string handle_val = static_cast<Event*>(ptr)->handle;
    v8::Local<v8::String> v8_handle = v8::String::NewFromUtf8(info.GetIsolate(), handle_val.c_str(), v8::String::kNormalString);
	info.GetReturnValue().Set(v8_handle);
}

void Event::setEventCollisionDirection(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
    v8::String::Utf8Value utf8_str(info.GetIsolate(), value->ToString());
	static_cast<Event*>(ptr)->handle = *utf8_str;
}

void Event::getEventCollisionDirection(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
    int coldir = (int)(*(CollisionData *)static_cast<Event*>(ptr)->data).dir;
	info.GetReturnValue().Set(coldir);
}

void Event::setEventCollisionType(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
    v8::String::Utf8Value utf8_str(info.GetIsolate(), value->ToString());
	static_cast<Event*>(ptr)->handle = *utf8_str;
}

void Event::getEventCollisionType(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	int coltype = (int)(*(CollisionData *)static_cast<Event*>(ptr)->data).type;
	info.GetReturnValue().Set(coltype);
}

/**
 * Factory method for allowing javascript to create instances of native Events
 *
 * NOTE: Like with the setters above, this static function does have a return
 * type (and object), but the return value is placed in the function callback
 * parameter, not the native c++ return type.
 */
void Event::ScriptedEventFactory(const v8::FunctionCallbackInfo<v8::Value>& args)
{
	v8::Isolate *isolate = args.GetIsolate();
	v8::Local<v8::Context> context = isolate->GetCurrentContext();
	v8::EscapableHandleScope handle_scope(args.GetIsolate());
	v8::Context::Scope context_scope(context);

	std::string context_name("default");
	if(args.Length() == 1)
	{
		v8::String::Utf8Value str(args.GetIsolate(), args[0]);
		context_name = std::string(v8helpers::ToCString(str));
#if GO_DEBUG
		std::cout << "Created new object in context " << context_name << std::endl;
#endif
	}
	Event *new_event = new Event();
	new_event->type = (EventType)args[0]->Int32Value();
	new_event->calledTime = args[1]->IntegerValue();
	v8::String::Utf8Value utf8_str(isolate, args[3]->ToString());
	new_event->sourceGUID = *utf8_str;
	switch (new_event->type)
	{
	case EventType::Collision :
		new_event->data = (CollisionData *)malloc(sizeof(CollisionData));
		*(CollisionData *)(new_event->data) = (CollisionData){(Direction)args[4]->Int32Value(), (CollisionType)args[5]->Int32Value()};
		break;
	case EventType::Key :
		new_event->data = (sf::Keyboard::Key *)malloc(sizeof(sf::Keyboard::Key));
        *((sf::Keyboard::Key *)new_event->data) = (sf::Keyboard::Key)args[4]->Int32Value();
		break;
	case EventType::Chord :
		
		break;
	default:
		break;
	}

	v8::Local<v8::Object> v8_obj = new_event->exposeToV8(isolate, context);
	args.GetReturnValue().Set(handle_scope.Escape(v8_obj));
}

/**
 * IMPORTANT: Pay close attention to the definition of the std::vector in this
 * example implementation. The v8helpers::expostToV8 will assume you have
 * instantiated this exact type of vector and passed it in. If you don't the
 * helper function will not work. 
 */
v8::Local<v8::Object> Event::exposeToV8(v8::Isolate *isolate, v8::Local<v8::Context> &context, std::string context_name)
{
	std::vector<v8helpers::ParamContainer<v8::AccessorGetterCallback, v8::AccessorSetterCallback>> v;
	v.push_back(v8helpers::ParamContainer("type", getEventType, setEventType));
    v.push_back(v8helpers::ParamContainer("handled", getEventHandled, setEventHandled));
    v.push_back(v8helpers::ParamContainer("calledTime", getEventCalledTime, setEventCalledTime));
    v.push_back(v8helpers::ParamContainer("source", getEventSource, setEventSource));
    v.push_back(v8helpers::ParamContainer("data", getEventData, setEventData));
    v.push_back(v8helpers::ParamContainer("collisionType", getEventCollisionType, setEventCollisionType));
    v.push_back(v8helpers::ParamContainer("collisionDirection", getEventCollisionDirection, setEventCollisionDirection));
    v.push_back(v8helpers::ParamContainer("handle", getEventHandle, setEventHandle));
	return v8helpers::exposeToV8(handle, this, v, isolate, context, context_name);
}