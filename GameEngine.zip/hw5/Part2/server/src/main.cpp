#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <iostream>
#include <thread>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include <zmq.hpp>
#include <v8.h>
#include <libplatform/libplatform.h>

#include "../src/engine/game_object.hpp"

#include "../src/environment/platform.hpp"
#include "../src/environment/moving_platform.hpp"
#include "../src/environment/death_zone.hpp"
#include "../src/environment/scroll_zone.hpp"

#include "../src/handlers/timeline.hpp"
#include "../src/handlers/zhelpers.hpp"
#include "../src/handlers/collision_handler.hpp"
#include "../src/handlers/input_handler.hpp"
#include "../src/handlers/event_distributor.hpp"
#include "../src/handlers/event_manager.hpp"
#include "../src/handlers/remove_event.hpp"
#include "../src/handlers/script_event_handler.hpp"

#include "../src/v8/v8helpers.hpp"
#include "../src/v8/ScriptManager.h"


using namespace std;

/**
 * All references and tutorials are linked in the HW5 Reflection Document and below:
 * 
 * SFML Documentation and Tutorials: https://www.sfml-dev.org/index.php
 * AABB Collision Logic Tutorial: https://trederia.blogspot.com/2016/02/2d-physics-101-pong.html
 * C++ enum Tutorial: https://www.programiz.com/cpp-programming/enumeration
 * C++ instanceof equivalent tutorial: https://stackoverflow.com/questions/500493/c-equivalent-of-javas-instanceof
 * C++ Singleton Tutorial: https://www.geeksforgeeks.org/implementation-of-singleton-class-in-cpp/
 * SFML Delta Time Tutorial 1: https://en.sfml-dev.org/forums/index.php?topic=7068.0
 * SFML Delta Time Tutorial 2: https://www.reddit.com/r/gamedev/comments/4c2ekd/what_is_the_best_way_to_work_out_delta_time/
 * ZMQ guide: https://zguide.zeromq.org
 * ZMQ zhelpers.hpp header: https://github.com/booksbyus/zguide/tree/master
*/

void drawObjects(sf::RenderWindow *window, GameObject **objects, int numObjects){
    for(int j = 0; j < numObjects; j++){
        window->draw(*(objects[j]));
    }
}

class GameThread
{
    bool busy; // a member variable used to indicate thread "status"
    int i; // an identifier
    std::mutex *_mutex; // the object for mutual exclusion of execution
    std::condition_variable *_condition_variable; // for messaging between threads
    int numObjects;
    MovingPlatform **objects;
    int64_t *frame_delta;
    

    public:
        GameThread(int i, std::mutex *_mutex, std::condition_variable *_condition_variable, MovingPlatform **objects, int numObjects, int64_t *frame_delta)
        {
            this->i = i; // set the id of this thread
            this->_mutex = _mutex;
            this->_condition_variable = _condition_variable;
            this->objects = (MovingPlatform **)malloc(sizeof(MovingPlatform *) * numObjects);
            memcpy(this->objects, objects, sizeof(MovingPlatform *) * numObjects);
            this->numObjects = numObjects;
            this->frame_delta = frame_delta;

        }

        bool isBusy()
        {
            std::lock_guard<std::mutex> lock(*_mutex);  // this locks the mutuex until the variable goes out of scope (i.e., when the function returns in this case)
            return busy;
        }

        void run()
        {
            if(i==0)
            {
                try
                {
                    for(int j = 0; j < numObjects; j+=2){
                        {
                            //cout << "Locking platform thread" << std::endl;
                            std::unique_lock<std::mutex> cv_lock(*this->_mutex);
                            //cout << "Locked platform thread" << std::endl;
                            //cout << "Updating Platform " << j << std::endl;
                            objects[j]->Update(*frame_delta);
                            //cout << "Unlocked platform thread" << std::endl;
                        }
                    }
                    //cout << "Unlocked player thread" << std::endl;
                }
                catch (...)
                {
                    std::cerr << "Thread " << i << " caught exception." << std::endl;
                }
            }
            else // id == 1
            {
                try
                {
                    for(int j = 1; j < numObjects; j+=2){
                        {
                            //cout << "Locking platform thread" << std::endl;
                            std::unique_lock<std::mutex> cv_lock(*this->_mutex);
                            //cout << "Locked platform thread" << std::endl;
                            //cout << "Updating Platform " << j << std::endl;
                            objects[j]->Update(*frame_delta);
                            //cout << "Unlocked platform thread" << std::endl;
                        }
                    }


                }
                catch (...)
                {
                    std::cerr << "Thread " << i << " caught exception." << std::endl;
                }
            }
        }

};

/**
 * Wrapper function because threads can't take pointers to member functions.
 */
void run_wrapper(GameThread *fe)
{
    fe->run();
}

int main()
{

    zmq::context_t context(1);
    zmq::socket_t broker(context, ZMQ_ROUTER);

    std::map<std::string, int> clientNum;
    std::map<int, std::vector<GameObject *>> clientObjects;
    std::map<int, int64_t> playerLastSeen;
    std::map<int, EventManager*> individualEventManagers;

    broker.bind("tcp://*:5671"); // "ipc" doesn't yet work on windows.

    #pragma region gameObjects

    /*
     * NOTE: You must initialize v8 in main, otherwise handles will go out of scope.
     *
     * Contexts are generally on a per-thread basis, so if you would like to do 
     * script execution in a different thread, you must create a new context in
     * the other thread and give care to ensure the context doesn't go out of scope
     * before the thread's run function is called.
	 *
	 * The below v8 function calls are basically boilerplate. 
     */

    
    std::cout << "starting scripts" << std::endl;
    std::unique_ptr<v8::Platform> platform = v8::platform::NewDefaultPlatform();
    v8::V8::InitializePlatform(platform.release());
    v8::V8::InitializeICU();
    v8::V8::Initialize();
    v8::Isolate::CreateParams create_params;
    create_params.array_buffer_allocator = v8::ArrayBuffer::Allocator::NewDefaultAllocator();
    v8::Isolate *isolate = v8::Isolate::New(create_params);

    std::cout << "entering anonymous scope" << std::endl;
    { // anonymous scope for managing handle scope
        v8::Isolate::Scope isolate_scope(isolate); // must enter the virtual machine to do stuff
        v8::HandleScope handle_scope(isolate);

		// Best practice to install all global functions in the context ahead of time.
        v8::Local<v8::ObjectTemplate> global = v8::ObjectTemplate::New(isolate);
        // Bind the global 'print' function to the C++ Print callback.
        global->Set(isolate, "print", v8::FunctionTemplate::New(isolate, v8helpers::Print));
		// Bind the global static factory function for creating new GameObject instances
		global->Set(isolate, "gameobjectfactory", v8::FunctionTemplate::New(isolate, GameObject::ScriptedGameObjectFactory));
        global->Set(isolate, "eventfactory", v8::FunctionTemplate::New(isolate, Event::ScriptedEventFactory));
		// Bind the global static function for retrieving object handles
		global->Set(isolate, "gethandle", v8::FunctionTemplate::New(isolate, ScriptManager::getHandleFromScript));
        // Bind the global static function for retrieving the most recent exposed event
		global->Set(isolate, "geteventhandle", v8::FunctionTemplate::New(isolate, ScriptManager::getFirstEventFromScript));
        global->Set(isolate, "getcurrenttime", v8::FunctionTemplate::New(isolate, ScriptManager::getCurrentTime));
        v8::Local<v8::Context> default_context =  v8::Context::New(isolate, NULL, global);
		v8::Context::Scope default_context_scope(default_context); // enter the context

        ScriptManager *sm = new ScriptManager(isolate, default_context); 

        // Create a new context
		v8::Local<v8::Context> object_context = v8::Context::New(isolate, NULL, global);
		sm->addContext(isolate, object_context, "object_context");
        sm->addScript("create_object", "src/scripts/create_object.js");
        sm->addScript("update", "src/scripts/update.js");
        sm->addScript("initialize_environment", "src/scripts/initialize_environment.js");

        std::cout << "initializing environment" << std::endl;
        sm->runOne("initialize_environment", false);

        
        // Create a new context
		v8::Local<v8::Context> event_context = v8::Context::New(isolate, NULL, global);
		sm->addContext(isolate, event_context, "event_context");
        sm->addScript("handle_event", "src/scripts/handle_event.js");

        ScriptEventHandler* seHandler = new ScriptEventHandler(sm, isolate, &default_context, "default");
        

        std::cout << "finished scripts" << std::endl;


        #pragma endregion

        #pragma region handlers

        Timeline mainTimeline = Timeline(nullptr, 2); // Creates a new base Timeline with a tic rate of 2
        int64_t frame_delta = 0;

        EventManager* generalEventManager = new EventManager(&mainTimeline);

        generalEventManager->addListener(EventType::Collision, seHandler);
        generalEventManager->addListener(EventType::Key, seHandler);

        CollisionHandler* collisionHandler = CollisionHandler::getInstance();

        std::cout << "adding gos to env" << std::endl;
        std::vector<GameObject*> objects = GameObject::game_objects;
        for(std::vector<GameObject*>::iterator it = objects.begin(); it != objects.end(); it++){
            std::cout << "go: " << (*it)->toString() << std::endl;
            (*it)->exposeToV8(isolate, default_context);
        }

        collisionHandler->setEventManager(generalEventManager);
        collisionHandler->setTimeline(&mainTimeline);

        InputCheckerStruct inputChecker;

        EventDistributor* distributor = new EventDistributor();
        generalEventManager->addListener(EventType::Collision, distributor);

        #pragma endregion

        #pragma region threads

        // Mutex to handle locking, condition variable to handle notifications between threads
        std::mutex objectMutex;
        std::condition_variable objectCv;
        std::mutex timeMutex;
        std::condition_variable timeCv;
        /*
        GameThread evenThread(0, &objectMutex, &objectCv, dynamicObjects, numDynamicObjects, &frame_delta); //Player thread
        GameThread oddThread(1, &objectMutex, &objectCv, dynamicObjects, numDynamicObjects, &frame_delta); //Dynamic Platform thread (this will be more useful when there are more moving platforms)
        */

        #pragma endregion threads

        //cout << "Fetching initial time" << std::endl;

        int64_t last_time = mainTimeline.getTime();
        int64_t unscaled_last_time = mainTimeline.getTime();
        int64_t unaltered_frame_delta;
        int64_t inputDelay = 600;


        std::cout << "beginning main loop" << std::endl;
        // run the program as long as the window is open
        while (true)
        {


            checkInput(&inputChecker);
            //cout << "Loop start" << std::endl;

            std::list<string> toErase;
            if(clientNum.size() > 0){
                for(std::map<string, int>::iterator it = clientNum.begin(); it!=clientNum.end(); it++){
                    //cout << "Player " << it->second << " last seen " << std::to_string(mainTimeline.getTime() - playerLastSeen[it->second]) << std::endl;
                    if((mainTimeline.getTime() - playerLastSeen[it->second]) >= 3000){
                        toErase.push_front(it->first);
                    }
                }
            }

            if(clientNum.size() > 0){
                for(int i = 0; i < toErase.size(); i++){
                    string nextToEraseIdentity = toErase.front();
                    int nextToEraseIndex = clientNum[nextToEraseIdentity];
                    for(std::vector<GameObject *>::iterator it = clientObjects[nextToEraseIndex].begin(); it != clientObjects[nextToEraseIndex].end(); it++){
                        collisionHandler->removeObjectFromEnvironment((*it));
                    }
                    
                    clientNum.erase(nextToEraseIdentity);
                    clientObjects.erase(nextToEraseIndex);
                    playerLastSeen.erase(nextToEraseIndex);
                    for(std::map<int, EventManager*>::iterator it = individualEventManagers.begin(); it!=individualEventManagers.end(); it++){
                        it->second->QueueEvent(new RemoveEvent(mainTimeline.getTime(), std::to_string(nextToEraseIndex)));
                    }
                    if(clientNum.size() == 0){
                        cout << "closing server." << endl;

                        zmq_close(broker);
                        context.shutdown();
                        context.close();
                        cout << "Server closed." << endl;
                        return 0;
                    }
                }
            }

            //  Next message gives us least recently used worker
            //std::cout << "A" << std::endl;
            std::string identity;
            bool firstSeen = false;
            try{
                zmq::message_t message1;
                zmq::recv_result_t result1 = broker.recv(message1, zmq::recv_flags::dontwait);
                if(result1.value() < 0){
                    continue;
                }

                identity = std::string(static_cast<char*>(message1.data()), message1.size());
                
                if(clientNum.find(identity) == clientNum.end()){
                    std::cout << "First seen" << std::endl;
                    clientNum[identity] = GameObject::getNextID();
                    playerLastSeen[clientNum.find(identity)->second] = mainTimeline.getTime();
                    individualEventManagers[clientNum[identity]] = new EventManager(&mainTimeline);
                    individualEventManagers[clientNum[identity]]->addListener(EventType::Remove, distributor);
                    firstSeen = true;
                }
            } catch(const std::exception &exc){
                continue;
            }
            //td::cout << "B" << std::endl;



            zmq::message_t message3;
            //std::string blank = "";
            try{
                zmq::message_t message2;
                zmq::recv_result_t result2 = broker.recv(message2, zmq::recv_flags::dontwait);
                if(result2.value() < 0){
                    continue;
                }


                zmq::recv_result_t result3 = broker.recv(message3, zmq::recv_flags::dontwait);
                if(result3.value() < 0){
                    continue;
                }
            } catch(const std::exception &exc){
                continue;
            }
            
            std::string client_message = std::string(static_cast<char*>(message3.data()), message3.size());;
            //cout<<"receiving client message"<<std::endl;
            //s_recv(broker, zmq::recv_flags::dontwait);     //  Envelope delimiter
            //s_recv(broker, client_message, zmq::recv_flags::dontwait);     //  Response from worker
            //std::cout << "B.1" << std::endl;
            if(strcmp("closing", client_message.c_str()) == 0){
                cout<<"receiving client close message"<<std::endl;
                std::string blank = "";
                std::string closeMessage = "released";
                s_sendmore(broker, identity);
                s_sendmore(broker, blank);
                s_send(broker, closeMessage );
                int index = clientNum.find(identity)->second;
                clientNum.erase(identity);
                for(std::vector<GameObject *>::iterator it = clientObjects[index].begin(); it != clientObjects[index].end(); it++){
                    collisionHandler->removeObjectFromEnvironment((*it));
                }
                cout<<"server queuing remove event"<<std::endl;
                for(std::map<int, EventManager*>::iterator it = individualEventManagers.begin(); it!=individualEventManagers.end(); it++){
                    it->second->QueueEvent(new RemoveEvent(mainTimeline.getTime(), std::to_string(index)));
                }
                //generalEventManager->QueueEvent(new RemoveEvent(mainTimeline.getTime(), index));
                clientObjects.erase(index);
                playerLastSeen.erase(index);
                cout<<"client erased"<<std::endl;
                if(clientNum.size() == 0){
                    cout << "closing server." << endl;

                    zmq_close(broker);
                    context.shutdown();
                    context.close();
                    cout << "Server closed." << endl;
                    return 0;
                }
                continue;
            } else {
                if(firstSeen){
                    std::cout << "B.3" << std::endl;
                    int currentPos = 0;
                    int previousPos = 0;
                    std::cout << "message: " << client_message << std::endl;
                    // Get Gameobjects
                    while ((currentPos = client_message.find("|", previousPos + 1)) != std::string::npos) {
                        std::string token = client_message.substr(previousPos + 1, currentPos - previousPos);
                        //std::cout << "adding object " << token << std::endl;
                        GameObject * go = (new GameObject(token));
                        go->setID(GameObject::getNextID());
                        clientObjects[clientNum.find(identity)->second].push_back(go);
                        
                        clientObjects[clientNum.find(identity)->second].back()->exposeToV8(isolate, default_context);
                        //clientObjects[clientNum.find(identity)->second].setID(clientNum.find(identity)->second);
                        //collisionHandler->addObjectToEnvironment(clientObjects[clientNum.find(identity)->second].back());  

                        previousPos = currentPos;
                    }

                    
                    //std::cout << "B.4" << std::endl;  
                } else {
                    int currentPos = 0;
                    int previousPos = 0;

                    while ((currentPos = client_message.find("|", previousPos + 1)) != std::string::npos) {
                        std::string token = client_message.substr(previousPos + 1, currentPos - previousPos);

                        //Read ID
                        std::string guidRaw = token.substr(token.find("GUID:") + 5, token.find(";", token.find("GUID:")) - (token.find("GUID:") + 5));
                        //std::cout << "Server updating object " << token << std::endl;
                        int i = 0;
                        for(std::vector<GameObject *>::iterator it = clientObjects[clientNum.find(identity)->second].begin(); it != clientObjects[clientNum.find(identity)->second].end(); it++){
                            if((*it)->guid.compare(guidRaw) == 0){
                                (*it)->Update(token);
                                //(*it)->setID(clientNum.find(identity)->second + i);
                                i++;
                            }
                        }
                        //clientObjects[clientNum.find(identity)->second].;
                        previousPos = currentPos;
                    }
                }
                
                //std::cout << "B.5" << std::endl; 
                
            }
            //std::cout << "C" << std::endl;

            int64_t current_time = mainTimeline.getTime();
            int64_t current_pauseless_time = mainTimeline.getPauselessTime();

            frame_delta = current_time - last_time; // Delta t in milliseconds
            unaltered_frame_delta = current_pauseless_time - unscaled_last_time;
            inputDelay += unaltered_frame_delta;

            if(inputChecker.pressed1 && inputDelay > 60){
                mainTimeline.changeTic(1);
                inputDelay = 0;
            } else if(inputChecker.pressed2 && inputDelay > 60){
                mainTimeline.changeTic(2);
                inputDelay = 0;
            } else if(inputChecker.pressed3 && inputDelay > 60){
                mainTimeline.changeTic(4);
                inputDelay = 0;
            } else if(inputChecker.pressedPause && inputDelay > 300){
                if(!mainTimeline.isPaused()){
                    //cout << "pausing; Delay: " << inputDelay << std::endl;
                    mainTimeline.pause();
                    inputDelay = 0;
                    //continue;
                } else if(mainTimeline.isPaused() && mainTimeline.getElapsedPausedTime() > 300){
                    //cout << "Elapsed paused Time " << mainTimeline.getElapsedPausedTime() << std::endl;
                    //cout << "unpausing; Delay: " << inputDelay << std::endl;
                    mainTimeline.unpause();
                    inputDelay = 0;
                    //continue;
                }
                inputChecker.pressedPause = false;
            }

            unscaled_last_time = current_pauseless_time;

            last_time = current_time;

            int64_t player_frame_delta = current_time - playerLastSeen.find(clientNum.find(identity)->second)->second;
            playerLastSeen[clientNum.find(identity)->second] = current_time;
            
            //std::cout << "D" << std::endl;

            // Start movement threads
            /*
            std::thread first(run_wrapper, &evenThread);
            std::thread second(run_wrapper, &oddThread);

            // Make sure both threads are complete before stopping main thread
            first.join();
            second.join();
            */

            //std::cout << "E" << std::endl;

            //std::cout << "Checking collisions" << std::endl;
            collisionHandler->checkAllCollisionsWithEnvironment();
            //std::cout << "Collisions complete" << std::endl;
            //cout << "completed collision checks main" << std::endl;
            generalEventManager->PopulateQueue();
            generalEventManager->HandleEvents();

            individualEventManagers[clientNum.find(identity)->second]->PopulateQueue();
            individualEventManagers[clientNum.find(identity)->second]->HandleEvents();

            
            sm->runOne("update", false);
            
            std::string updates;

            updates += std::to_string(player_frame_delta); //This would be prettier in one line, but it's more efficient this way.
            updates += "|";
            updates += std::to_string(clientNum.find(identity)->second);
            updates += "|";
            
            // show content:
            for (std::map<std::string,int>::iterator it=clientNum.begin(); it!=clientNum.end(); ++it){
                for(std::vector<GameObject *>::iterator git = clientObjects[it->second].begin(); git != clientObjects[it->second].end(); git++){
                    updates += (*git)->toString();
                    updates += "|";
                }
                
            }
            std::vector<GameObject *> objects = GameObject::game_objects;
            for(std::vector<GameObject *>::iterator it = objects.begin(); it!=objects.end(); it++){
                updates += (*it)->toString();
                //std::cout << "Server Object sending: " << (*it)->toString() << std::endl;
                updates += "|";
            }
            updates += "~|";
            updates += distributor->getEventsToSend();
            distributor->cleanEventsToSend();

            std::string blank = "";
            s_sendmore(broker, identity);
            s_sendmore(broker, blank);
            s_send(broker, updates);
        }
        zmq_close(broker);
        zmq_ctx_destroy((void *)context);
        cout << "Server closed." << endl;   

    }

    isolate->Dispose();
    v8::V8::Dispose();
    v8::V8::ShutdownPlatform();


    return 0;
}