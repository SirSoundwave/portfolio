var ballSource = gethandle("ball");
print("ball invert Y is " + invertBallYVelocity);
print("ball invert X is " + invertBallXVelocity);
if(invertBallXVelocity){
    print("Entering X flip");
    print("Original ball velocity [" + ballSource.velocity_x + ", " + ballSource.velocity_y + "]");
    ballSource.velocity_x = -1 * ballSource.velocity_x;
    invertBallXVelocity = false;
    print("New ball velocity [" + ballSource.velocity_x + ", " + ballSource.velocity_y + "]");
}
if(invertBallYVelocity){
    print("Entering Y flip");
    print("Original ball velocity [" + ballSource.velocity_x + ", " + ballSource.velocity_y + "]");
    ballSource.velocity_y = -1 * ballSource.velocity_y;
    invertBallYVelocity = false;
    print("New ball velocity [" + ballSource.velocity_x + ", " + ballSource.velocity_y + "]");
}


ballSource.x = ballSource.x + ballSource.velocity_x * 10;
ballSource.y = ballSource.y + ballSource.velocity_y * 10;
print("New ball position [" + ballSource.x + ", " + ballSource.y + "]");