//
// This script calls gameobjectfactory() to create a new game object, and
// receives its handle. 
//
// NOTE: gameobjectfactory is a static function added to the global context in
// the native main() function
//
const brickIds = new Map();

const screenWidth = 800.0;
const screenHeight = 600.0;

const wallThickness = 30;
var lastEvent;

// Create boundaries
var leftWall = gameobjectfactory();

leftWall.size_x = wallThickness;
leftWall.size_y = screenHeight;
leftWall.x = 0;
leftWall.y = screenHeight / 2;
leftWall.r = 0;
leftWall.g = 0;
leftWall.b = 255;
leftWall.collidable = true;
leftWall.shouldRender = true;
leftWall.colType = 0;

var rightWall = gameobjectfactory();

rightWall.size_x = wallThickness;
rightWall.size_y = screenHeight;
rightWall.x = screenWidth;
rightWall.y = screenHeight / 2;
rightWall.r = 0;
rightWall.g = 0;
rightWall.b = 255;
rightWall.collidable = true;
rightWall.shouldRender = true;
rightWall.colType = 0;

var ceiling = gameobjectfactory();

ceiling.size_x = screenWidth;
ceiling.size_y = wallThickness;
ceiling.x = screenWidth / 2;
ceiling.y = 0;
ceiling.r = 0;
ceiling.g = 0;
ceiling.b = 255;
ceiling.collidable = true;
ceiling.shouldRender = true;
ceiling.colType = 0;


const numRows = 5;
const numColumns = 5;
const brickWidth = (screenWidth -  wallThickness)/numRows;
const brickHeight = (screenHeight/3 - wallThickness)/numColumns;
//Create bricks
for(var row = 0; row < numRows; row++){
    for(var column = 0; column < numColumns; column++){
        var brick = gameobjectfactory();
        brick.size_x = brickWidth;
        brick.size_y = brickHeight;
        brick.x = (column + 1/2) * brickWidth + wallThickness/2;
        brick.y = (row + 1/2) * brickHeight + wallThickness/2;
        brick.r = (row + 5) * 20;
        brick.g = (row + 2) * 10;
        brick.b = 4;
        brick.collidable = true;
        brick.shouldRender = true;
        brick.colType = 0;
        brick.active = true;
        brickIds.set(brick.guid, brick.guid);
        
    }
}
