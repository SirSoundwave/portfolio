var EventType = {
    Key: 0,
    Collision: 1,
    Death: 2,
    Spawn: 3,
    Remove: 4,
    Chord: 5
};

var CollisionType = {
    NONE: 0,
    STANDARD: 1,
    DEATH: 2,
    SCROLL: 3,
    COUNT: 4
};

var Direction = {
    UP: 0,
    RIGHT: 1,
    DOWN: 2,
    LEFT: 3,
    NONE: 4
};

var eventX = geteventhandle();

if(!eventX.handled){
    switch(eventX.type){
        case EventType.Collision:
            if(brickIds.has(eventX.source) && eventX.collisionType != CollisionType.COUNT){
                print("source brick is " + eventX.source);
                var brickSource = gethandle(eventX.source);
                print("handle: " + brickSource.guid);
                brickSource.active = false;
                brickSource.shouldRender = false;
            } else if(eventX.source == "ball"){
                print("ball collision");
                var ballSource = gethandle("ball");
                if(eventX.collisionDirection == Direction.UP || eventX.collisionDirection == Direction.DOWN){
                    var invertBallYVelocity = true;
                    print("ball invert Y is " + ballSource.invertYVelocity);
                } else {
                    var invertBallXVelocity = true;
                    print("ball invert X is " + ballSource.invertXVelocity);
                }
            }
            break;
        default:
            break;
    }
}
eventX.handled = true;
//lastEvent = geteventhandle();
//print("Got event of type " + eventX.type + " at time " + eventX.calledTime + " with handle " + eventX.handle);