#include <SFML/Graphics/RectangleShape.hpp>
#include "../engine/game_object.hpp"
#include "../handlers/collision_handler.hpp"
#include <SFML/Window/Keyboard.hpp>
#include <iostream>
#include "../handlers/input_handler.hpp"
#include "../handlers/window_handler.hpp"
#include <cmath>
#include "../handlers/event.hpp"
#include "../handlers/collision_event.hpp"
#include "../handlers/key_event.hpp"
#include "../handlers/event_handler.hpp"
#include "../handlers/death_event.hpp"
#include "../environment/spawn_point.hpp"
#include "../handlers/spawn_handler.hpp"
#include "../handlers/event_manager.hpp"

#ifndef PLAYER_H
#define PLAYER_H

using namespace std;

struct {
    bool up = false;
    bool down = false;
    bool right = false;
    bool left = false;
    bool collisionTypes[(int)CollisionType::COUNT];
} collisionChecks;  

class Player : public GameObject, public EventHandler
{
public:
    Player(const sf::Vector2f& size = sf::Vector2f(0.f, 0.f), const sf::Vector2f& position = sf::Vector2f(0.f, 0.f), float speed = 700.0f, float jumpPower = 700.0f, InputCheckerStruct *inputChecker = nullptr, EventManager* eventManager = nullptr, Timeline* timeline = nullptr, SpawnPoint* spawn = nullptr);

	/**
	 * Fetches the system's CollisionHandler instance to check environmental collisions
	*/
    void fetchCollisionHandler(){
        collisionHandler = CollisionHandler::getInstance();
    }

    void setSpeed(float speed){
        this->speed = speed;
    }

    void setJumpPower(float power){
        this->jumpPower = power;
    }

    void setGravityModifier(float grav){
        this->gravityModifier = grav;
    }

    void PreUpdate(){
        resetChecks();
        //collisionHandler->checkCollisionsWithEnvironment(this);
    }

	/**
	 * Called during each iteration of the main gameplay loop.
	*/
    void Update(int64_t deltaT){
        velocity = sf::Vector2f(0.0f, 0.0f);

		//Handle Moving Left
        if(inputChecker->pressedLeft && !collisionChecks.left)
        {
            //Move Left
            velocity -= sf::Vector2f(speed * deltaT, 0.0f);
        }

		//Handle Moving Right
        if(inputChecker->pressedRight && !collisionChecks.right)
        {
            //Move Right
            velocity += sf::Vector2f(speed * deltaT, 0.0f);
        }
        
		//Handle Jumping (if the player can jump and is pressing the jump key and is either grounded or still has jump time remaining)
		if(canJump && inputChecker->pressedJump && (collisionChecks.down || jumpTime > 0))
        {
           	//Jump
           	velocity -= sf::Vector2f(0.0f, jumpPower * deltaT);
        }

		//Handle gravity and the end of jumps
        if(!collisionChecks.down) //If the player isn't grounded
        {
			//If the jump ends and the player is still jumping
			if(jumpTime > 0 && canJump){
                
				jumpTime -= deltaT; //Decrease jump time remaining
				if(!sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){ //End the jump if th player isn't holding the jump button
					canJump = false;
				}
			} else { //Apply gravity if not jumping
				canJump = false;
				velocity += sf::Vector2f(0.0f, gravityModifier * deltaT);
			}    
        } else { //Reset the jump timer and flag if grounded
			jumpTime = jumpMillieconds;
			canJump = true;
		}
        
        GameObject* plat = collisionHandler->getCollidingWithEnvironment(this);
        if(plat != nullptr){ //Move the player if they are on a moving platform
            //cout << "Getting platform velocity X: " << std::to_string(plat->getVelocity().x) << ", Y: " << std::to_string(plat->getVelocity().y) << std::endl;
            sf::Vector2f platVelocity = plat->getVelocity();

            if(platVelocity.x != 0 || platVelocity.y != 0)
            {
                double movementLen = sqrt(pow(platVelocity.x, 2) + pow(platVelocity.y, 2));
                sf::Vector2f platVelocityNormalized = sf::Vector2f(platVelocity.x / movementLen, platVelocity.y / movementLen);
                double movementAmt = (plat->getSpeed() * deltaT);
                velocity += sf::Vector2f(platVelocityNormalized.x * movementAmt, platVelocityNormalized.y * movementAmt);
                //velocity += platVelocity;
            }

        }
        this->move(velocity);

        resetInputChecks(inputChecker);
    }

    virtual void OnEvent(Event event) override{
        //cout << "event received" << std::endl;
        if(this->active){
            if(event.GetType() == EventType::Collision){
                CollisionEvent collision = *(CollisionEvent*)&(event);
                std::string source = collision.getSource();
                if(source == this->guid){
                    switch (collision.getDirection())
                        {
                        case Direction::UP:
                            collisionChecks.up = true;
                            break;
                        case Direction::DOWN:
                            collisionChecks.down = true;
                            break;
                        case Direction::LEFT:
                            collisionChecks.left = true;
                            break;
                        case Direction::RIGHT:
                            collisionChecks.right = true;
                            break;
                        default:
                            break;
                        }
                        Event* event;
                        switch (collision.getCollisionType())
                        {
                        case CollisionType::STANDARD:
                            collisionChecks.collisionTypes[(int)CollisionType::STANDARD] = true;
                            break;
                        case CollisionType::DEATH:
                            collisionChecks.collisionTypes[(int)CollisionType::DEATH] = true;
                            std::cout << "player queuing death event" << std::endl;
                            event = new DeathEvent(this->timeline->getTime(), this->guid);
                            eventManager->QueueEvent(event);
                            std::cout << "player queued death event" << std::endl;
                            collision.Handle();
                            break;
                        case CollisionType::SCROLL:
                            std::cout << "scrolling" << std::endl;
                            collisionChecks.collisionTypes[(int)CollisionType::SCROLL] = true;
                            WindowHandler::GetInstance()->sideScroll(collision.getDirection());
                            directionBump(collision.getDirection(), 10);
                            break;
                        default:
                            break;
                        }
                }

            } else if(event.GetType() == EventType::Key){
                KeyEvent keyEvent = *(KeyEvent*)&event;
                updateInputCheck(inputChecker, keyEvent.getKey());
            } else if(event.GetType() == EventType::Chord){
                std::cout << "Chord Event!" << std::endl;
            }
        }
    }

    void directionBump(Direction dir, float amount){
        switch(dir){
            case Direction::UP:
                this->move(0, -1 * (amount + this->getSize().y));
                break;
            case Direction::DOWN:
                this->move(0, amount + this->getSize().y);
                break;
            case Direction::RIGHT:
                this->move(amount + this->getSize().x, 0);
                break;
            case Direction::LEFT:
                this->move(-1 * (amount + this->getSize().x), 0);
                break;
            default:
                break;
            }
    }

    void resetChecks(){
        collisionChecks.up = false;
        collisionChecks.down = false;
        collisionChecks.left = false;
        collisionChecks.right = false;
        for(int i = 0; i < (int)CollisionType::COUNT; i++){
            collisionChecks.collisionTypes[i] = false;
        }
    }

    void setSpawn(SpawnPoint* spawnPoint){
        this->spawn = spawnPoint;
        this->spawnHandler->setSpawn(this->spawn);
    }

    void setEventManager(EventManager* eventManager){
        this->eventManager = eventManager;
    }



private:
    float jumpPower;
    float gravityModifier;
    CollisionHandler *collisionHandler;
    bool canJump = false;
    float jumpTime = 100.0f;
    float jumpMillieconds = 100.0f;
    InputCheckerStruct *inputChecker;
    SpawnHandler* spawnHandler;
    EventManager* eventManager;
    SpawnPoint* spawn;
};

#endif