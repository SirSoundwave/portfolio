#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <iostream>
#include <thread>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include <zmq.hpp>
#include <v8.h>
#include <libplatform/libplatform.h>

#include "../src/engine/game_object.hpp"
#include "../src/entities/player.hpp"

#include "../src/handlers/timeline.hpp"
#include "../src/handlers/zhelpers.hpp"
#include "../src/handlers/collision_handler.hpp"
#include "../src/handlers/input_handler.hpp"
#include "../src/handlers/event_distributor.hpp"
#include "../src/handlers/event_manager.hpp"
#include "../src/handlers/remove_event.hpp"
#include "../src/handlers/script_event_handler.hpp"
#include "../src/handlers/chord_event.hpp"
#include "../src/handlers/event_receiver.hpp"

#include "../src/v8/v8helpers.hpp"
#include "../src/v8/ScriptManager.h"


using namespace std;

/**
 * All references and tutorials are linked in the HW5 Reflection Document and below:
 * 
 * SFML Documentation and Tutorials: https://www.sfml-dev.org/index.php
 * AABB Collision Logic Tutorial: https://trederia.blogspot.com/2016/02/2d-physics-101-pong.html
 * C++ enum Tutorial: https://www.programiz.com/cpp-programming/enumeration
 * C++ instanceof equivalent tutorial: https://stackoverflow.com/questions/500493/c-equivalent-of-javas-instanceof
 * C++ Singleton Tutorial: https://www.geeksforgeeks.org/implementation-of-singleton-class-in-cpp/
 * SFML Delta Time Tutorial 1: https://en.sfml-dev.org/forums/index.php?topic=7068.0
 * SFML Delta Time Tutorial 2: https://www.reddit.com/r/gamedev/comments/4c2ekd/what_is_the_best_way_to_work_out_delta_time/
 * ZMQ guide: https://zguide.zeromq.org
 * ZMQ zhelpers.hpp header: https://github.com/booksbyus/zguide/tree/master
*/

void checkKeyEvents(EventManager* eventManager, Timeline* timeline, vector<sf::Keyboard::Key> keys, vector<vector<sf::Keyboard::Key>> chordsToCheck){
    map<sf::Keyboard::Key, bool> keyHandled;
    for(sf::Keyboard::Key key : keys){
        keyHandled[key] = false;
    }
    for(vector<sf::Keyboard::Key> chord : chordsToCheck){
        bool chordComplete = true;
        for(int i = 0; i < chord.size(); i++){
            if((std::find(keys.begin(), keys.end(), chord[i]) == keys.end()) || !sf::Keyboard::isKeyPressed(chord[i]) || keyHandled[chord[i]]){
                chordComplete = false;
                break;
            }
        }
        if(chordComplete){
            //cout << "raising chord event" << std::endl;
            eventManager->QueueEvent(new ChordEvent(timeline->getTime(), chord));
            //cout << "raised chord event" << std::endl;
            for(int j = 0; j < chord.size(); j++){
                keyHandled[chord[j]] = true;
            }
            //cout << "marked chord keys handled" << std::endl;
        }

    }
    for(int k = 0; k < keys.size(); k++){
        if(sf::Keyboard::isKeyPressed(keys[k]) && !keyHandled[keys[k]]){
            eventManager->QueueEvent(new KeyEvent(timeline->getTime(), keys[k]));
            //cout << "raised key event for " << std::to_string(keys[k]) <<  std::endl;
        }
    }
}


int main()
{
    vector<sf::Keyboard::Key> keysToCheck = {
        sf::Keyboard::Left,
        sf::Keyboard::Right,
        sf::Keyboard::Up,
        sf::Keyboard::Down,
        sf::Keyboard::Up,
        sf::Keyboard::Num1,
        sf::Keyboard::Num2,
        sf::Keyboard::Num3,
        sf::Keyboard::P
    };

    vector<vector<sf::Keyboard::Key>> chordsToCheck = {
        {sf::Keyboard::Left, sf::Keyboard::Right,}
    };

    int numKeysToCheck = 9;

    sf::RenderWindow window(sf::VideoMode(800, 600), "Homework 5", sf::Style::Resize); // Create the render window

    WindowHandler* windowHandler = WindowHandler::GetInstance();
    windowHandler->setWindow(&window);

    InputCheckerStruct inputChecker;
    
/*
     * NOTE: You must initialize v8 in main, otherwise handles will go out of scope.
     *
     * Contexts are generally on a per-thread basis, so if you would like to do 
     * script execution in a different thread, you must create a new context in
     * the other thread and give care to ensure the context doesn't go out of scope
     * before the thread's run function is called.
	 *
	 * The below v8 function calls are basically boilerplate. 
     */

    
    std::cout << "starting scripts" << std::endl;
    std::unique_ptr<v8::Platform> platform = v8::platform::NewDefaultPlatform();
    v8::V8::InitializePlatform(platform.release());
    v8::V8::InitializeICU();
    v8::V8::Initialize();
    v8::Isolate::CreateParams create_params;
    create_params.array_buffer_allocator = v8::ArrayBuffer::Allocator::NewDefaultAllocator();
    v8::Isolate *isolate = v8::Isolate::New(create_params);

    std::cout << "entering anonymous scope" << std::endl;
    { // anonymous scope for managing handle scope
        v8::Isolate::Scope isolate_scope(isolate); // must enter the virtual machine to do stuff
        v8::HandleScope handle_scope(isolate);

		// Best practice to install all global functions in the context ahead of time.
        v8::Local<v8::ObjectTemplate> global = v8::ObjectTemplate::New(isolate);
        // Bind the global 'print' function to the C++ Print callback.
        global->Set(isolate, "print", v8::FunctionTemplate::New(isolate, v8helpers::Print));
		// Bind the global static factory function for creating new GameObject instances
		global->Set(isolate, "gameobjectfactory", v8::FunctionTemplate::New(isolate, GameObject::ScriptedGameObjectFactory));
        global->Set(isolate, "eventfactory", v8::FunctionTemplate::New(isolate, Event::ScriptedEventFactory));
		// Bind the global static function for retrieving object handles
		global->Set(isolate, "gethandle", v8::FunctionTemplate::New(isolate, ScriptManager::getHandleFromScript));
        // Bind the global static function for retrieving the most recent exposed event
		global->Set(isolate, "geteventhandle", v8::FunctionTemplate::New(isolate, ScriptManager::getFirstEventFromScript));
        global->Set(isolate, "getkeypressed", v8::FunctionTemplate::New(isolate, ScriptEventHandler::getKeyPressed));
        global->Set(isolate, "getcurrenttime", v8::FunctionTemplate::New(isolate, ScriptManager::getCurrentTime));
        global->Set(isolate, "raiseevent", v8::FunctionTemplate::New(isolate, ScriptEventHandler::ScriptedRaiseEvent));
        v8::Local<v8::Context> default_context =  v8::Context::New(isolate, NULL, global);
		v8::Context::Scope default_context_scope(default_context); // enter the context

        ScriptManager *sm = new ScriptManager(isolate, default_context); 
        

        // Create a new context
		v8::Local<v8::Context> object_context = v8::Context::New(isolate, NULL, global);
		sm->addContext(isolate, object_context, "object_context");
        sm->addScript("create_object", "src/scripts/create_object.js");
        sm->addScript("initialize_environment", "src/scripts/initialize_environment.js");
        sm->addScript("update", "src/scripts/update.js");
        sm->addScript("get_delta_time", "src/scripts/get_delta_time.js");
        
        // Create a new context
		v8::Local<v8::Context> event_context = v8::Context::New(isolate, NULL, global);
		sm->addContext(isolate, event_context, "event_context");
        sm->addScript("handle_event", "src/scripts/handle_event.js");
        sm->addScript("input_handler", "src/scripts/chord_handler.js");


        sm->addScript("initialize_environment", "src/scripts/initialize_environment.js");



        ScriptEventHandler* seHandler = new ScriptEventHandler(sm, isolate, &default_context, "default");
        

        std::cout << "finished scripts" << std::endl;


        #pragma region handlers

        Timeline mainTimeline = Timeline(nullptr, 2); // Creates a new base Timeline with a tic rate of 2
        sm->timeline = &mainTimeline;
        int64_t frame_delta = 0;

        EventManager* eventManager = new EventManager(&mainTimeline);
        ScriptEventHandler::em = eventManager;
        //KeyEventManager* keyEventManager = new KeyEventManager(&mainTimeline);
        EventReceiver* eventReceiver = new EventReceiver(eventManager, &mainTimeline);
        CollisionHandler* collisionHandler = CollisionHandler::getInstance();

        collisionHandler->setEventManager(eventManager);
        collisionHandler->setTimeline(&mainTimeline);
        eventManager->addListener(EventType::Remove, collisionHandler);

        //eventManager->addListener(EventType::Collision, seHandler);
        eventManager->addListener(EventType::Key, seHandler);
        eventManager->addListener(EventType::Chord, seHandler);

        #pragma endregion

        #pragma region gameObjects


        #pragma endregion

        bool windowCloseFlag = false;

        //cout << "Fetching initial time" << std::endl;

        int64_t last_time = mainTimeline.getTime();
        int64_t unscaled_last_time = mainTimeline.getTime();
        int64_t unaltered_frame_delta;
        int64_t inputDelay = 600;

        std::cout << "initializing environment" << std::endl;
        sm->runOne("initialize_environment", false);

        zmq::context_t context(1);
        zmq::socket_t worker(context, ZMQ_REQ);
        worker.connect("tcp://localhost:5671");
        bool focused = true;
        bool firstRun = true;
        // run the program as long as the window is open
        while (window.isOpen())
        {
            

            // check all the window's events that were triggered since the last iteration of the loop (do this before restricting framerate to allow closing the window at any time)
            sf::Event* event = (sf::Event *) malloc(sizeof(sf::Event));
            while (window.pollEvent(*event))
            {

                //cout << "Event polled" << std::endl;
                // "close requested" event: we close the window
                if (event->type == sf::Event::Closed){
                    cout << "Close requested" << std    ::endl;
                    window.close();
                    cout << "Close performed" << std::endl;
                    std::string closing = "closing";
                    s_send(worker, closing);
                    s_dump(worker);
                    zmq_close(worker);
                    context.shutdown();
                    context.close();
                    return 0;
                } else if(event->type == sf::Event::GainedFocus){
                    focused = true;
                } else if(event->type == sf::Event::LostFocus){
                    focused = false;
                }
            }
            if(focused)
                //checkKeyEvents(eventManager, &mainTimeline, keysToCheck, chordsToCheck);
                sm->runOne("input_handler", false);
                //checkInput(&inputChecker);

            //cout<<"Sending message to server" << std::endl;
            std::string send = "";
            
            for(std::vector<GameObject *>::iterator it = GameObject::game_objects.begin(); it!=GameObject::game_objects.end(); it++){
                send += (*it)->toString();
                //if((*it)->guid.compare("ball") == 0)
                    //std::cout << "Object sending to server: " << (*it)->toString() << std::endl;
                send += "|";
            }
            s_send(worker, send);

            std::string msg = s_recv(worker);
            
            //cout<<"Received message from server: " << msg << std::endl;
            window.clear(sf::Color::Black);

            //collisionHandler->initEnvironmentHolder();
            int currentPos = 0;
            int previousPos = 0;

            // Get player deltaT
            currentPos = msg.find("|", previousPos);
            std::string token = msg.substr(previousPos, currentPos - previousPos);
            int64_t playerDeltaT = std::stoi(token);
            previousPos = currentPos;

            currentPos = msg.find("|", previousPos + 1);
            //cout << "Previous position: " << previousPos << "; Current position: " << currentPos << std::endl;
            std::string tokenID = msg.substr(previousPos + 1, currentPos - (previousPos + 1));
            //cout << "Player ID: " << tokenID << std::endl;
            int newID = std::stoi(tokenID);
            
            //player.setID(newID);
            previousPos = currentPos;

            //cout << "Receiving frame delta: " << std::to_string(playerDeltaT) << std::endl;

            // Get Gameobjects
            while ((currentPos = msg.find("|", previousPos + 1)) != std::string::npos && msg.substr(previousPos + 1, currentPos - previousPos).find("~") == std::string::npos) {
                std::string token = msg.substr(previousPos + 1, currentPos - previousPos);


                //std::cout << "Client Object receiving: " << token << std::endl;
                //Read ID
                std::string idRaw = token.substr(token.find("ID:") + 3, token.find(";", token.find("ID:")) - (token.find("ID:") + 3));
                int readId = std::stoi(idRaw);
                std::string guidRaw = token.substr(token.find("GUID:") + 5, token.find(";", token.find("GUID:")) - (token.find("GUID:") + 5));

                if(collisionHandler->environmentContains(readId)){
                    //std::cout << "updating " << guidRaw << " in environment; ID: " << idRaw << std::endl;
                    collisionHandler->updateEnvironmentObject(readId, token);
                } else {
                    //std::cout << "adding " << guidRaw << " to environment; ID: " << idRaw << std::endl;
                    collisionHandler->addObjectToEnvironment(new GameObject(token));
                }
                
                for(std::vector<GameObject *>::iterator it = GameObject::game_objects.begin(); it!=GameObject::game_objects.end(); it++){
                    //std::cout << "comparing " << (*it)->guid << " to " << guidRaw << " With result " << std::to_string((*it)->guid.compare(guidRaw)) << std::endl;
                    if((*it)->guid.compare(guidRaw) == 0){
                        //std::cout << "Updating" << guidRaw << std::endl;
                        (*it)->Update(token);
                        //if((*it)->guid.compare("ball") == 0)
                        //    std::cout << "Object updated to" << (*it)->toString() << std::endl;
                    }
                }

                //cout << "Handling object: " << token << std::endl;
                

                //cout << "Object handled. Moving up string." << std::endl;
                previousPos = currentPos;
                //cout << "String moved up." << std::endl;
            }

                    //cout << "Loop start" << std::endl;
            int64_t current_time = mainTimeline.getTime();
            int64_t current_pauseless_time = mainTimeline.getPauselessTime();

            frame_delta = current_time - last_time; // Delta t in milliseconds
            unaltered_frame_delta = current_pauseless_time - unscaled_last_time;
            inputDelay += unaltered_frame_delta;
            //cout << "Delta T calculated as: " << (long)frame_delta << std::endl;

            unscaled_last_time = current_pauseless_time;

            last_time = current_time;

            currentPos = msg.find("~|");
            previousPos = currentPos+1;
            while ((currentPos = msg.find("|", previousPos + 1)) != std::string::npos) {
                std::string token = msg.substr(previousPos + 1, currentPos - previousPos);

                //cout << "Event: " << token << std::endl;
                eventReceiver->parseEvent(token);
                
                previousPos = currentPos;
            }

            //cout << "End server events" << std::endl;

            eventManager->PopulateQueue();
            eventManager->HandleEvents();

            //cout << "getting delta time scripted" << std::endl;
            //sm->runOne("get_delta_time", false);
            //cout << "updating" << std::endl;
            sm->runOne("update", false);
            
            //cout << "objects drawing" << std::endl;
            std::map<int, GameObject*> environment = collisionHandler->getEnvironment();
            for(std::map<int, GameObject*>::iterator it = environment.begin(); it!=environment.end(); it++){
                GameObject toDraw = *(it->second);
                //cout<<"Drawing Object " << toDraw.toString() << std::endl;
                sf::Transform offset;
                offset.translate(windowHandler->getOffset());
                if(windowHandler->getOffset().x != 0 || windowHandler->getOffset().y != 0){
                    //cout << "render offset: <" << windowHandler->getOffset().x << ", " << windowHandler->getOffset().y << ">" << std::endl;
                }
                if(toDraw.getActive() && toDraw.getShouldRender()){
                    window.draw(toDraw, offset);
                } else {
                    toDraw.move(windowHandler->getOffset());
                }
                
            }

            /*
            std::vector<GameObject*> objects = GameObject::game_objects;
            for(std::vector<GameObject*>::iterator it = objects.begin(); it!=objects.end(); it++){
                GameObject toDraw = **it;
                //cout<<"Drawing Object at x:" << toDraw.getPosition().x << ", y: " << toDraw.getPosition().y << "; Color: r: " << std::to_string(toDraw.getFillColor().r) << ", g: " << std::to_string(toDraw.getFillColor().g) << ", b: " << std::to_string(toDraw.getFillColor().b) << ", a: " << std::to_string(toDraw.getFillColor().a) << std::endl;
                sf::Transform offset;
                offset.translate(windowHandler->getOffset());
                if(windowHandler->getOffset().x != 0 || windowHandler->getOffset().y != 0){
                    //cout << "render offset: <" << windowHandler->getOffset().x << ", " << windowHandler->getOffset().y << ">" << std::endl;
                }
                if(toDraw.getActive() && toDraw.getShouldRender()){
                    window.draw(toDraw, offset);
                } else {
                    toDraw.move(windowHandler->getOffset());
                }
                
            } */

            // end the current frame
            window.display();
            //cout << "frame ended" << std::endl;
        }
    }
    return 0;
}