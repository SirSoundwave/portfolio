#pragma once

#include "../engine/game_object.hpp"
#include <utility>
#include <v8.h>
#include <SFML/Graphics.hpp>
#include <string.h>
#include <iostream>
#include "enum_tools.hpp"
#include "../v8/ScriptManager.h"
#include "../v8/v8helpers.hpp"


#ifndef EVENT_H
#define EVENT_H

    enum class EventType{
        Key,
        Collision,
        Death,
        Spawn,
        Remove,
        Chord
    };

    class Event{
        protected:
            EventType type;
            bool handled = false;
            u_int64_t calledTime;

            std::string sourceGUID;
            void* data;

            
        public:
            static int counter;

            std::string handle;

            virtual~ Event();

            EventType GetType() const{
                return type;
            }

            bool Handled(){
                return handled;
            }

            void Handle(){
                handled = true;
            }

            u_int64_t GetCalledTime() const{
                return calledTime;
            }

            std::string getSource(){
                return sourceGUID;
            }
            void * getData(){
                return data;
            }


            virtual std::string ToString(){
                std::string output;
                switch (type)
                {
                case EventType::Collision :
                    output = "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime) +
                        ";Source ID:" + sourceGUID +
                        ";Direction:" + std::to_string((int)(*(CollisionData*)this->data).dir) +
                        ";CollisionType:" + std::to_string((int)(*(CollisionData*)this->data).type) +
                        ";}";
                    break;
                case EventType::Key :
                    output = "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime) +
                        ";Source ID:" + sourceGUID;
                        ";Key:" + std::to_string(*((sf::Keyboard::Key *)this->data)) +
                        ";}";
                    break;
                default:
                    output = "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime) +
                        ";Source ID:" + sourceGUID;
                        ";}";
                    break;
                    break;
                }
                return output;

            }
            void Cleanup(){
                //std::cout << "Server cleanup Event Type: " << (int)this->type << std::endl;
                if(this->data != nullptr && (this->type != EventType::Death) && (this->type != EventType::Spawn)){
                    free(this->data);
                }
                //std::cout << "Server cleaned" << std::endl;
            }

            Event * copy(){
                return this;
            }

            /**
             * NOTE: These "Accessors" have to be **static**
             *
             * You will need to implement a setter and getter for every class
             * member variable you want accessible to javascript.
             */
            static void setEventType(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
            static void getEventType(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
            static void setEventHandled(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
            static void getEventHandled(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
            static void setEventCalledTime(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
            static void getEventCalledTime(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
            static void setEventSource(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
            static void getEventSource(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
            static void setEventData(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
            static void getEventData(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
            static void setEventCollisionType(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
            static void getEventCollisionType(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
            static void setEventCollisionDirection(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
            static void getEventCollisionDirection(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
            static void setEventHandle(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
            static void getEventHandle(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type

            /**
             * This function will make this class instance accessible to scripts in
             * the given context. 
             *
             * IMPORTANT: Please read this definition of this function in
             * GameObject.cpp. The helper function I've provided expects certain
             * parameters which you must use in order to take advance of this
             * convinience. 
             */
            v8::Local<v8::Object> exposeToV8(v8::Isolate *isolate, v8::Local<v8::Context> &context, std::string context_name="default");

            /**
             * Factor methods for creating new instances of GameObjects.
             *
             * This is primarily a demonstration of how you can create new objects
             * in javascript. NOTE: this is embedded in this GameObject class, but
             * could (and likely should) be used for other functionality as well
             * (i.e., Events). 
             */
            static Event* EventFactory(std::string context_name="default");
            static void ScriptedEventFactory(const v8::FunctionCallbackInfo<v8::Value>& args);

    };



#endif