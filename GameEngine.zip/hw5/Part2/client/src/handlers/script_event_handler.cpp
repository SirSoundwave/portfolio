#include "script_event_handler.hpp"

EventManager* ScriptEventHandler::em;

ScriptEventHandler::ScriptEventHandler(ScriptManager* sm, v8::Isolate* isolate, v8::Local<v8::Context>* context, std::string context_name){
    this->sm = sm;
    this->isolate = isolate;
    this->context = context;
    this->context_name = context_name;
}

void ScriptEventHandler::HearEvent(Event event){
    this->OnEvent(event);
    
    
}

void ScriptEventHandler::OnEvent(Event event){
    //std::cout << "attempting scripted event handle for " << event.handle << std::endl;
    ScriptManager::eventHandle = event.handle;
    event.exposeToV8(isolate, *context);
    sm->runOne("handle_event", false, context_name);
}

void ScriptEventHandler::getKeyPressed(const v8::FunctionCallbackInfo<v8::Value>& args){
    v8::Isolate *isolate = args.GetIsolate();
    v8::Local<v8::Context> context = isolate->GetCurrentContext();
    v8::Local<v8::Boolean> object = v8::Boolean::New(isolate, (sf::Keyboard::isKeyPressed(static_cast<sf::Keyboard::Key>(args[0]->Int32Value(context).ToChecked()))));
    args.GetReturnValue().Set(object);
}

void ScriptEventHandler::ScriptedRaiseEvent(const v8::FunctionCallbackInfo<v8::Value>& args){
    //std::cout << "attempting to raise event" << std::endl;
    v8::Isolate *isolate = args.GetIsolate();
    v8::Local<v8::Context> context = isolate->GetCurrentContext();
    v8::String::Utf8Value str(isolate, args[0]);
	std::string handle(*str);
    //std::cout << "fetching object "<< handle << std::endl;
    v8::Local<v8::Value> object = context->Global()->Get(context, args[0]->ToString()).ToLocalChecked();
    //std::cout << "wrapping object" << std::endl;
    v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(object->ToObject()->GetInternalField(0));
    //std::cout << "getting pointer" << std::endl;
    void* ptr = wrap->Value();
    //std::cout << "queueing event" << std::endl;
    //std::cout << static_cast<Event *>(ptr)->ToString() << std::endl;
    em->QueueEvent(static_cast<Event *>(ptr));
    //std::cout << "queued event" << std::endl;
}