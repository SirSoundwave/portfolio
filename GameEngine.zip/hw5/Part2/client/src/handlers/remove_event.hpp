#include "event.hpp"

#ifndef REMOVEEVENT_H
#define REMOVEEVENT_H

class RemoveEvent : public Event{
        public:
        RemoveEvent(u_int64_t calledTime, std::string source){
            this->type = EventType::Remove;
            this->calledTime = calledTime;
            this->sourceGUID = source;
        }

        virtual std::string ToString() override{
            return "{Type:" + std::to_string((int)this->type) +
                    ";Called Time:" + std::to_string(this->calledTime); +
                    ";Source ID:" + sourceGUID;
                    "};";
        }
};

#endif