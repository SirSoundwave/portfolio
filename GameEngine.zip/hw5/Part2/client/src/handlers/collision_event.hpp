#include "event.hpp"
#include "../engine/game_object.hpp"

#ifndef COLEVENT_H
#define COLEVENT_H

    class CollisionEvent : public Event{

        public:
            CollisionEvent(u_int64_t calledTime, std::string source, GameObject* other){
                this->calledTime = calledTime;
                this->type = EventType::Collision;
                sourceGUID = source;

                this->data = (CollisionData *)malloc(sizeof(CollisionData));
                *(CollisionData *)(this->data) = (CollisionData){Direction::NONE, other->getCollisionType()};
                this->handle = "event" + std::to_string(counter++);
            }

            CollisionEvent(u_int64_t calledTime, std::string source, GameObject* other, Direction* direction){
                this->calledTime = calledTime;
                this->type = EventType::Collision;
                sourceGUID = source;

                this->data = (CollisionData *)malloc(sizeof(CollisionData));
                *(CollisionData *)(this->data) = (CollisionData){*direction, other->getCollisionType()};
                this->handle = "event" + std::to_string(counter++);
            }

            CollisionEvent(u_int64_t calledTime, std::string source, CollisionType colType, Direction direction){
                this->calledTime = calledTime;
                this->type = EventType::Collision;
                sourceGUID = source;

                this->data = (CollisionData *)malloc(sizeof(CollisionData));
                *(CollisionData *)(this->data) = (CollisionData){direction, colType};
                this->handle = "event" + std::to_string(counter++);
            }

            CollisionType getCollisionType(){
                return ((CollisionData *)(this->data))->type;
            }

            Direction getDirection(){
                return ((CollisionData *)(this->data))->dir;
            }

            std::string GetOther(){
                return sourceGUID;
            }

            virtual std::string ToString() override{
                return "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime); +
                        ";Source ID:" + sourceGUID +
                        ";Direction:" + std::to_string((int)(*(CollisionData*)this->data).dir) +
                        ";Type:" + std::to_string((int)(*(CollisionData*)this->data).type) +
                        "};";
            }
    };

#endif