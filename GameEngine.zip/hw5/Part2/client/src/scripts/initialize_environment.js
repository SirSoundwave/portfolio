//
// This script calls gameobjectfactory() to create a new game object, and
// receives its handle. 
//
// NOTE: gameobjectfactory is a static function added to the global context in
// the native main() function
//
const screenWidth = 800.0;
const screenHeight = 600.0;

var lastTime = getcurrenttime();
var currentTime = getcurrenttime();
var deltaTime = 0;


var ball = gameobjectfactory();

ball.size_x = 30;
ball.size_y = 30;
ball.x = screenWidth/2;
ball.y = screenHeight * 2/3;
ball.velocity_x = 0.1;
ball.velocity_y = -0.1;
ball.r = 255;
ball.g = 0;
ball.b = 0;
ball.collidable = true;
ball.shouldRender = true;
ball.colType = 1;
ball.guid = "ball";
ball.active = true;

var paddle = gameobjectfactory();

paddle.size_x = 100;
paddle.size_y = 30;
paddle.x = screenWidth/2;
paddle.y = screenHeight;
paddle.r = 0;
paddle.g = 255;
paddle.b = 0;
paddle.collidable = true;
paddle.shouldRender = true;
paddle.colType = 1;
paddle.speed = 5;
paddle.guid = "paddle";
paddle.active = true;




