currentTime = getcurrenttime();

deltaTime = currentTime - lastTime;

lastTime = getcurrenttime();