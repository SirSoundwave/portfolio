var EventType = {
    Key: 0,
    Collision: 1,
    Death: 2,
    Spawn: 3,
    Remove: 4,
    Chord: 5
};

var CollisionType = {
    NONE: 0,
    STANDARD: 1,
    DEATH: 2,
    SCROLL: 3,
    COUNT: 4
};

var Direction = {
    UP: 0,
    RIGHT: 1,
    DOWN: 2,
    LEFT: 3,
    NONE: 4
};

var eventX = geteventhandle();
//print("Got event of type " + eventX.type + " at time " + eventX.calledTime + " with handle " + eventX.handle);
switch(eventX.type){
    case EventType.Key:
        var platformSource = gethandle("paddle");
        if(eventX.data == 71){
            platformSource.velocity_x = platformSource.speed * -1;
        } else if (eventX.data == 72){
            platformSource.velocity_x = platformSource.speed;
        }
    default:
        break;
}