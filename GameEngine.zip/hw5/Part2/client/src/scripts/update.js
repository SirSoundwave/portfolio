var platformSource = gethandle("paddle");

platformSource.x = platformSource.x + platformSource.velocity_x;
platformSource.velocity_x = 0;
