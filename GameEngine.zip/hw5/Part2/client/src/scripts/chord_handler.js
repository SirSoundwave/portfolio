var keysToCheck = [
    71, //Left
    72, //Right
    73, //Up
    74, //Down
    27, //Num1
    28, //Num2
    29, //Num3
    15 //P
]

var chordsToCheck = [
    [71, 72] //Left and right
]

var keyHandled = new Map();
for(var i = 0; i < keysToCheck.length; i++){
    keyHandled.set(keysToCheck[i], false);
}

for(var c = 0; c < chordsToCheck.length; c++){
    var chordComplete = true;
    for(var d = 0; d < chordsToCheck[c].length; d++){
        if(!keysToCheck.includes(chordsToCheck[c][d]) || !getkeypressed(chordsToCheck[c][d]) || keyHandled.get(chordsToCheck[c][d])){
            chordComplete = false;
            break;
        }
    }
    if(chordComplete){
        //raise chord event
        //print("Raise chord event");
        var chordKeys = "";
        for(var e = 0; e < chordsToCheck[c].length; e++){
            keyHandled.set(chordsToCheck[c][e], true);
            chordKeys += chordsToCheck[c][e].toString() + "|"
        }
        chordKeys += "~";
        var chordEvent = eventfactory(5, getcurrenttime(), 0, chordKeys);
        raiseevent(chordEvent.handle);
    }
}
for(var k = 0; k < keysToCheck.length; k++){
    if(getkeypressed(keysToCheck[k]) && !keyHandled.get(keysToCheck[k])){
        //raise key event
        //print("Raise key event for key " + keysToCheck[k]);
        var keyEvent = eventfactory(0, getcurrenttime(), 0, keysToCheck[k]);
        raiseevent(keyEvent.handle);
    }
}