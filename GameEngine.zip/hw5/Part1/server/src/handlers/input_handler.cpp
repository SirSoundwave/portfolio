#include "input_handler.hpp"

void checkInput(InputCheckerStruct *inputCheck){
    inputCheck->pressedLeft = sf::Keyboard::isKeyPressed(sf::Keyboard::Left);
    inputCheck->pressedRight = sf::Keyboard::isKeyPressed(sf::Keyboard::Right);
    inputCheck->pressedUp = sf::Keyboard::isKeyPressed(sf::Keyboard::Up);
    inputCheck->pressedDown = sf::Keyboard::isKeyPressed(sf::Keyboard::Down);
    inputCheck->pressedJump = sf::Keyboard::isKeyPressed(sf::Keyboard::Up);
    inputCheck->pressed1 = sf::Keyboard::isKeyPressed(sf::Keyboard::Num1);
    inputCheck->pressed2 = sf::Keyboard::isKeyPressed(sf::Keyboard::Num2);
    inputCheck->pressed3 = sf::Keyboard::isKeyPressed(sf::Keyboard::Num3);
    inputCheck->pressedPause = sf::Keyboard::isKeyPressed(sf::Keyboard::P);
}