#include <bits/stdc++.h>
#include <string.h>
#include <iostream>
#include <mutex>
#include <chrono>

#ifndef TIMELINE_H
#define TIMELINE_H

using namespace std;
class Timeline
{
private:
    std::mutex timeLock; //if tics can change size and the game is multithreaded
    int64_t start_time; //the time of the *anchor when created
    int64_t elapsed_paused_time;
    int64_t last_paused_time;
    int64_t tic; //units of anchor timeline per step
    bool paused = false;
    bool baseTimeline;
    Timeline *anchor; //for most general game time, system library pointer
    int64_t paused_time_temp = 0;

public:

    Timeline(Timeline *anchor = nullptr, int64_t tic = 1);

    Timeline(const Timeline &timeline);

    void setAnchor(Timeline *anchor)
    {
        this->anchor = anchor;
    }

    //Need mutex here down;

    /**
     * Gets the current time relative to the timeline's anchor (or system time) in milliseconds
    */
    int64_t getTime(){
        //cout << "Time requested" << std::endl;
        int64_t return_time = 0;
        try{
            //cout << "Locking timeline" << std::endl;
            {
                int64_t paused_time = getElapsedPausedTime();
                // This line would get the time lock, but it crashes the program with a segmentation fault.
                std::unique_lock<std::mutex> mutexLock(this->timeLock);
                //cout << "Timeline locked" << std::endl;
        
                if(!baseTimeline){
                    //cout << "returning relative time" << std::endl;
                    return_time =  (anchor->getTime() - start_time - anchor->getElapsedPausedTime())/tic - paused_time;
                } else {
                    //cout << "returning system time" << std::endl;
                    int64_t current_time = chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now().time_since_epoch()).count();
                    //cout << "current time retrieved" << std::endl;
                    return_time = (current_time - start_time) / tic - paused_time;
                }
            }
            //cout << "Timeline unlocked" << std::endl;
        } catch(...){
            std::cerr << "Error while getting time" << std::endl;
        }


        return return_time;
    }

    /**
     * Gets the current time relative to the timeline's anchor (or system time) in milliseconds without accounting for pause
    */
    int64_t getPauselessTime(){
        //cout << "Time requested" << std::endl;
        int64_t return_time = 0;
        try{
            //cout << "Locking timeline" << std::endl;
            {
                // This line would get the time lock, but it crashes the program with a segmentation fault.
                std::unique_lock<std::mutex> mutexLock(this->timeLock);
                //cout << "Timeline locked" << std::endl;
        
                if(!baseTimeline){
                    //cout << "returning relative time" << std::endl;
                    return_time =  (anchor->getTime() - start_time)/tic;
                } else {
                    //cout << "returning system time" << std::endl;
                    int64_t current_time = chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now().time_since_epoch()).count();
                    //cout << "current time retrieved" << std::endl;
                    return_time = (current_time - start_time) / tic;
                }
            }
            //cout << "Timeline unlocked" << std::endl;
        } catch(...){
            std::cerr << "Error while getting time" << std::endl;
        }


        return return_time;
    }

    /**
     * Pauses the timeline
    */
    void pause()
    {
        int64_t current_time;
        if(baseTimeline){
            current_time = chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now().time_since_epoch()).count();
        } else {
            current_time = anchor->getTime();
        }
        
        {
            cout << "Pausing" << endl;
            // This line would get the time lock, but it crashes the program with a segmentation fault.
            std::unique_lock<std::mutex> mutexLock(this->timeLock);
            last_paused_time = current_time;
            paused = true;
            cout << "Paused" << endl;
        }
        
        
    }

    /**
     * Unpauses the timeline
    */
    void unpause()
    {
        int64_t current_time;
        if(baseTimeline){
            current_time = chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now().time_since_epoch()).count();
        } else {
            current_time = anchor->getTime();
        }
        {
            cout << "Unpausing" << endl;
            // This line would get the time lock, but it crashes the program with a segmentation fault.
            std::unique_lock<std::mutex> mutexLock(this->timeLock);
            elapsed_paused_time = paused_time_temp + (current_time - last_paused_time) / tic;
            paused_time_temp = elapsed_paused_time;
            paused = false;
            cout << "Unpaused" << endl;
        }
        
        
    }

    /**
     * Gets the elapsed paused time (updates elapsed paused time if the timeline is paused)
    */
    int64_t getElapsedPausedTime()
    {
        //cout << "Getting elapsed paused time" << std::endl;
        if(isPaused()){
            //cout << "currently paused" << std::endl;
            int64_t current_time;
            if(!baseTimeline){
                current_time = anchor->getTime();
            } else {
                current_time = chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now().time_since_epoch()).count();
            }
            {
                std::unique_lock<std::mutex> mutexLock(this->timeLock);
                elapsed_paused_time = paused_time_temp + (current_time - last_paused_time) / tic;
            }
 
        }
        return elapsed_paused_time;
    }

    /**
     * Updates the tics per step.
    */
    void changeTic(int tic)
    {
        // This line would get the time lock, but it crashes the program with a segmentation fault.
        std::unique_lock<std::mutex> mutexLock(this->timeLock);
        cout << "Changing tic to " << tic << std::endl;
        this->tic = tic;
    }

    /**
     * Returns true if this timeline or its anchor is paused.
    */
    bool isPaused()
    {
        {
            if(baseTimeline){
                return paused;
            }
            return paused || anchor->isPaused();
        }
    }

};

#endif