#include "event.hpp"
#include "../v8/ScriptManager.h"
#include "../environment/spawn_point.hpp"
#include "../engine/game_object.hpp"
#include "death_event.hpp"
#include "spawn_event.hpp"
#include "event_handler.hpp"
#include "event_manager.hpp"

#ifndef SCRIPTEVENTHANDLER_H
#define SCRIPTEVENTHANDLER_H

class ScriptEventHandler : public EventHandler{
    
    public:

        ScriptManager* sm;
        v8::Isolate* isolate;
        v8::Local<v8::Context>* context;
        std::string context_name;
        

        ScriptEventHandler(ScriptManager* sm, v8::Isolate* isolate, v8::Local<v8::Context>* context, std::string context_name){
            this->sm = sm;
            this->isolate = isolate;
            this->context = context;
            this->context_name = context_name;
        }

        void HearEvent(Event event){
            this->OnEvent(event);
            
            
        }

        void OnEvent(Event event) override{
            //std::cout << "attempting scripted event handle" << std::endl;
            ScriptManager::eventHandle = event.handle;
            event.exposeToV8(isolate, *context);
            sm->runOne("handle_event", false, context_name);
        }
};

#endif