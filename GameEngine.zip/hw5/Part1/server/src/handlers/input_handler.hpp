#include <iostream>
#include <SFML/Window/Keyboard.hpp>

#ifndef INPUTHANDLER_H
#define INPUTHANDLER_H

struct InputCheckerStruct{
    bool pressedLeft;
    bool pressedRight;
    bool pressedUp;
    bool pressedDown;
    bool pressedJump;
    bool pressed1;
    bool pressed2;
    bool pressed3;
    bool pressedPause;
};

void checkInput(InputCheckerStruct *inputCheck);

#endif