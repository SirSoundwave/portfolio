#include <SFML/Graphics.hpp>
#include "event.hpp"

#ifndef KEYEVENT_H
#define KEYEVENT_H

    class KeyEvent : public Event{
        public:
            KeyEvent(u_int64_t calledTime, sf::Keyboard::Key key){
                this->type = EventType::Key;
                this->calledTime = calledTime;
                this->data = (sf::Keyboard::Key *)malloc(sizeof(sf::Keyboard::Key));
                *((sf::Keyboard::Key *)this->data) = key;
                this->handle = "event" + std::to_string(counter++);
            }

            sf::Keyboard::Key getKey(){
                return *((sf::Keyboard::Key *)this->data);
            }

            virtual std::string ToString() override{
                return "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime); +
                        ";Source ID:" + std::to_string(sourceID);
                        ";Key:" + std::to_string(getKey()) +
                        "};";
            }
    };

#endif