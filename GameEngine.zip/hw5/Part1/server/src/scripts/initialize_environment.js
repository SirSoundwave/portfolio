//
// This script calls gameobjectfactory() to create a new game object, and
// receives its handle. 
//
// NOTE: gameobjectfactory is a static function added to the global context in
// the native main() function
//
print("Creating new object");
var platform = gameobjectfactory();
print("Received new object: " +  platform.guid);
platform.size_x = 100.0;
platform.size_y = 50.0;
platform.x = 400.0;
platform.y = 300.0;
platform.r = 0;
platform.b = 0;
platform.g = 255;
platform.collidable = true;
platform.shouldRender = true;
print("Updated properties of object to: x: " + platform.x + ", y: " + platform.y + ", size: [" + platform.size_x + ", " + platform.size_y + "], Color: (" + platform.r + ", " + platform.g + ", " + platform.b + ");");
