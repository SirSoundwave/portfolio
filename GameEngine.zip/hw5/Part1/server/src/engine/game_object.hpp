#pragma once

#include <utility>
#include <v8.h>

#include <SFML/Graphics/RectangleShape.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <string>
#include <iostream>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include <bits/stdc++.h>

#include "../handlers/event.hpp"
#include "../handlers/enum_tools.hpp"
#include "../handlers/timeline.hpp"

#ifndef GAME_OBJECT_H
#define GAME_OBJECT_H

class GameObject : public sf::RectangleShape
{
public :


    explicit GameObject(const sf::Vector2f& size = sf::Vector2f(1.f, 1.f), const sf::Vector2f& position = sf::Vector2f(0.f, 0.f), bool collidable = false);
    //~GameObject();

    GameObject(std::string rep);

    void Update(std::string rep){
        //Read ID
        std::string idRaw = rep.substr(rep.find("ID:") + 3, rep.find(",", rep.find("ID:")) - (rep.find("ID:") + 3));
        int readId = std::stoi(idRaw);
        
        if(readId == this->objectID){

            //Read Position
            std::string posXRaw = rep.substr(rep.find("Position:") + 9, rep.find(",", rep.find("Position:")) - (rep.find("Position:") + 9));
            float positionX = std::stof(posXRaw);
            std::string posYRaw = rep.substr(rep.find(",", rep.find("Position:")) + 1, rep.find(";", rep.find("Position:")) - (rep.find(",", rep.find("Position:")) + 1));
            float positionY = std::stof(posYRaw);
            //std::cout << "New Object Position: " << positionX << ", " << positionY << std::endl;
            this->setPosition(sf::Vector2f(positionX, positionY));

            //Read Size
            float sizeX = std::stof(rep.substr(rep.find("Size:") + 5, rep.find(",", rep.find("Size:")) - (rep.find("Size:") + 5)));
            float sizeY = std::stof(rep.substr(rep.find(",", rep.find("Size:")) + 1, rep.find(";", rep.find("Size:")) - (rep.find(",", rep.find("Size:")) + 1)));
            setSize(sf::Vector2f(sizeX, sizeY));

            //Read Velocity
            std::string velXRaw = rep.substr(rep.find("Velocity:") + 9, rep.find(",", rep.find("Velocity:")) - (rep.find("Velocity:") + 9)); 
            std::string velYRaw = rep.substr(rep.find(",", rep.find("Velocity:")) + 1, rep.find(";", rep.find("Velocity:")) - (rep.find(",", rep.find("Velocity:")) + 1));
            //std::cout << "New Object Velocity: " << velXRaw << ", " << velYRaw << std::endl;
            float velX = std::stof(velXRaw);
            float velY = std::stof(velYRaw);
            
            this->velocity = sf::Vector2f(velX, velY);

            // Read Collidable
            std::string collidableRaw = rep.substr(rep.find("Collidable:")+11, rep.find(";", rep.find("Collidable:")) - (rep.find("Collidable:")+11));
            //std::cout << "Collidable: " << collidableRaw << std::endl;
            this->collidable = std::stoi(collidableRaw);

            // Read Collision Type
            std::string colTypeRaw = rep.substr(rep.find("Collision Type:")+15, rep.find(";", rep.find("Collision Type:")) - (rep.find("Collision Type:")+15));
            //std::cout << "Collidable: " << collidableRaw << std::endl;
            this->colType = (CollisionType)std::stoi(colTypeRaw);

            // Read Should Render
            std::string renderRaw = rep.substr(rep.find("ShouldRender:")+13, rep.find(";", rep.find("ShouldRender:")) - (rep.find("ShouldRender:")+13));
            //std::cout << "Speed: " << speedRaw << std::endl;
            this->shouldRender = std::stoi(renderRaw);

            // Read Active
            std::string activeRaw = rep.substr(rep.find("Active:")+7, rep.find(";", rep.find("Active:")) - (rep.find("Active:")+7));
            //std::cout << "Speed: " << speedRaw << std::endl;
            this->active = std::stoi(activeRaw);

            // Read Speed
            std::string speedRaw = rep.substr(rep.find("Speed:")+6, rep.find(";", rep.find("Speed:")) - (rep.find("Speed:")+6));
            //std::cout << "Speed: " << speedRaw << std::endl;
            this->speed = std::stof(speedRaw);

            // Read Colors
            std::string rRaw = rep.substr(rep.find("Color:")+6,
                                        rep.find(",", rep.find("Color:")) - (rep.find("Color:")+6));
            std::string gRaw = rep.substr(rep.find(",", rep.find("Color:")) + 1,
                                        rep.find(",", rep.find(",", rep.find("Color:")) + 1) - (rep.find(",", rep.find("Color:") + 1) + 1));
            std::string bRaw = rep.substr(rep.find(",", rep.find(",", rep.find("Color:")) + 1) + 1,
                                        rep.find(";", rep.find("Color:")) - (rep.find(",", rep.find(",", rep.find("Color:")) + 1) + 1));
            //std::cout << "Color: r: " << rRaw << ", g: " << gRaw << ", b: " << bRaw << std::endl;
            int r = std::stoi(rRaw);
            int g = std::stoi(gRaw);
            int b = std::stoi(bRaw);
            this->setFillColor(sf::Color(r, g, b));

            if(rep.find("Texture:") != std::string::npos){
                this->textureLoc = rep.substr(rep.find("Texture:")+8, rep.find(";", rep.find("Texture:")) - (rep.find("Texture:")+8));
                if(objectTexture.loadFromFile(textureLoc)){
                    this->setTexture(&objectTexture);
                }
            }
        }
    }

    void setSize(const sf::Vector2f& size)
    {
        m_size = size;
        update();
    }

    const sf::Vector2f& getSize() const
    {
        return m_size;
    }

    virtual std::size_t getPointCount() const;

    virtual sf::Vector2f getPoint(std::size_t index) const;

    void setColor(sf::Color color)
    {
        this->color = color;
    }

    void setColor(int r, int g, int b, int a=255)
    {
        this->color = sf::Color(r, g, b, a);
    }

    sf::Color getColor()
    {
        return color;
    }

    void updateFillColor(){
        {
            std::unique_lock<std::mutex> mutexLock(*(this->colorLock));
            this->setFillColor(this->color);
        }
        
    }

    sf::FloatRect getBoundingBox(){
        return getGlobalBounds();
    }

    void setVelocity(sf::Vector2f velocity){
        this->velocity = velocity;
    }

    sf::Vector2f getVelocity(){
        return this->velocity;
    }

    float getSpeed(){
        return this->speed;
    }

    bool getCollidable(){
        return collidable && active;
    }

    CollisionType getCollisionType() const{
        return colType;
    }

    void PreUpdate();

    void Update(int64_t deltaT);

    std::string toString();

    void setTextureAddress(std::string &address);

    static int getNextID(){
        nextID++;
        return nextID;
    }

    void setID(int id) {
        this->objectID = id;
    }


    int getID() const{
        return this->objectID;
    }

    bool getShouldRender(){
        return this->shouldRender;
    }

    void setTimeline(Timeline* timeline){
        this->timeline = timeline;
    }

    void setActive(bool active){
        this->active = active;
    }

    bool getActive(){
        return this->active;
    }

    /**
     * This function will make this class instance accessible to scripts in
     * the given context. 
     *
     * IMPORTANT: Please read this definition of this function in
     * GameObject.cpp. The helper function I've provided expects certain
     * parameters which you must use in order to take advance of this
     * convinience. 
     */
    v8::Local<v8::Object> exposeToV8(v8::Isolate *isolate, v8::Local<v8::Context> &context, std::string context_name="default");

    /**
     * Static function to keep track of current total number of
     * gameobjects, to facilitate creating GUIDs by incrementing a counter.
     */
    static int getCurrentGUID();

    /**
     * Shared list of all instances of game objects...auto populated by the
     * constructor.
     */
    static std::vector<GameObject*> game_objects;

    /**
     * Factor methods for creating new instances of GameObjects.
     *
     * This is primarily a demonstration of how you can create new objects
     * in javascript. NOTE: this is embedded in this GameObject class, but
     * could (and likely should) be used for other functionality as well
     * (i.e., Events). 
     */
    static GameObject* GameObjectFactory(std::string context_name="default");
    static void ScriptedGameObjectFactory(const v8::FunctionCallbackInfo<v8::Value>& args);
    

private :
    sf::Vector2f m_size;

    v8::Isolate* isolate;
	v8::Global<v8::Context>* context;

    /**
     * NOTE: These "Accessors" have to be **static**
     *
     * You will need to implement a setter and getter for every class
     * member variable you want accessible to javascript.
     */
    static void setGameObjectX(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectX(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectY(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectY(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectGUID(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectGUID(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectSpeed(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectSpeed(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectTextureLoc(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectTextureLoc(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectCollisionType(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectCollisionType(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectColor(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectColor(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectVelocityX(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectVelocityX(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectVelocityY(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectVelocityY(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectActive(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectActive(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectSizeX(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectSizeX(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectSizeY(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectSizeY(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectColorR(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectColorR(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectColorG(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectColorG(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectColorB(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectColorB(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectCollidable(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectCollidable(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    static void setGameObjectShouldRender(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info);
    static void getGameObjectShouldRender(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info); // note return type
    
protected :
    sf::Color color = sf::Color::Black;
    sf::Vector2f velocity;
    bool collidable;
    float speed = 0;
    std::string textureLoc = "null";
    sf::Texture objectTexture;
    CollisionType colType;
    static int nextID;
    int objectID;
    string guid;
    bool shouldRender;
    Timeline* timeline;
    bool active = true;

    std::mutex * colorLock;

};

#endif