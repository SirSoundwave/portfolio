    #include <SFML/Graphics/RectangleShape.hpp>
    #include "../engine/game_object.hpp"
    #include "platform.hpp"


    Platform::Platform(const sf::Vector2f& size, const sf::Vector2f& position)
    {
        this->setPosition(position);
        setSize(size);
        this->collidable = true;
        this->colType = CollisionType::STANDARD;
        this->shouldRender = true;
    }
