#include <SFML/Graphics/RectangleShape.hpp>
#include "../engine/game_object.hpp"
#include "platform.hpp"
#include "moving_platform.hpp"


MovingPlatform::MovingPlatform(const sf::Vector2f& size, const sf::Vector2f& position, const sf::Vector2f targets[], int numTargets, float speed)
{
    this->setPosition(position);
    setSize(size);
    setSpeed(speed);
    targetIndex = 0;
    this->numTargets = numTargets;
    setTargets(targets, numTargets);
    this->collidable = true;
    this->colType = CollisionType::STANDARD;
    this->shouldRender = true;
}