#include "../engine/game_object.hpp"

#ifndef PLATFORM_H
#define PLATFORM_H

class Platform : public GameObject
{
public:
    Platform(const sf::Vector2f& size = sf::Vector2f(0.f, 0.f), const sf::Vector2f& position = sf::Vector2f(0.f, 0.f));
    

};

#endif