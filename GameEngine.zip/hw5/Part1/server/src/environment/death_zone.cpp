    #include <SFML/Graphics/RectangleShape.hpp>
    #include "../engine/game_object.hpp"
    #include "death_zone.hpp"


    DeathZone::DeathZone(const sf::Vector2f& size, const sf::Vector2f& position)
    {
        this->setPosition(position);
        setSize(size);
        this->collidable = true;
        this->colType = CollisionType::DEATH;
        this->shouldRender = false;
    }
