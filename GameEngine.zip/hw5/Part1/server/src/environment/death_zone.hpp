#include "../engine/game_object.hpp"

#ifndef DEATHZONE_H
#define DEATHZONE_H

class DeathZone : public GameObject
{
public:
    DeathZone(const sf::Vector2f& size = sf::Vector2f(0.f, 0.f), const sf::Vector2f& position = sf::Vector2f(0.f, 0.f));
    

};

#endif