#include <SFML/Graphics/RectangleShape.hpp>
#include <cmath>
#include "platform.hpp"
#include <iostream>

using namespace std;
#ifndef MOVINGPLATFORM_H
#define MOVINGPLATFORM_H

class MovingPlatform : public Platform
{
public:
    MovingPlatform(const sf::Vector2f& size = sf::Vector2f(0.f, 0.f), const sf::Vector2f& position = sf::Vector2f(0.f, 0.f), const sf::Vector2f targets[] = {}, int numTargets = 0, float speed = 1);

    sf::Vector2f getNextTarget(){
        return targets[targetIndex];
    }

    sf::Vector2f getPreviousTarget(){
        if(targetIndex == 0){
            return targets[numTargets - 1];
        }
        return targets[targetIndex];
    }

    void Update(int64_t deltaT){
        sf::Vector2f next = getNextTarget();
        sf::Vector2f current = getPosition();

        double distance = sqrt(pow(next.x - current.x, 2) + pow(next.y - current.y, 2));

        if(distance < (speed * deltaT)){
            sf::Vector2f movement = getNextTarget()-getPosition();
            if(targetIndex >= numTargets - 1){
                targetIndex = 0;
            } else {
                targetIndex ++;
            }
            velocity = movement;
        } else {
            sf::Transform t;
            sf::Vector2f movementDir = (next - current);
            double movementLen = sqrt(pow(movementDir.x, 2) + pow(movementDir.y, 2));

            sf::Vector2f movementNormalized = sf::Vector2f(movementDir.x / movementLen, movementDir.y / movementLen);

            double movementAmt = (speed * deltaT);

            velocity = sf::Vector2f(movementNormalized.x * movementAmt, movementNormalized.y * movementAmt);
        }

        this->move(velocity);

    }

    void setSpeed(float speed){
        this->speed = speed;
    }

    void setTargets(const sf::Vector2f targetsIn[], int numTargets){
        targets = (sf::Vector2f *)malloc(sizeof(sf::Vector2f) * numTargets);
        for(int i = 0; i < numTargets; i++){
            targets[i] = targetsIn[i];
        }
    }

private:
    int targetIndex;
    int numTargets;
    sf::Vector2f *targets;
};

#endif