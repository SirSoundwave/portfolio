#include "../engine/game_object.hpp"

#ifndef SCROLLZONE_H
#define SCROLLZONE_H

class ScrollZone : public GameObject
{
public:
    ScrollZone(const sf::Vector2f& size = sf::Vector2f(0.f, 0.f), const sf::Vector2f& position = sf::Vector2f(0.f, 0.f));
    

};

#endif