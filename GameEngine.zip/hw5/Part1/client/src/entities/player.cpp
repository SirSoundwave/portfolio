#include <SFML/Graphics/RectangleShape.hpp>
#include "../engine/game_object.hpp"
#include "player.hpp"

Player::Player(const sf::Vector2f& size, const sf::Vector2f& position, float speed, float jumpPower, InputCheckerStruct *inputChecker, EventManager* eventManager, Timeline* timeline, SpawnPoint* spawn)
{
    this->spawn = spawn;
    this->objectID = ++nextID;
    this->setPosition(position);
    setSize(size);
    setSpeed(speed);
    setJumpPower(jumpPower);
    fetchCollisionHandler();
    this->inputChecker = inputChecker;
    this->shouldRender = true;
    resetChecks();
    this->timeline = timeline;
    this->eventManager = eventManager;
    this->spawnHandler = new SpawnHandler(this, this->spawn, 1000, this->eventManager);
    eventManager->addListener(EventType::Death, this->spawnHandler);
    eventManager->addListener(EventType::Spawn, this->spawnHandler);
    
}