//
// This script calls gameobjectfactory() to create a new game object, and
// receives its handle. 
//
// NOTE: gameobjectfactory is a static function added to the global context in
// the native main() function
//
var new_obj = gameobjectfactory();
print("Received new object: " +  new_obj.guid)
