var eventX = geteventhandle();
print("Got event of type " + eventX.type + " at time " + eventX.calledTime + " with handle " + eventX.handle);