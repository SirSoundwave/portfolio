#include "event_manager.hpp"
#include "timeline.hpp"

EventManager::EventManager(Timeline* timeline){
    this->timeline = timeline;
}