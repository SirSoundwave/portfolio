#include "event.hpp"
#include "../engine/game_object.hpp"
#include "enum_tools.hpp"

#ifndef COLEVENT_H
#define COLEVENT_H

    class CollisionEvent : public Event{

        public:
            CollisionEvent(u_int64_t calledTime, int source, GameObject* other){
                this->calledTime = calledTime;
                this->type = EventType::Collision;
                sourceID = source;

                this->data = (CollisionData *)malloc(sizeof(CollisionData));
                *(CollisionData *)(this->data) = (CollisionData){Direction::NONE, other->getCollisionType()};
            }

            CollisionEvent(u_int64_t calledTime, int source, GameObject* other, Direction* direction){
                this->calledTime = calledTime;
                this->type = EventType::Collision;
                sourceID = source;

                this->data = (CollisionData *)malloc(sizeof(CollisionData));
                *(CollisionData *)(this->data) = (CollisionData){*direction, other->getCollisionType()};
            }

            CollisionEvent(u_int64_t calledTime, int source, CollisionType colType, Direction direction){
                this->calledTime = calledTime;
                this->type = EventType::Collision;
                sourceID = source;

                this->data = (CollisionData *)malloc(sizeof(CollisionData));
                *(CollisionData *)(this->data) = (CollisionData){direction, colType};
            }

            CollisionType getCollisionType(){
                return ((CollisionData *)(this->data))->type;
            }

            Direction getDirection(){
                return ((CollisionData *)(this->data))->dir;
            }

            int GetOther(){
                return sourceID;
            }

            virtual std::string ToString() override{
                return "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime); +
                        ";Source ID:" + std::to_string(sourceID) +
                        ";Direction:" + std::to_string((int)(*(CollisionData*)this->data).dir) +
                        ";CollisionType:" + std::to_string((int)(*(CollisionData*)this->data).type) +
                        ";Other ID:" + 
                        "};";
            }
    };

#endif