#include "event_handler.hpp"
#include "../environment/spawn_point.hpp"
#include "../engine/game_object.hpp"
#include "death_event.hpp"
#include "spawn_event.hpp"
#include "event_handler.hpp"

#ifndef SPAWNHANDLER_H
#define SPAWNHANDLER_H

class SpawnHandler : public EventHandler{
    public:
        SpawnHandler(GameObject* tracked, SpawnPoint* spawnPoint, uint64_t respawnTime, EventManager* eventManager){
            this->tracked = tracked;
            setRespawnTime(respawnTime);
            this->spawnPoint = spawnPoint;
            this->eventManager = eventManager;
        }

        virtual void OnEvent(Event event) override{
            if(event.GetType() == EventType::Death){
                //std::cout << "death event received" << std::endl;
                DeathEvent* deathEvent = (DeathEvent*)&event;
                int source = deathEvent->getSource();
                if(source == tracked->getID()){
                    tracked->setActive(false);
                    //std::cout << "queuing spawn event" << std::endl;
                    SpawnEvent* spawnEvent = new SpawnEvent(deathEvent->GetCalledTime() + respawnTime, tracked->getID());
                    eventManager->QueueEvent(spawnEvent);
                    //std::cout << "spawn event queued" << std::endl;
                }
            } else if(event.GetType() == EventType::Spawn){
                //std::cout << "spawn event received" << std::endl;
                SpawnEvent* spawnEvent = (SpawnEvent*)&event;
                int source = spawnEvent->getSource();
                if(source == tracked->getID()){
                    tracked->setPosition(spawnPoint->getPosition());
                    tracked->setActive(true);
                }
            }
        }

        void setRespawnTime(uint64_t respawnTime){
            this->respawnTime = respawnTime >= 0 ? respawnTime : 0;
        }

        void setSpawn(SpawnPoint* spawnPoint){
            this->spawnPoint = spawnPoint;
        }

    private:
        GameObject* tracked;
        SpawnPoint* spawnPoint;
        uint64_t respawnTime;
        EventManager* eventManager;


};

#endif