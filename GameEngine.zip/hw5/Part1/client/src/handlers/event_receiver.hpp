#include "event_handler.hpp"
#include "event_manager.hpp"
#include "collision_event.hpp"
#include "death_event.hpp"
#include "key_event.hpp"
#include "spawn_event.hpp"
#include "remove_event.hpp"

#ifndef EVENTRECV_H
#define EVENTRECV_H

class EventReceiver{
    public:
        EventReceiver(EventManager* eventManager, Timeline* timeline){
            this->eventManager = eventManager;
            this->timeline = timeline;
        }

        void parseEvent(std::string eventToken){
            //Read Type
            std::string typeRaw = eventToken.substr(eventToken.find("Type:") + 5, eventToken.find(";", eventToken.find("Type:")) - (eventToken.find("Type:") + 5));
            //cout << "Event Type: " << typeRaw << std::endl;
            int readType = std::stoi(typeRaw);
            EventType type = (EventType)readType;

            //Read Source ID
            std::string sourceRaw = eventToken.substr(eventToken.find("Source ID:") + 10, eventToken.find(";", eventToken.find("Source ID:")) - (eventToken.find("Source ID:") + 10));
            //cout << "Source ID: " << sourceRaw << std::endl;
            int sourceID = std::stoi(sourceRaw);

            std::string paramA;
            int paramAInt;
            std::string paramB;
            int paramBInt;
            


            switch (type)
                {
                case EventType::Collision :

                    //Read CollisionType
                    paramA = eventToken.substr(eventToken.find("CollisionType:") + 14, eventToken.find(";", eventToken.find("CollisionType:")) - (eventToken.find("CollisionType:") + 14));
                    paramAInt = std::stoi(paramA);

                    //cout << "CollisionType: " << paramB << std::endl;

                    //Read Direction
                    paramB = eventToken.substr(eventToken.find("Direction:") + 10, eventToken.find(";", eventToken.find("Direction:")) - (eventToken.find("Direction:") + 10));
                    //cout << "Direction: " << paramA << std::endl;
                    paramBInt = std::stoi(paramB);

                    if(paramAInt == 2 && sourceID == 6){
                        cout << "Death zone collision" << endl;
                    }
                    
                    //cout << "sanity time check: " << timeline->getTime() << std::endl;
                    eventManager->QueueEvent(new CollisionEvent(timeline->getTime(), sourceID, (CollisionType)paramAInt, (Direction)paramBInt));
                    break;
            
                case EventType::Death :
                    cout << "received death event" << endl;
                    eventManager->QueueEvent(new DeathEvent(timeline->getTime(), sourceID));
                    break;
                case EventType::Key :
                    //Read Key
                    paramA = eventToken.substr(eventToken.find("Key:") + 4, eventToken.find(";", eventToken.find("Key:")) - (eventToken.find("Key:") + 4));
                    paramAInt = std::stoi(paramA);

                    eventManager->QueueEvent(new KeyEvent(timeline->getTime(), (sf::Keyboard::Key)paramAInt));
                    break;
                case EventType::Spawn :
                    eventManager->QueueEvent(new SpawnEvent(timeline->getTime(), sourceID));
                    break;
                case EventType::Remove :
                    cout << "Remove event received" << std::endl;
                    eventManager->QueueEvent(new RemoveEvent(timeline->getTime(), sourceID));
                    break;
                default:
                    break;
                }
        }

    private:
        EventManager* eventManager;
        Timeline* timeline;
};

#endif