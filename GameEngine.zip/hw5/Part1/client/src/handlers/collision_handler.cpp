#include "collision_handler.hpp"

CollisionHandler* CollisionHandler::instancePtr = nullptr;

CollisionHandler* CollisionHandler::getInstance(){
        if(instancePtr == nullptr){
            instancePtr = new CollisionHandler();
            instancePtr->initEnvironmentHolder();
        }
        return instancePtr;
    }