#include "event.hpp"
#include "../engine/game_object.hpp"

#ifndef DEATHEVENT_H
#define DEATHEVENT_H

    class DeathEvent : public Event{
        public:
            DeathEvent(u_int64_t calledTime, int sourceID){
                std::cout << "Creating death event" << std::endl;
                this->type = EventType::Death;
                this->calledTime = calledTime;
                this->sourceID = sourceID;
                std::cout << "Death event created" << std::endl;
            }

            virtual std::string ToString() override{
                return "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime); +
                        ";Target ID:" + std::to_string(sourceID);
                        "};";
            }
    };

#endif