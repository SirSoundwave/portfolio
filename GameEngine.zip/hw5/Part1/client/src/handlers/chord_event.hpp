#include <SFML/Graphics.hpp>
#include "event.hpp"
#include <stdio.h>

#ifndef CHORDEVENT_H
#define CHORDEVENT_H

    class ChordEvent : public Event{
        public:
            ChordEvent(u_int64_t calledTime, std::vector<sf::Keyboard::Key> keys){
                this->type = EventType::Chord;
                this->calledTime = calledTime;
                this->data = new std::vector<sf::Keyboard::Key>(keys);
            }

            std::vector<sf::Keyboard::Key> getKeys(){
                return *((std::vector<sf::Keyboard::Key> *)this->data);
            }

            std::string getKeysString(){
                std::string out = "";
                for(sf::Keyboard::Key key : getKeys()){
                    out += std::to_string(key) + ",";
                }
                return out;
            }

            virtual std::string ToString() override{
                return "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime); +
                        ";Source ID:" + std::to_string(sourceID);
                        ";Keys:" + getKeysString() +
                        "};";
            }
    };

#endif