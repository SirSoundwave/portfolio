#include "key_event_manager.hpp"
#include "event_manager.hpp"
#include "timeline.hpp"

KeyEventManager::KeyEventManager(Timeline* timeline) : EventManager(timeline){
    this->timeline = timeline;
}