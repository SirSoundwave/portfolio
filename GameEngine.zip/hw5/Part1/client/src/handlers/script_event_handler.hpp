#include "event.hpp"
#include "../v8/ScriptManager.h"
#include "../environment/spawn_point.hpp"
#include "../engine/game_object.hpp"
#include "death_event.hpp"
#include "spawn_event.hpp"
#include "event_handler.hpp"
#include "event_manager.hpp"

#ifndef SCRIPTEVENTHANDLER_H
#define SCRIPTEVENTHANDLER_H

class ScriptEventHandler : public EventHandler{
    
    public:

        ScriptManager* sm;
        v8::Isolate* isolate;
        v8::Local<v8::Context>* context;
        std::string context_name;

        static EventManager* em;
        

        ScriptEventHandler(ScriptManager* sm, v8::Isolate* isolate, v8::Local<v8::Context>* context, std::string context_name);

        void HearEvent(Event event);

        void OnEvent(Event event) override;

        static void getKeyPressed(const v8::FunctionCallbackInfo<v8::Value>& args);

        static void ScriptedRaiseEvent(const v8::FunctionCallbackInfo<v8::Value>& args);
};

#endif