#ifndef ENUMTOOLS_H
#define ENUMTOOLS_H

enum class CollisionType{
        NONE = 0,
        STANDARD = 1,
        DEATH = 2,
        SCROLL = 3,
        COUNT = 4
};

enum class Direction{
    UP = 0,
    RIGHT = 1,
    DOWN = 2,
    LEFT = 3,
    NONE = 4
};

struct CollisionData{
    Direction dir;
    CollisionType type;
};

#endif