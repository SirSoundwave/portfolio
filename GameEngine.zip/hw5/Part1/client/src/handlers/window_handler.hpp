#include <iostream>
#include <SFML/Window/Keyboard.hpp>
#include <SFML/Graphics.hpp>
#include "enum_tools.hpp"

#ifndef WINDOWHANDLER_H
#define WINDOWHANDLER_H

class WindowHandler {
    private:

        static WindowHandler *instancePtr;
        sf::Vector2f offset = sf::Vector2f(0.0, 0.0);
        sf::RenderWindow* window;

        WindowHandler(){

        }

    public:
        WindowHandler(const WindowHandler &obj) = delete;

        static WindowHandler* GetInstance();

        void setOffset(sf::Vector2f newOffset){
            this->offset = newOffset;
        }

        sf::Vector2f getOffset(){
            return this->offset;
        }

        void sideScroll(Direction dir){
            switch(dir){
                case Direction::UP:
                    setOffset(sf::Vector2f(this->offset.x, this->offset.y + window->getSize().y));
                    break;
                case Direction::DOWN:
                    setOffset(sf::Vector2f(this->offset.x, this->offset.y - window->getSize().y));
                    break;
                case Direction::RIGHT:
                    setOffset(sf::Vector2f(this->offset.x - window->getSize().x, this->offset.y));
                    break;
                case Direction::LEFT:
                    setOffset(sf::Vector2f(this->offset.x + window->getSize().x, this->offset.y));
                    break;
                default:
                    break;
            }
        }

        void setWindow(sf::RenderWindow* window){
            this->window = window;
        }

        sf::RenderWindow* getWindow(){
            return this->window;
        }

};

#endif