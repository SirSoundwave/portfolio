#include "../engine/game_object.hpp"
#include <string.h>
#include <iostream>
#include "../handlers/event_manager.hpp"
#include "../handlers/collision_event.hpp"
#include "../handlers/remove_event.hpp"
#include "../handlers/event_handler.hpp"
#include "../handlers/timeline.hpp"
#include "enum_tools.hpp"
#include <mutex>
#include <map>

#ifndef COLLHANDLER_H
#define COLLHANDLER_H

using namespace std;

class CollisionHandler : public EventHandler
{
private:
    static CollisionHandler *instancePtr; //Static pointer to the CollisionHandler instance

    map<int, GameObject*> environment;
    EventManager* eventManager;
    Timeline* timeline;

    std::mutex objectListLock;

    CollisionHandler(){

    }

public:
    Direction direction;

    CollisionHandler(const CollisionHandler& obj) = delete;

    static CollisionHandler* getInstance();

    void setEventManager(EventManager* manager){
        eventManager = manager;
    }

    void setTimeline(Timeline* timeline){
        this->timeline = timeline;
    }

    GameObject* getCollidingWithEnvironment(GameObject* check){
        //std::unique_lock<std::mutex> mutexLock(this->objectListLock);
        for(std::map<int, GameObject*>::iterator it = environment.begin(); it!=environment.end(); it++){
            if(it->second->getCollidable() && it->second->getBoundingBox().intersects(check->getBoundingBox())){
                return it->second;
            }
        }
        return NULL;
    }

    void checkCollisionsWithEnvironment(GameObject* check){
        for(std::map<int, GameObject*>::iterator it = environment.begin(); it!=environment.end(); it++){
            //cout << "Subiteration: " << i << std::endl;
            if((it->second->getID() != check->getID()) && it->second->getCollidable() && it->second->getBoundingBox().intersects(check->getBoundingBox())){
                //cout << "Collision found." << std::endl;
                Direction collisionDir = getCollisionDirection(check, it->second);
                //cout << "collided id is " << environment[i]->getID() << std::endl;
                CollisionEvent* event = new CollisionEvent(timeline->getTime(), check->getID(), it->second->getCollisionType(), collisionDir);
                //cout << "sending event to queue." << std::endl;
                eventManager->QueueEvent(event);
            }
        }
    }

    void checkAllCollisionsWithEnvironment(){
        std::unique_lock<std::mutex> mutexLock(this->objectListLock);
        for(std::map<int, GameObject*>::iterator it = environment.begin(); it!=environment.end(); it++){
            //cout << "Iteration: " << i << std::endl;
            if(it->second->getActive())
                checkCollisionsWithEnvironment(it->second);
            //cout << "end Iteration: " << i << std::endl;
        }
        //cout << "completed environment checks" << std::endl;
    }

    bool isCollidingWithEnvironmentInDirection(GameObject* check, Direction dir){
        //std::unique_lock<std::mutex> mutexLock(this->objectListLock);
        //cout << "Checking collisions with " << count << " Gameobjects" << std::endl;
        if(environment.empty()){
            //cout << "environment was null" << endl;
            return false;
        }
        for(std::map<int, GameObject*>::iterator it = environment.begin(); it!=environment.end(); it++){
            if(it->second->getCollidable()){
                //cout << "Checking object " << environment[i]->toString() << " for collision direction " << dir << std::endl;
                if( (it->second != check) && getCollisionDirection(check, it->second) == dir){
                    return true;
                }
            }
        }
        return false;
    }

    Direction getCollisionDirection(GameObject* source, GameObject* other){
        //std::unique_lock<std::mutex> mutexLock(this->objectListLock);
        //cout << "Checking for collision direction" << std::endl;
        if(source == nullptr || other == nullptr){
            //cout << "One or more GameObjects was null" << std::endl;
            return Direction::NONE;
        }
        //cout << "No null GameObjects" << std::endl;
        sf::FloatRect overlap;
        if(source->getBoundingBox().intersects(other->getBoundingBox(), overlap)){
            sf::Vector2f collDir = source->getPosition() - other->getPosition();
            //cout << "Got collision direction vector" << std::endl;
            if(overlap.width > overlap.height){
                //cout << "Vertical Collision" << std::endl;
                return collDir.y > 0 ? Direction::UP : Direction::DOWN;
            } else {
                //cout << "Horizontal Collision" << std::endl;
                return collDir.x > 0 ? Direction::LEFT: Direction::RIGHT; 
            }
        }
        //cout << "No direction found" << std::endl;
        return Direction::NONE;
    }

    void addObjectToEnvironment(GameObject *obj){
        std::unique_lock<std::mutex> mutexLock(this->objectListLock);
        environment[obj->getID()] = obj;
    }

    void removeObjectFromEnvironment(GameObject *obj){
        if(environment.find(obj->getID()) != environment.end()){
            environment.erase(obj->getID());
        }
    }

    void removeObjectFromEnvironment(int id){
        cout << "checking for  " << id << std::endl;
        if(environment.find(id) != environment.end()){
            cout << "erasing " << id << std::endl;
            environment.erase(id);
        }
    }

    bool environmentContains(int id){
        return (environment.find(id) != environment.end());
    }

    void updateEnvironmentObject(int id, std::string info){
        environment[id]->Update(info);
    }

    GameObject * getGameObject(int index){
        return environment[index];
    }

    auto getEnvironment(){
        return environment;
    }

    void initEnvironmentHolder(){
        for(std::map<int, GameObject*>::iterator it = environment.begin(); it!=environment.end(); it++){
            free(it->second);
        }
        environment.clear();
    }

    virtual void OnEvent(Event event) override{
        if(event.GetType() == EventType::Remove){
            cout << "Removing from environment" << std::endl;
            removeObjectFromEnvironment(event.getSource());
        }
    }

};


#endif