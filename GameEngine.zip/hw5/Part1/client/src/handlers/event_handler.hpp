#include "event.hpp"

#ifndef EVENTHANDLER_H
#define EVENTHANDLER_H

class EventHandler{
    public:
        void HearEvent(Event event){
            this->OnEvent(event);
            
            
        }

        virtual void OnEvent(Event event){
            std::cout << "should be overridden" << std::endl;
        }
};

#endif