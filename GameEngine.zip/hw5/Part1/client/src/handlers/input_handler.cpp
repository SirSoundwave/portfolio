#include "input_handler.hpp"

void checkInput(InputCheckerStruct *inputCheck){
    inputCheck->pressedLeft = sf::Keyboard::isKeyPressed(sf::Keyboard::Left);
    inputCheck->pressedRight = sf::Keyboard::isKeyPressed(sf::Keyboard::Right);
    inputCheck->pressedUp = sf::Keyboard::isKeyPressed(sf::Keyboard::Up);
    inputCheck->pressedDown = sf::Keyboard::isKeyPressed(sf::Keyboard::Down);
    inputCheck->pressedJump = sf::Keyboard::isKeyPressed(sf::Keyboard::Up);
    inputCheck->pressed1 = sf::Keyboard::isKeyPressed(sf::Keyboard::Num1);
    inputCheck->pressed2 = sf::Keyboard::isKeyPressed(sf::Keyboard::Num2);
    inputCheck->pressed3 = sf::Keyboard::isKeyPressed(sf::Keyboard::Num3);
    inputCheck->pressedPause = sf::Keyboard::isKeyPressed(sf::Keyboard::P);
}

void resetInputChecks(InputCheckerStruct *inputCheck){
    inputCheck->pressedLeft = false;
    inputCheck->pressedRight = false;
    inputCheck->pressedUp = false;
    inputCheck->pressedDown = false;
    inputCheck->pressedJump = false;
    inputCheck->pressed1 = false;
    inputCheck->pressed2 = false;
    inputCheck->pressed3 = false;
    inputCheck->pressedPause = false;
}

void updateInputCheck(InputCheckerStruct *inputCheck, sf::Keyboard::Key key){
    //std::cout<< "Key: " << key << std::endl;
    switch (key)
    {
    case sf::Keyboard::Left :
        inputCheck->pressedLeft = true;
        break;
    case sf::Keyboard::Right :
        inputCheck->pressedRight = true;
        break;
    case sf::Keyboard::Up :
        inputCheck->pressedUp = true;
        inputCheck->pressedJump = true;
        break;
    case sf::Keyboard::Down :
        inputCheck->pressedDown = true;
        break;
    case sf::Keyboard::Num1 :
        inputCheck->pressed1 = true;
        break;
    case sf::Keyboard::Num2 :
        inputCheck->pressed2 = true;
        break;
    case sf::Keyboard::Num3 :
        inputCheck->pressed3 = true;
        break;
    case sf::Keyboard::P :
        inputCheck->pressedPause = true;
        break;    
    default:
        break;
    }
}

