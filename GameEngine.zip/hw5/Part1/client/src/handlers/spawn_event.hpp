#include "event.hpp"
#include "../engine/game_object.hpp"

#ifndef SPAWNEVENT_H
#define SPAWNEVENT_H

    class SpawnEvent : public Event{
        public:
            SpawnEvent(u_int64_t calledTime, int source){
                this->type = EventType::Spawn;
                this->calledTime = calledTime;
                this->sourceID = source;
            }

            virtual std::string ToString() override{
                return "{Type:" + std::to_string((int)this->type) +
                        ";Called Time:" + std::to_string(this->calledTime); +
                        ";Source ID:" + std::to_string(sourceID);
                        "};";
            }
    };

#endif