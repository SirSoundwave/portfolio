#include <iostream>
#include <SFML/Window/Keyboard.hpp>
#include <v8.h>
#include "../v8/v8helpers.hpp"

#ifndef INPUTHANDLER_H
#define INPUTHANDLER_H

struct InputCheckerStruct{
    bool pressedLeft = false;
    bool pressedRight = false;
    bool pressedUp = false;
    bool pressedDown = false;
    bool pressedJump = false;
    bool pressed1 = false;
    bool pressed2 = false;
    bool pressed3 = false;
    bool pressedPause = false;
};

void checkInput(InputCheckerStruct *inputCheck);

void resetInputChecks(InputCheckerStruct *inputCheck);

void updateInputCheck(InputCheckerStruct *inputCheck, sf::Keyboard::Key key);

#endif