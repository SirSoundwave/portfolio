#include <string.h>
#include <iostream>
#include <queue>
#include "event.hpp"
#include "../engine/game_object.hpp"
#include "timeline.hpp"
#include "event_handler.hpp"
#include "event_manager.hpp"
#include "key_event.hpp"
#include "chord_event.hpp"
#include <mutex>

#ifndef KEYEVENTMANAGER_H
#define KEYEVENTMANAGER_H

    using namespace std;

    class KeyEventManager : public EventManager{
        private:
            uint64_t timeThreshold = 100;
            int nextIndex = 0;
            std::vector<vector<sf::Keyboard::Key>> chords;

        public:
            KeyEventManager(Timeline* timeline);

            void addChord(list<sf::Keyboard::Key> chord){
                for(sf::Keyboard::Key key : chord){
                    chords[nextIndex].push_back(key);
                }
                nextIndex++;
            }

            void HandleEvents() override{
                //cout << "locking to handle" << std::endl;
                {
                    std::unique_lock<std::mutex> mutexLock2(this->eventQueueLock);
                    //cout << "locked to handle" << std::endl;
                    vector<Event> chordCheck;
                    vector<sf::Keyboard::Key> chordKeyCheck;
                    while(!eventQueue.empty() && eventQueue.top().GetCalledTime() <= timeline->getTime()){
                        //cout << "getting event to send" << std::endl;
                        //cout << "preparing event to raise" << std::endl;
                        Event toSend = eventQueue.top();
                        eventQueue.pop();
                        if(toSend.GetType() == EventType::Key){
                            std::cout << "time diff" << (timeline->getTime() - toSend.GetCalledTime()) << std::endl;
                            if((timeline->getTime() - toSend.GetCalledTime()) >= timeThreshold){
                                std::cout << "sending key event" << std::endl;
                                SendEvent(toSend);
                                toSend.Cleanup();
                            } else {
                                chordCheck.push_back(toSend);
                                chordKeyCheck.push_back(*(sf::Keyboard::Key *)toSend.getData());
                            }
                        }

                        //cout << "event sent" << std::endl;
                    }
                    for(int i = 0; i < chords.size(); i++){
                        if(chords[i].size() < chordCheck.size()){
                            continue;
                        } else {
                            bool allKeysFound = true;
                            for(sf::Keyboard::Key key : chords[i]){
                                if(std::find(chords[i].begin(), chords[i].end(), key) == chords[i].end()){
                                    allKeysFound = false;
                                    break;
                                }
                            }
                            if(allKeysFound){
                                vector<sf::Keyboard::Key> chord = chords[i];
                                QueueEvent(new ChordEvent(timeline->getTime(), chord));
                                for(sf::Keyboard::Key key : chords[i]){
                                    chordKeyCheck.erase(std::find(chordKeyCheck.begin(), chordKeyCheck.end(), key));
                                }
                            }                     
                        }
                    }
                    for(Event event : chordCheck){
                        if(std::find(chordKeyCheck.begin(), chordKeyCheck.end(), *(sf::Keyboard::Key *)event.getData()) != chordKeyCheck.end()){
                            QueueEvent(event.copy());
                        }
                    }
                }
                //cout << "unlocked from handle" << std::endl;
            }
    };

#endif