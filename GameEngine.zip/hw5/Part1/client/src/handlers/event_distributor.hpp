#include "event_handler.hpp"

#ifndef EVENTDIST_H
#define EVENTDIST_H

class EventDistributor : public EventHandler{
    public:
        EventDistributor(){
            eventsToSend = "";
        }

        virtual void OnEvent(Event event) override{
            //std::cout << "Got event: " << event->ToString() << std::endl;
            eventsToSend += event.ToString() + "|";
        }

        std::string getEventsToSend(){
            return eventsToSend;
        }

        void cleanEventsToSend(){
            eventsToSend = "";
        }
    private:
        std::string eventsToSend;
};

#endif