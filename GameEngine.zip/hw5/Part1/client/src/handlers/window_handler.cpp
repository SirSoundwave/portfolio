#include "window_handler.hpp"

WindowHandler* WindowHandler::instancePtr = nullptr;

WindowHandler* WindowHandler::GetInstance(){
        if(instancePtr == nullptr){
            instancePtr = new WindowHandler();
        }
        return instancePtr;
    }