#include "../engine/game_object.hpp"

#ifndef SPAWNPOINT_H
#define SPAWNPOINT_H

class SpawnPoint : public GameObject
{
public:
    SpawnPoint(const sf::Vector2f& position = sf::Vector2f(0.f, 0.f));
    

};

#endif