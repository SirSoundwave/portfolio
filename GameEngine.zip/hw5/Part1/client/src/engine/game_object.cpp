#include <SFML/Graphics/RectangleShape.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Texture.hpp>
#include "game_object.hpp"
#include <string>
#include <cstring>
#include <iostream>
#include "../handlers/collision_handler.hpp"
#include "../v8/ScriptManager.h"
#include "../v8/v8helpers.hpp"
#include <filesystem>

int GameObject::nextID = 0;
std::vector<GameObject*> GameObject::game_objects;

GameObject::GameObject(const sf::Vector2f& size, const sf::Vector2f& position, bool collidable)
{
    this->objectID = ++nextID;
    this->setPosition(position);
    setSize(size);
    this->collidable = collidable;
    this->colType = CollisionType::STANDARD;
    guid = "gameobject" + std::to_string(this->objectID);
    game_objects.push_back(this);
}

/*
GameObject::~GameObject()
{
    if(context != NULL){
       context->Reset();
    }
	
}*/

/**
 * Can read a formatted string into a GameObject.
*/
GameObject::GameObject(std::string rep)
{

    //Read ID
    std::string idRaw = rep.substr(rep.find("ID:") + 3, rep.find(",", rep.find("ID:")) - (rep.find("ID:") + 3));
    int readId = std::stoi(idRaw);
    this->objectID = readId;

    //Read Position
    std::string posXRaw = rep.substr(rep.find("Position:") + 9, rep.find(",", rep.find("Position:")) - (rep.find("Position:") + 9));
    float positionX = std::stof(posXRaw);
    std::string posYRaw = rep.substr(rep.find(",", rep.find("Position:")) + 1, rep.find(";", rep.find("Position:")) - (rep.find(",", rep.find("Position:")) + 1));
    float positionY = std::stof(posYRaw);
    //std::cout << "New Object Position: " << positionX << ", " << positionY << std::endl;
    this->setPosition(sf::Vector2f(positionX, positionY));

    //Read Size
    float sizeX = std::stof(rep.substr(rep.find("Size:") + 5, rep.find(",", rep.find("Size:")) - (rep.find("Size:") + 5)));
    float sizeY = std::stof(rep.substr(rep.find(",", rep.find("Size:")) + 1, rep.find(";", rep.find("Size:")) - (rep.find(",", rep.find("Size:")) + 1)));
    setSize(sf::Vector2f(sizeX, sizeY));

    //Read Velocity
    std::string velXRaw = rep.substr(rep.find("Velocity:") + 9, rep.find(",", rep.find("Velocity:")) - (rep.find("Velocity:") + 9)); 
    std::string velYRaw = rep.substr(rep.find(",", rep.find("Velocity:")) + 1, rep.find(";", rep.find("Velocity:")) - (rep.find(",", rep.find("Velocity:")) + 1));
    //std::cout << "New Object Velocity: " << velXRaw << ", " << velYRaw << std::endl;
    float velX = std::stof(velXRaw);
    float velY = std::stof(velYRaw);
    
    this->velocity = sf::Vector2f(velX, velY);

    // Read Collidable
    std::string collidableRaw = rep.substr(rep.find("Collidable:")+11, rep.find(";", rep.find("Collidable:")) - (rep.find("Collidable:")+11));
    //std::cout << "Collidable: " << collidableRaw << std::endl;
    this->collidable = std::stoi(collidableRaw);

    // Read Collision Type
    std::string colTypeRaw = rep.substr(rep.find("Collision Type:")+15, rep.find(";", rep.find("Collision Type:")) - (rep.find("Collision Type:")+15));
    //std::cout << "Collision Type: " << collidableRaw << std::endl;
    this->colType = (CollisionType)std::stoi(colTypeRaw);

    // Read Should Render
    std::string renderRaw = rep.substr(rep.find("ShouldRender:")+13, rep.find(";", rep.find("ShouldRender:")) - (rep.find("ShouldRender:")+13));
    //std::cout << "Render: " << renderRaw << std::endl;
    this->shouldRender = std::stoi(renderRaw);

    // Read Active
    std::string activeRaw = rep.substr(rep.find("Active:")+7, rep.find(";", rep.find("Active:")) - (rep.find("Active:")+7));
    //std::cout << "Active: " << activeRaw << std::endl;
    this->active = std::stoi(activeRaw);

    // Read Speed
    std::string speedRaw = rep.substr(rep.find("Speed:")+6, rep.find(";", rep.find("Speed:")) - (rep.find("Speed:")+6));
    //std::cout << "Speed: " << speedRaw << std::endl;
    this->speed = std::stof(speedRaw);

    // Read Colors
    std::string rRaw = rep.substr(rep.find("Color:")+6,
                                 rep.find(",", rep.find("Color:")) - (rep.find("Color:")+6));
    std::string gRaw = rep.substr(rep.find(",", rep.find("Color:")) + 1,
                                  rep.find(",", rep.find(",", rep.find("Color:")) + 1) - (rep.find(",", rep.find("Color:") + 1) + 1));
    std::string bRaw = rep.substr(rep.find(",", rep.find(",", rep.find("Color:")) + 1) + 1,
                                  rep.find(";", rep.find("Color:")) - (rep.find(",", rep.find(",", rep.find("Color:")) + 1) + 1));
    std::cout << "Color: r: " << rRaw << ", g: " << gRaw << ", b: " << bRaw << std::endl;
    int r = std::stoi(rRaw);
    int g = std::stoi(gRaw);
    int b = std::stoi(bRaw);
    this->setFillColor(sf::Color(r, g, b));

    if(rep.find("Texture:") != std::string::npos){
        this->textureLoc = rep.substr(rep.find("Texture:")+8, rep.find(";", rep.find("Texture:")) - (rep.find("Texture:")+8));
        if(objectTexture.loadFromFile(textureLoc)){
            this->setTexture(&objectTexture);
        }
    }
    guid = "gameobject" + std::to_string(this->objectID);
    std::cout << "guid: " << guid << std::endl;
    std::cout << "pushed to gameobjects vector" << std::endl;
}

std::size_t GameObject::getPointCount() const
{
    return 4;
}

void GameObject::setTextureAddress(std::string &address){
    this->textureLoc.assign(address);
}

sf::Vector2f GameObject::getPoint(std::size_t index) const
{
    sf::Vector2f direction = sf::Vector2f(0.f, 0.f);

    switch(index) {
        case 0:
            direction.x = -m_size.x / 2;
            direction.y = m_size.y / 2;
            break;
        case 1:
            direction.x = -m_size.x / 2;
            direction.y = -m_size.y / 2;
            break;
        case 2:
            direction.x = m_size.x / 2;
            direction.y = -m_size.y / 2;
            break;
        case 3:
            direction.x = m_size.x / 2;
            direction.y = m_size.y / 2;
            break;
        default:
            break;
    }
    return direction;
}

/**
 * Creates a formatted String based on the GameObject's properties
*/
std::string GameObject::toString(){
    std::string rep = "{ID:" + std::to_string(this->getID()) +
                      ";Size:" + std::to_string(this->getSize().x) + "," + std::to_string(this->getSize().y) +
                      ";Position:"+ std::to_string(this->getPosition().x) + "," + std::to_string(this->getPosition().y)+
                      ";Velocity:"+ std::to_string(this->getVelocity().x) + "," + std::to_string(this->getVelocity().y)+
                      ";Collidable:" + std::to_string((int)this->collidable) +
                      ";Collision Type:" + std::to_string((int)this->colType) +
                      ";ShouldRender:" + std::to_string(this->shouldRender) +
                      ";Active:" + std::to_string(this->active) +
                      ";Speed:" + std::to_string(this->speed) +
                      ";Color:" + std::to_string(this->getFillColor().r) + "," + std::to_string(this->getFillColor().g) + "," + std::to_string(this->getFillColor().b);
    if(strcmp(this->textureLoc.c_str(), "null") != 0){
        rep += ";Texture:"+textureLoc;
    }
    rep += ";}";
    return rep;
}

/**
 * Implementations of static setter and getter functions
 *
 * IMPORTANT: These setter and getter functions will set and get values of v8
 * callback data structures. Note their return type is void regardless of
 * whether they are setter or getter. 
 *
 * Also keep in mind that the function signature must match this exactly in
 * order for v8 to accept these functions. 
 */ 

void GameObject::setGameObjectX(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->setPosition(value->NumberValue(), static_cast<GameObject*>(ptr)->getPosition().y);
}

void GameObject::getGameObjectX(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	float x_val = static_cast<GameObject*>(ptr)->getPosition().x;
	info.GetReturnValue().Set(x_val);
}


void GameObject::setGameObjectY(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->setPosition(static_cast<GameObject*>(ptr)->getPosition().x, value->NumberValue());
}

void GameObject::getGameObjectY(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	int y_val = static_cast<GameObject*>(ptr)->getPosition().y;
	info.GetReturnValue().Set(y_val);
}

void GameObject::setGameObjectGUID(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	v8::String::Utf8Value utf8_str(info.GetIsolate(), value->ToString());
	static_cast<GameObject*>(ptr)->guid = *utf8_str;
}

void GameObject::getGameObjectGUID(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	std::string guid = static_cast<GameObject*>(ptr)->guid;
	v8::Local<v8::String> v8_guid = v8::String::NewFromUtf8(info.GetIsolate(), guid.c_str(), v8::String::kNormalString);
	info.GetReturnValue().Set(v8_guid);
}

void GameObject::setGameObjectSpeed(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->speed = value->Int32Value();
}

void GameObject::getGameObjectSpeed(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	int speed_val = static_cast<GameObject*>(ptr)->speed;
	info.GetReturnValue().Set(speed_val);
}

void GameObject::setGameObjectCollisionType(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->colType = static_cast<CollisionType>(value->Int32Value());
}

void GameObject::getGameObjectCollisionType(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	int col_val = static_cast<int>(static_cast<GameObject*>(ptr)->colType);
	info.GetReturnValue().Set(col_val);
}

void GameObject::setGameObjectActive(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->active = value->BooleanValue();
}

void GameObject::getGameObjectActive(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	bool active_val = static_cast<GameObject*>(ptr)->active;
	info.GetReturnValue().Set(active_val);
}

void GameObject::setGameObjectVelocityX(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->setVelocity(sf::Vector2f(value->NumberValue(), static_cast<GameObject*>(ptr)->getVelocity().y));
}

void GameObject::getGameObjectVelocityX(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	float x_val = static_cast<GameObject*>(ptr)->getVelocity().x;
	info.GetReturnValue().Set(x_val);
}


void GameObject::setGameObjectVelocityY(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->setVelocity(sf::Vector2f(static_cast<GameObject*>(ptr)->getVelocity().x, value->NumberValue()));
}

void GameObject::getGameObjectVelocityY(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	float y_val = static_cast<GameObject*>(ptr)->getVelocity().y;
	info.GetReturnValue().Set(y_val);
}

void GameObject::setGameObjectSizeX(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->setSize(sf::Vector2f(value->NumberValue(), static_cast<GameObject*>(ptr)->getSize().y));
}

void GameObject::getGameObjectSizeX(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	float x_val = static_cast<GameObject*>(ptr)->getSize().x;
	info.GetReturnValue().Set(x_val);
}


void GameObject::setGameObjectSizeY(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->setSize(sf::Vector2f(static_cast<GameObject*>(ptr)->getSize().x, value->NumberValue()));
}

void GameObject::getGameObjectSizeY(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	float y_val = static_cast<GameObject*>(ptr)->getSize().y;
	info.GetReturnValue().Set(y_val);
}

void GameObject::setGameObjectColorR(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->setColor(value->Uint32Value(), static_cast<GameObject*>(ptr)->getColor().g, static_cast<GameObject*>(ptr)->getColor().b);
    static_cast<GameObject*>(ptr)->setFillColor(static_cast<GameObject*>(ptr)->getColor());
}

void GameObject::getGameObjectColorR(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	float r_val = static_cast<GameObject*>(ptr)->getColor().r;
	info.GetReturnValue().Set(r_val);
}

void GameObject::setGameObjectColorG(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->setColor(static_cast<GameObject*>(ptr)->getColor().r, value->Uint32Value(), static_cast<GameObject*>(ptr)->getColor().b);
    static_cast<GameObject*>(ptr)->setFillColor(static_cast<GameObject*>(ptr)->getColor());
}

void GameObject::getGameObjectColorG(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	float g_val = static_cast<GameObject*>(ptr)->getColor().g;
	info.GetReturnValue().Set(g_val);
}

void GameObject::setGameObjectColorB(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->setColor(static_cast<GameObject*>(ptr)->getColor().r, static_cast<GameObject*>(ptr)->getColor().g, value->Uint32Value());
    static_cast<GameObject*>(ptr)->setFillColor(static_cast<GameObject*>(ptr)->getColor());
}

void GameObject::getGameObjectColorB(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	float b_val = static_cast<GameObject*>(ptr)->getColor().b;
	info.GetReturnValue().Set(b_val);
}

void GameObject::setGameObjectCollidable(v8::Local<v8::String> property, v8::Local<v8::Value> value, const v8::PropertyCallbackInfo<void>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	static_cast<GameObject*>(ptr)->collidable = value->BooleanValue();
}

void GameObject::getGameObjectCollidable(v8::Local<v8::String> property, const v8::PropertyCallbackInfo<v8::Value>& info)
{
	v8::Local<v8::Object> self = info.Holder();
	v8::Local<v8::External> wrap = v8::Local<v8::External>::Cast(self->GetInternalField(0));
	void* ptr = wrap->Value();
	bool collidable_val = static_cast<GameObject*>(ptr)->collidable;
	info.GetReturnValue().Set(collidable_val);
}



/**
 * Factory method for allowing javascript to create instances of native game
 * objects
 *
 * NOTE: Like with the setters above, this static function does have a return
 * type (and object), but the return value is placed in the function callback
 * parameter, not the native c++ return type.
 */
void GameObject::ScriptedGameObjectFactory(const v8::FunctionCallbackInfo<v8::Value>& args)
{
	v8::Isolate *isolate = args.GetIsolate();
	v8::Local<v8::Context> context = isolate->GetCurrentContext();
	v8::EscapableHandleScope handle_scope(args.GetIsolate());
	v8::Context::Scope context_scope(context);

	std::string context_name("default");
	if(args.Length() == 1)
	{
		v8::String::Utf8Value str(args.GetIsolate(), args[0]);
		context_name = std::string(v8helpers::ToCString(str));
#if GO_DEBUG
		std::cout << "Created new object in context " << context_name << std::endl;
#endif
	}
	GameObject *new_object = new GameObject();
	v8::Local<v8::Object> v8_obj = new_object->exposeToV8(isolate, context);
	args.GetReturnValue().Set(handle_scope.Escape(v8_obj));
}

/**
 * IMPORTANT: Pay close attention to the definition of the std::vector in this
 * example implementation. The v8helpers::expostToV8 will assume you have
 * instantiated this exact type of vector and passed it in. If you don't the
 * helper function will not work. 
 */
v8::Local<v8::Object> GameObject::exposeToV8(v8::Isolate *isolate, v8::Local<v8::Context> &context, std::string context_name)
{
	std::vector<v8helpers::ParamContainer<v8::AccessorGetterCallback, v8::AccessorSetterCallback>> v;
	v.push_back(v8helpers::ParamContainer("x", getGameObjectX, setGameObjectX));
	v.push_back(v8helpers::ParamContainer("y", getGameObjectY, setGameObjectY));
	v.push_back(v8helpers::ParamContainer("guid", getGameObjectGUID, setGameObjectGUID));
    v.push_back(v8helpers::ParamContainer("speed", getGameObjectSpeed, setGameObjectSpeed));
	v.push_back(v8helpers::ParamContainer("colType", getGameObjectCollisionType, setGameObjectCollisionType));
    v.push_back(v8helpers::ParamContainer("active", getGameObjectActive, setGameObjectActive));
	v.push_back(v8helpers::ParamContainer("velocity_x", getGameObjectVelocityX, setGameObjectVelocityX));
    v.push_back(v8helpers::ParamContainer("velocity_y", getGameObjectVelocityY, setGameObjectVelocityY));
    v.push_back(v8helpers::ParamContainer("size_x", getGameObjectSizeX, setGameObjectSizeX));
    v.push_back(v8helpers::ParamContainer("size_y", getGameObjectSizeY, setGameObjectSizeY));
    v.push_back(v8helpers::ParamContainer("r", getGameObjectColorR, setGameObjectColorR));
    v.push_back(v8helpers::ParamContainer("g", getGameObjectColorG, setGameObjectColorG));
    v.push_back(v8helpers::ParamContainer("b", getGameObjectColorB, setGameObjectColorB));
    v.push_back(v8helpers::ParamContainer("collidable", getGameObjectCollidable, setGameObjectCollidable));
	return v8helpers::exposeToV8(guid, this, v, isolate, context, context_name);
}